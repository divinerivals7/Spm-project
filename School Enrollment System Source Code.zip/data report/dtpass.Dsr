VERSION 5.00
Begin {78E93846-85FD-11D0-8487-00A0C90DC8A9} rptassess 
   Bindings        =   "dtpass.dsx":0000
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Assessment Report"
   ClientHeight    =   11085
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   10380
   MaxButton       =   0   'False
   MinButton       =   0   'False
   StartUpPosition =   2  'CenterScreen
   WindowState     =   2  'Maximized
   _ExtentX        =   18309
   _ExtentY        =   19553
   _Version        =   393216
   _DesignerVersion=   100684101
   ReportWidth     =   8928
   BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   GridX           =   10
   GridY           =   10
   LeftMargin      =   1440
   RightMargin     =   1000
   TopMargin       =   1440
   BottomMargin    =   1440
   NumSections     =   5
   SectionCode0    =   1
   BeginProperty Section0 {1C13A8E0-A0B6-11D0-848E-00A0C90DC8A9} 
      _Version        =   393216
      Name            =   "Section4"
      Object.Height          =   1875
      NumControls     =   4
      ItemType0       =   7
      BeginProperty Item0 {1C13A8E5-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Image1"
         Object.Left            =   864
         Object.Width           =   1863
         Object.Height          =   1440
         Picture         =   "dtpass.dsx":0016
         SizeMode        =   1
      EndProperty
      ItemType1       =   3
      BeginProperty Item1 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label3"
         Object.Left            =   2880
         Object.Top             =   288
         Object.Width           =   4608
         Object.Height          =   432
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   18
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Molina Montessori Center, Inc."
      EndProperty
      ItemType2       =   3
      BeginProperty Item2 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label1"
         Object.Left            =   4032
         Object.Top             =   1152
         Object.Width           =   2448
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Assessment Report"
      EndProperty
      ItemType3       =   3
      BeginProperty Item3 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label2"
         Object.Left            =   3312
         Object.Top             =   720
         Object.Width           =   3744
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "San Marcos Calumpit, Bulacan"
      EndProperty
   EndProperty
   SectionCode1    =   2
   BeginProperty Section1 {1C13A8E0-A0B6-11D0-848E-00A0C90DC8A9} 
      _Version        =   393216
      Name            =   "Section2"
      Object.Height          =   4029
      NumControls     =   22
      ItemType0       =   6
      BeginProperty Item0 {1C13A8E4-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Shape2"
         Object.Top             =   3600
         Object.Width           =   8925
         Object.Height          =   420
         BackColor       =   12648384
         BackStyle       =   1
      EndProperty
      ItemType1       =   3
      BeginProperty Item1 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label4"
         Object.Left            =   288
         Object.Top             =   1152
         Object.Width           =   2010
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Student Number:"
      EndProperty
      ItemType2       =   3
      BeginProperty Item2 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "L1"
         Object.Left            =   2160
         Object.Top             =   1152
         Object.Width           =   3600
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "L1"
      EndProperty
      ItemType3       =   3
      BeginProperty Item3 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label9"
         Object.Left            =   288
         Object.Top             =   2016
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Grade Level:"
      EndProperty
      ItemType4       =   3
      BeginProperty Item4 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "L7"
         Object.Left            =   2160
         Object.Top             =   2016
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "L7"
      EndProperty
      ItemType5       =   3
      BeginProperty Item5 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label11"
         Object.Left            =   288
         Object.Top             =   720
         Object.Width           =   570
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Date:"
      EndProperty
      ItemType6       =   3
      BeginProperty Item6 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Ld"
         Object.Left            =   2160
         Object.Top             =   720
         Object.Width           =   3600
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      EndProperty
      ItemType7       =   3
      BeginProperty Item7 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label5"
         Object.Left            =   288
         Object.Top             =   1584
         Object.Width           =   2010
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Student  Name:"
      EndProperty
      ItemType8       =   3
      BeginProperty Item8 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "L2"
         Object.Left            =   2160
         Object.Top             =   1584
         Object.Width           =   3600
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "L2"
      EndProperty
      ItemType9       =   3
      BeginProperty Item9 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label6"
         Object.Left            =   5904
         Object.Top             =   1152
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Total Payment:"
      EndProperty
      ItemType10      =   3
      BeginProperty Item10 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "lt"
         Object.Left            =   7488
         Object.Top             =   1152
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Lt"
      EndProperty
      ItemType11      =   3
      BeginProperty Item11 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label10"
         Object.Left            =   288
         Object.Top             =   2880
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "School Year:"
      EndProperty
      ItemType12      =   3
      BeginProperty Item12 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "L8"
         Object.Left            =   2160
         Object.Top             =   2880
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "L8"
      EndProperty
      ItemType13      =   6
      BeginProperty Item13 {1C13A8E4-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Shape1"
         Object.Width           =   8925
         Object.Height          =   435
         BackColor       =   12648384
         BackStyle       =   1
      EndProperty
      ItemType14      =   3
      BeginProperty Item14 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label7"
         Object.Left            =   1008
         Object.Top             =   3744
         Object.Width           =   2310
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Particulars"
         Alignment       =   2
      EndProperty
      ItemType15      =   3
      BeginProperty Item15 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label8"
         Object.Left            =   6192
         Object.Top             =   3744
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Amount"
         Alignment       =   2
      EndProperty
      ItemType16      =   3
      BeginProperty Item16 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label12"
         Object.Left            =   3312
         Object.Top             =   144
         Object.Width           =   2295
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Student Information"
         Alignment       =   2
      EndProperty
      ItemType17      =   5
      BeginProperty Item17 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line1"
         Object.Left            =   8928
         Object.Height          =   3744
      EndProperty
      ItemType18      =   5
      BeginProperty Item18 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line2"
         Object.Height          =   3888
      EndProperty
      ItemType19      =   5
      BeginProperty Item19 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line7"
         Object.Left            =   4752
         Object.Top             =   3600
         Object.Height          =   420
      EndProperty
      ItemType20      =   3
      BeginProperty Item20 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label14"
         Object.Left            =   288
         Object.Top             =   2448
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Section:"
      EndProperty
      ItemType21      =   3
      BeginProperty Item21 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "L16"
         Object.Left            =   2160
         Object.Top             =   2448
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "L16"
      EndProperty
   EndProperty
   SectionCode2    =   4
   BeginProperty Section2 {1C13A8E0-A0B6-11D0-848E-00A0C90DC8A9} 
      _Version        =   393216
      Name            =   "Section1"
      Object.Height          =   432
      NumControls     =   6
      ItemType0       =   4
      BeginProperty Item0 {1C13A8E2-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Text1"
         Object.Left            =   1296
         Object.Top             =   144
         Object.Width           =   2880
         Object.Height          =   144
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         DataField       =   "Particular"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
      EndProperty
      ItemType1       =   4
      BeginProperty Item1 {1C13A8E2-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Text2"
         Object.Left            =   5760
         Object.Top             =   144
         Object.Width           =   1440
         Object.Height          =   288
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         DataField       =   "Amount"
         Alignment       =   1
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   1
            Format          =   "#,##0.00"
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   1
         EndProperty
      EndProperty
      ItemType2       =   5
      BeginProperty Item2 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line3"
         Object.Left            =   8928
         Object.Height          =   432
      EndProperty
      ItemType3       =   5
      BeginProperty Item3 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line4"
         Object.Left            =   4752
         Object.Height          =   432
      EndProperty
      ItemType4       =   5
      BeginProperty Item4 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line6"
         Object.Height          =   432
      EndProperty
      ItemType5       =   5
      BeginProperty Item5 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line8"
         Object.Top             =   432
         Object.Width           =   8928
      EndProperty
   EndProperty
   SectionCode3    =   7
   BeginProperty Section3 {1C13A8E0-A0B6-11D0-848E-00A0C90DC8A9} 
      _Version        =   393216
      Name            =   "Section3"
      Object.Height          =   3
      NumControls     =   0
   EndProperty
   SectionCode4    =   8
   BeginProperty Section4 {1C13A8E0-A0B6-11D0-848E-00A0C90DC8A9} 
      _Version        =   393216
      Name            =   "Section5"
      Object.Height          =   867
      NumControls     =   4
      ItemType0       =   3
      BeginProperty Item0 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label15"
         Object.Left            =   288
         Object.Top             =   576
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Printed By:"
      EndProperty
      ItemType1       =   3
      BeginProperty Item1 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Labelu"
         Object.Left            =   1872
         Object.Top             =   576
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      EndProperty
      ItemType2       =   5
      BeginProperty Item2 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line5"
         Object.Left            =   1584
         Object.Top             =   864
         Object.Width           =   1860
      EndProperty
      ItemType3       =   3
      BeginProperty Item3 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label13"
         Object.Left            =   3888
         Object.Top             =   576
         Object.Width           =   5040
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Monotype Corsiva"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   -1  'True
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Dedicated to the Total Formation of Your Children's Future"
      EndProperty
   EndProperty
End
Attribute VB_Name = "rptassess"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
