VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Begin VB.Form frmassess 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Assessment"
   ClientHeight    =   9870
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   10650
   BeginProperty Font 
      Name            =   "Arial Narrow"
      Size            =   12
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   9870
   ScaleWidth      =   10650
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox Text6 
      Height          =   2655
      Left            =   11520
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   23
      Top             =   5280
      Width           =   3375
   End
   Begin VB.TextBox Text5 
      Height          =   3135
      Left            =   11520
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   22
      Top             =   2040
      Width           =   3375
   End
   Begin MSMask.MaskEdBox txttf 
      Height          =   375
      Left            =   8400
      TabIndex        =   19
      Top             =   5760
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   661
      _Version        =   393216
      Appearance      =   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Format          =   "#,##0.00;($#,##0.00)"
      PromptChar      =   "_"
   End
   Begin VB.ListBox List1 
      Height          =   1560
      ItemData        =   "frmassess.frx":0000
      Left            =   11640
      List            =   "frmassess.frx":0002
      TabIndex        =   16
      Top             =   360
      Width           =   3135
   End
   Begin MSAdodcLib.Adodc adoass 
      Height          =   375
      Left            =   720
      Top             =   5760
      Visible         =   0   'False
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   661
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   2
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   3
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   "DSN=MMIC"
      OLEDBString     =   ""
      OLEDBFile       =   ""
      DataSourceName  =   "MMIC"
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   "ASSESSMENT"
      Caption         =   "Adodc1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin vkUserContolsXP.vkFrame vkFrame3 
      Height          =   2415
      Left            =   360
      TabIndex        =   2
      Top             =   3240
      Width           =   9975
      _ExtentX        =   17595
      _ExtentY        =   4260
      Caption         =   "Payment Info"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin MSDataGridLib.DataGrid dtgpart 
         Height          =   1935
         Left            =   120
         TabIndex        =   14
         Top             =   360
         Width           =   9735
         _ExtentX        =   17171
         _ExtentY        =   3413
         _Version        =   393216
         BackColor       =   12640511
         HeadLines       =   1
         RowHeight       =   24
         BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ColumnCount     =   2
         BeginProperty Column00 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         BeginProperty Column01 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         SplitCount      =   1
         BeginProperty Split0 
            BeginProperty Column00 
            EndProperty
            BeginProperty Column01 
            EndProperty
         EndProperty
      End
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   10320
      Top             =   1200
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkCommand cmdprint 
      Height          =   495
      Left            =   5760
      TabIndex        =   0
      Top             =   9240
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   873
      Caption         =   "&Print"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmdcancel 
      Height          =   495
      Left            =   8880
      TabIndex        =   1
      Top             =   9240
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   873
      Caption         =   "&Clear"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   495
      Left            =   7320
      TabIndex        =   4
      Top             =   9240
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   873
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   3015
      Left            =   360
      TabIndex        =   5
      Top             =   120
      Width           =   9975
      _ExtentX        =   17595
      _ExtentY        =   5318
      Caption         =   "Student Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkLabel vkLabel4 
         Height          =   375
         Left            =   240
         TabIndex        =   21
         Top             =   1920
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Section"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtsection 
         Height          =   375
         Left            =   1920
         TabIndex        =   20
         Top             =   1920
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtstudno 
         Height          =   375
         Left            =   1920
         TabIndex        =   18
         Top             =   480
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkCommand cmdenter 
         Height          =   375
         Left            =   4560
         TabIndex        =   17
         Top             =   480
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   661
         Caption         =   "&Enter"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtgl 
         Height          =   375
         Left            =   1920
         TabIndex        =   12
         Top             =   1440
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel5 
         Height          =   375
         Left            =   240
         TabIndex        =   11
         Top             =   1440
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Grade Level"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtfn 
         Height          =   375
         Left            =   1920
         TabIndex        =   10
         Top             =   960
         Width           =   7455
         _ExtentX        =   13150
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   4210816
      End
      Begin vkUserContolsXP.vkLabel vkLabel2 
         Height          =   375
         Left            =   240
         TabIndex        =   9
         Top             =   960
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Student Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel1 
         Height          =   375
         Left            =   240
         TabIndex        =   8
         Top             =   480
         Width           =   1575
         _ExtentX        =   2778
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Student Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtsy 
         Height          =   375
         Left            =   1920
         TabIndex        =   7
         Top             =   2400
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel3 
         Height          =   375
         Left            =   240
         TabIndex        =   6
         Top             =   2400
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "School Year"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   2895
      Left            =   360
      TabIndex        =   13
      Top             =   6240
      Width           =   9975
      _ExtentX        =   17595
      _ExtentY        =   5106
      Caption         =   "Assessment Record"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin MSDataGridLib.DataGrid dtgass 
         Bindings        =   "frmassess.frx":0004
         Height          =   2415
         Left            =   120
         TabIndex        =   15
         Top             =   360
         Width           =   9735
         _ExtentX        =   17171
         _ExtentY        =   4260
         _Version        =   393216
         BackColor       =   12640511
         HeadLines       =   1
         RowHeight       =   24
         BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ColumnCount     =   2
         BeginProperty Column00 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         BeginProperty Column01 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         SplitCount      =   1
         BeginProperty Split0 
            BeginProperty Column00 
            EndProperty
            BeginProperty Column01 
            EndProperty
         EndProperty
      End
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "Total Fee"
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   7440
      TabIndex        =   3
      Top             =   5760
      Width           =   1095
   End
End
Attribute VB_Name = "frmassess"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*****************
' frmassess code *
'*****************
Private Sub cmdcancel_Click()
Call cleartextfields
Me.dtgpart.Enabled = False
Me.txtstudno.SetFocus
Me.txtstudno.locked = False
Me.cmdprint.Enabled = False
Me.cmdsave.Enabled = False
unlocked
Set dtgpart.DataSource = Nothing
Set dtgass.DataSource = rsASSESSMENT
dbgrid
End Sub

Private Sub cmdenter_Click()
If Len(Me.txtstudno.Text) <= 0 Then Exit Sub
With rsASSESSMENT
    .Find "Student_Number = '" & Trim(Me.txtstudno.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
    MsgBox "Student number already assessed!!!", vbCritical, ""
    Me.txtstudno.SetFocus
    cleartextfields
    Me.cmdsave.Enabled = False
: Exit Sub
    End If
End With
With rsREGISTRATION
    .Find "Student_Number= '" & Trim(Me.txtstudno.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
        locked
        Me.txtstudno.locked = True
        Me.txtstudno.Text = .Fields(0)
        Me.txtfn.Text = .Fields(1) & ", " & .Fields(2) & " " & .Fields(3)
        Me.txtgl.Text = .Fields(9)
        Me.txtsection.Text = .Fields(10)
        Me.txtsy.Text = .Fields(11)
        
Me.Text6.Text = "Assessed Student #" + Me.txtstudno.Text

With rsLOGS
.Find "logid ='" & MDIForm1.StatusBar2.Panels(6) & "'", 0, adSearchForward, 1
If Not .EOF Then
    Me.Text5.Text = .Fields(5)
End If
End With
            
        Else
        MsgBox "Student Information Not Exist!!!", vbCritical, ""
        cleartextfields
        Me.txtstudno.locked = False
        Exit Sub
        End If
cmdsave.Enabled = True
Me.cmdprint.Enabled = True
End With

Dim rspart2 As New ADODB.Recordset
rspart2.Open "Select * from PARTICULAR where Grade_Level like '" & Trim(Me.txtgl.Text) & "%'", con, adOpenKeyset, adLockOptimistic
Set dtgpart.DataSource = rspart2
dbgrid2

Dim rs As New ADODB.Recordset
rs.Open "Select sum(Amount) as sumpay from PARTICULAR where Grade_Level like '" & Trim(Me.txtgl.Text) & "%'", con, adOpenKeyset, adLockOptimistic

On Error GoTo err:
Me.txttf.Text = rs!sumpay
Exit Sub
err:
cmdsave.Enabled = False
Exit Sub

End Sub

Private Sub cmdprint_Click()
Dim rspart2 As New ADODB.Recordset
rspart2.Open "Select * from PARTICULAR where Grade_Level like '" & Trim(Me.txtgl.Text) & "%'", con, adOpenKeyset, adLockOptimistic
Set rptassess.DataSource = rspart2

        rptassess.Sections(2).Controls("ld").Caption = Now
        rptassess.Sections(2).Controls("L1").Caption = Me.txtstudno.Text
        rptassess.Sections(2).Controls("L2").Caption = Me.txtfn.Text
        rptassess.Sections(2).Controls("L7").Caption = Me.txtgl.Text
        rptassess.Sections(2).Controls("L8").Caption = Me.txtsy.Text
        rptassess.Sections(2).Controls("lt").Caption = Me.txttf.Text
        rptassess.Sections(2).Controls("L16").Caption = Me.txtsection.Text
        rptassess.Sections("Section5").Controls("labelu").Caption = MDIForm1.StatusBar1.Panels(5).Text
        rptassess.Show vbModal

End Sub

Private Sub cmdsave_Click()
If Me.txtstudno.Text = "" Then
    MsgBox "Please Enter Student Number...", vbCritical, ""
    txtstudno.SetFocus
Exit Sub
End If
If Me.txtfn.Text = "" Then
    MsgBox "Please Enter Student Name...", vbCritical, ""
    txtstudno.SetFocus
Exit Sub
End If
If Me.txtgl.Text = "" Then
    MsgBox "Please Enter Student Grade Level...", vbCritical, ""
    txtstudno.SetFocus
Exit Sub
End If
If Me.txtsy.Text = "" Then
    MsgBox "Please Enter Student School Year...", vbCritical, ""
    txtstudno.SetFocus
Exit Sub
End If

If Me.txttf.Text = "" Then
    MsgBox "Cannot assess a student that dont have anything to pay", vbCritical, ""
    Me.txtstudno.SetFocus
    cleartextfields
    Me.cmdsave.Enabled = False
    Me.cmdprint.Enabled = False
    Me.txtstudno.locked = False
Exit Sub
End If

act
With adoass.Recordset
    .Find "Student_Number='" & Trim(Me.txtstudno.Text) & "'", 0, adSearchForward, 1
    If .EOF <> True Then
    MsgBox "Student Already Assessed!", vbInformation, ""
    Me.txtstudno.SetFocus
    Exit Sub
Else
    .AddNew 'add new information
    .Fields(1) = Me.txtstudno.Text
    .Fields(2) = Me.txtfn.Text
    .Fields(3) = Me.txtgl.Text
    .Fields(4) = Me.txtsection.Text
    .Fields(5) = Me.txtsy.Text
    .Fields(6) = Me.txttf.Text
    .Fields(7) = Now
    .Fields(8) = MDIForm1.StatusBar2.Panels(2)
    .Update
    MDIForm1.StatusBar2.Panels(3) = .Fields(0)
    MsgBox "Successfully Saved!!!", vbInformation + vbOKOnly, ""
    Set dtgpart.DataSource = Nothing
    unlocked
    Me.txtstudno.locked = False
    MDIForm1.mnuar.Enabled = True
    MDIForm1.mnubill.Enabled = True
    CloseConnection
 End If
 End With

OpenConnection
adoass.Refresh
dbgrid
unlocked
cleartextfields
cmdsave.Enabled = False
cmdprint.Enabled = False
Me.txtstudno.SetFocus
End Sub

Private Sub dtgass_Click()
With adoass.Recordset
    If .RecordCount < 1 Then MsgBox "No Data Selected", vbExclamation, "": Exit Sub
    cleartextfields
    Me.txtstudno.Text = .Fields(1)
    Me.txtfn.Text = .Fields(2)
    Me.txtgl.Text = .Fields(3)
    Me.txtsection.Text = .Fields(4)
    Me.txtsy.Text = .Fields(5)
    Me.txttf.Text = .Fields(6)
    Me.cmdprint.Enabled = True
    Me.cmdsave.Enabled = False
dbgrid
Dim rspart2 As New ADODB.Recordset
rspart2.Open "Select * from PARTICULAR where Grade_Level like '" & Trim(Me.txtgl.Text) & "%'", con, adOpenKeyset, adLockOptimistic
Set dtgpart.DataSource = rspart2
dbgrid2
End With
End Sub

Private Sub dtgass_HeadClick(ByVal ColIndex As Integer)
With adoass.Recordset
    If (.Sort = .Fields(ColIndex).[Name] & " Asc") Then
        .Sort = .Fields(ColIndex).[Name] & " Desc"
    Else
        .Sort = .Fields(ColIndex).[Name] & " Asc"
    End If
End With
End Sub

Private Sub Form_Load()
OpenConnection
cmdsave.Enabled = False
Me.cmdprint.Enabled = False
dbgrid
'dbgrid2
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim a As Integer
If cmdsave.Enabled = True Then
    a = MsgBox("Are you sure you want to quit this form with out saving?", vbYesNo + vbQuestion, "")
        If a = vbYes Then
            Call CloseConnection
            Unload Me
        Else
            Cancel = 1
            End If
Else
    Call CloseConnection
    Unload Me
End If
End Sub

Private Sub vkCommand1_Click()
Unload Me
End Sub
Private Sub Form_Activate()
Me.txtstudno.SetFocus
locked
End Sub

Sub enabletextfields()
txtstudno.Enabled = True
txtfn.Enabled = True
txtsy.Enabled = True
txtsection.Enabled = True
txtgl.Enabled = True
txttf.Enabled = True
cmdsave.Enabled = True
End Sub

Sub cleartextfields()
Me.Text5.Text = ""
Me.Text6.Text = ""
txtstudno.Text = ""
txtfn.Text = ""
txtgl.Text = ""
txtsection.Text = ""
txtsy.Text = ""
txttf.Text = ""
End Sub

Public Sub locked()
txtfn.locked = True
txtgl.locked = True
txtsy.locked = True
End Sub
Public Sub unlocked()
txtfn.locked = False
txtgl.locked = False
txtsy.locked = False

End Sub
Private Sub txtstudno_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
 cmdenter_Click
 cmdsave.Enabled = True
End If
End Sub
Public Sub dbgrid()
dtgass.Columns(0).Width = 0
dtgass.Columns(1).Width = 1700
dtgass.Columns(2).Width = 3000
dtgass.Columns(3).Width = 1700
dtgass.Columns(4).Width = 1000
dtgass.Columns(5).Width = 1500
dtgass.Columns(6).Width = 1000
End Sub
Public Sub dbgrid2()
dtgpart.Columns(0).Width = 0
dtgpart.Columns(1).Width = 1700
dtgpart.Columns(2).Width = 3000
dtgpart.Columns(3).Width = 1000
End Sub
Public Sub clear()
Me.txtstudno.Text = ""
Me.txtfn.Text = ""
Me.txtgl.Text = ""
Me.txtsy.Text = ""
Me.txttf.Text = ""
End Sub

Public Sub act()
With rsLOGS
    .Find "logid = '" & MDIForm1.StatusBar2.Panels(6) & "'", 0, adSearchForward, 1
If Not .EOF Then
    .Fields(5) = Me.Text5.Text + ", " + Me.Text6.Text
    .Update
End If
End With
End Sub

