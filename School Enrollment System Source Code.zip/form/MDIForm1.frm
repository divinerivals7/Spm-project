VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.MDIForm MDIForm1 
   BackColor       =   &H8000000C&
   Caption         =   "Molina Montessori Center Inc. Student Information and Cashiering System"
   ClientHeight    =   9765
   ClientLeft      =   165
   ClientTop       =   810
   ClientWidth     =   11850
   Icon            =   "MDIForm1.frx":0000
   LinkTopic       =   "MDIForm1"
   Picture         =   "MDIForm1.frx":08CA
   StartUpPosition =   3  'Windows Default
   WindowState     =   2  'Maximized
   Begin ComctlLib.StatusBar StatusBar2 
      Align           =   2  'Align Bottom
      Height          =   0
      Left            =   0
      TabIndex        =   2
      Top             =   9420
      Width           =   11850
      _ExtentX        =   20902
      _ExtentY        =   0
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   7
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel2 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel3 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel4 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel5 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel6 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel7 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Tag             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Timer Timer3 
      Interval        =   150
      Left            =   120
      Top             =   9840
   End
   Begin VB.Timer Timer1 
      Left            =   0
      Top             =   600
   End
   Begin MSComctlLib.Toolbar Toolbar1 
      Align           =   1  'Align Top
      Height          =   480
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   11850
      _ExtentX        =   20902
      _ExtentY        =   847
      ButtonWidth     =   820
      ButtonHeight    =   794
      Appearance      =   1
      Style           =   1
      ImageList       =   "ImageList2"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   12
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   4
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   4
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Object.ToolTipText     =   "Click to open a file"
            ImageKey        =   "open"
            Style           =   5
            BeginProperty ButtonMenus {66833FEC-8583-11D1-B16A-00C0F0283628} 
               NumButtonMenus  =   2
               BeginProperty ButtonMenu1 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "studinfo"
                  Text            =   "Student Information"
               EndProperty
               BeginProperty ButtonMenu2 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "ai"
                  Text            =   "Applicant Information"
               EndProperty
            EndProperty
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "notepad"
            Object.ToolTipText     =   "Click to view notepad"
            ImageKey        =   "note"
         EndProperty
         BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button8 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "cal"
            Object.ToolTipText     =   "Click to view calculator"
            ImageKey        =   "cal"
         EndProperty
         BeginProperty Button9 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button10 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "exit"
            Object.ToolTipText     =   "Click to exit"
            ImageKey        =   "exit"
         EndProperty
         BeginProperty Button11 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   4
         EndProperty
         BeginProperty Button12 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   4
         EndProperty
      EndProperty
   End
   Begin ComctlLib.StatusBar StatusBar1 
      Align           =   2  'Align Bottom
      Height          =   345
      Left            =   0
      TabIndex        =   1
      Top             =   9420
      Width           =   11850
      _ExtentX        =   20902
      _ExtentY        =   609
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   16
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Visible         =   0   'False
            Object.Width           =   1766
            MinWidth        =   1766
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel2 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Visible         =   0   'False
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel3 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Bevel           =   0
            Object.Width           =   1764
            MinWidth        =   1764
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel4 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Bevel           =   0
            Object.Width           =   2822
            MinWidth        =   2822
            Picture         =   "MDIForm1.frx":1AD5F
            Text            =   "Username:"
            TextSave        =   "Username:"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel5 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Alignment       =   1
            Object.Width           =   3175
            MinWidth        =   3175
            Text            =   "Waiting. . . "
            TextSave        =   "Waiting. . . "
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel6 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Bevel           =   0
            Object.Width           =   882
            MinWidth        =   882
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel7 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Bevel           =   0
            Object.Width           =   2117
            MinWidth        =   2117
            Picture         =   "MDIForm1.frx":1B471
            Text            =   "Time:"
            TextSave        =   "Time:"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel8 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Style           =   5
            Alignment       =   1
            TextSave        =   "8:42 PM"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel9 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Bevel           =   0
            Object.Width           =   1235
            MinWidth        =   1235
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel10 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Bevel           =   0
            Object.Width           =   2117
            MinWidth        =   2117
            Picture         =   "MDIForm1.frx":1BB83
            Text            =   "Date:"
            TextSave        =   "Date:"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel11 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Style           =   6
            Alignment       =   1
            Object.Width           =   2469
            MinWidth        =   2469
            TextSave        =   "11/9/2009"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel12 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Bevel           =   0
            Object.Width           =   1235
            MinWidth        =   1235
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel13 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Style           =   1
            Enabled         =   0   'False
            Object.Width           =   1235
            MinWidth        =   1235
            TextSave        =   "CAPS"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel14 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Style           =   2
            Object.Width           =   1235
            MinWidth        =   1235
            TextSave        =   "NUM"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel15 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Style           =   3
            Enabled         =   0   'False
            Object.Width           =   1235
            MinWidth        =   1235
            TextSave        =   "INS"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel16 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Style           =   4
            Enabled         =   0   'False
            Object.Width           =   1235
            MinWidth        =   1235
            TextSave        =   "SCRL"
            Object.Tag             =   ""
         EndProperty
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin MSComctlLib.ImageList ImageList2 
      Left            =   0
      Top             =   960
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   24
      ImageHeight     =   24
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   9
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "MDIForm1.frx":1C295
            Key             =   "add"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "MDIForm1.frx":21E3E
            Key             =   "aa"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "MDIForm1.frx":223DC
            Key             =   "exit1"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "MDIForm1.frx":27FAE
            Key             =   "exit"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "MDIForm1.frx":2DB44
            Key             =   "note"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "MDIForm1.frx":334EB
            Key             =   "cal"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "MDIForm1.frx":38E1B
            Key             =   "open"
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "MDIForm1.frx":3E77E
            Key             =   "$"
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "MDIForm1.frx":44078
            Key             =   "search"
         EndProperty
      EndProperty
   End
   Begin VB.Menu mnufile 
      Caption         =   "&File"
      Begin VB.Menu mnustudinfo 
         Caption         =   "Student Information"
      End
      Begin VB.Menu mnuai 
         Caption         =   "Applicant Information"
      End
      Begin VB.Menu mnusep 
         Caption         =   "-"
      End
      Begin VB.Menu mnuswitch 
         Caption         =   "Log Out"
         Shortcut        =   ^O
      End
      Begin VB.Menu mnuseparator 
         Caption         =   "-"
      End
      Begin VB.Menu mnuau 
         Caption         =   "Add User"
      End
      Begin VB.Menu mnuseparator2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuchangepass 
         Caption         =   "Change Password"
      End
      Begin VB.Menu mnusep3 
         Caption         =   "-"
      End
      Begin VB.Menu mnulock 
         Caption         =   "Lock the System"
         Shortcut        =   ^L
      End
      Begin VB.Menu mnusep2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuexit 
         Caption         =   "Exit"
         Shortcut        =   ^E
      End
   End
   Begin VB.Menu mnuregistrar 
      Caption         =   "&Registrar"
      Begin VB.Menu mnuapp 
         Caption         =   "Application Form"
         Shortcut        =   ^A
      End
      Begin VB.Menu mnureg 
         Caption         =   "Registration Form"
         Shortcut        =   ^R
      End
      Begin VB.Menu sep5 
         Caption         =   "-"
      End
      Begin VB.Menu mnueditapp 
         Caption         =   "Edit Application Form"
      End
      Begin VB.Menu mnueditreg 
         Caption         =   "Edit Registration Form"
      End
      Begin VB.Menu sep6 
         Caption         =   "-"
      End
      Begin VB.Menu mnusy 
         Caption         =   "School Year"
      End
   End
   Begin VB.Menu mnuaccounting 
      Caption         =   "&Accounting"
      Begin VB.Menu mnuass 
         Caption         =   "Assessment"
         Shortcut        =   {F4}
      End
      Begin VB.Menu mnubill 
         Caption         =   "Payment"
         Shortcut        =   {F5}
      End
   End
   Begin VB.Menu mnutools 
      Caption         =   "&Tools"
      Begin VB.Menu mnunote 
         Caption         =   "Notepad"
         Shortcut        =   {F1}
      End
      Begin VB.Menu mnucal 
         Caption         =   "Calculator"
         Shortcut        =   {F2}
      End
   End
   Begin VB.Menu mnureport 
      Caption         =   "&Report"
      Begin VB.Menu mnuRS 
         Caption         =   "Registered Student"
         Begin VB.Menu mnuAS 
            Caption         =   "All Student"
         End
         Begin VB.Menu mnuBSY 
            Caption         =   "By School Year"
         End
         Begin VB.Menu mnuBS 
            Caption         =   "By Grade Level"
         End
      End
      Begin VB.Menu mnulogreport 
         Caption         =   "Log Report"
      End
      Begin VB.Menu mnuPR 
         Caption         =   "Payment Report"
         Begin VB.Menu mnuAPR 
            Caption         =   "All Payment Report"
         End
         Begin VB.Menu mnuBA 
            Caption         =   "By Accountant"
         End
      End
   End
   Begin VB.Menu mnuhelp 
      Caption         =   "&Help"
      Begin VB.Menu mnushort 
         Caption         =   "Shortcut Key "
         Shortcut        =   {F3}
      End
      Begin VB.Menu mnuuser 
         Caption         =   "User Manual"
      End
   End
   Begin VB.Menu mnusm 
      Caption         =   "&Maintenance"
      Begin VB.Menu mnubr 
         Caption         =   "Payment Records"
      End
      Begin VB.Menu mnuar 
         Caption         =   "Assessment Records"
      End
      Begin VB.Menu mnuID 
         Caption         =   "Reset Student ID"
      End
      Begin VB.Menu sep7 
         Caption         =   "-"
      End
      Begin VB.Menu mnuappr 
         Caption         =   "Applicant Records"
      End
      Begin VB.Menu sep8 
         Caption         =   "-"
      End
      Begin VB.Menu mnuparticular 
         Caption         =   "Particular"
         Shortcut        =   {F6}
      End
      Begin VB.Menu mnudis 
         Caption         =   "Discount"
      End
      Begin VB.Menu mnupen 
         Caption         =   "Penalty"
      End
      Begin VB.Menu mnupay 
         Caption         =   "View Payment Records"
      End
      Begin VB.Menu mnuaddsec 
         Caption         =   "Add Section"
      End
   End
End
Attribute VB_Name = "MDIForm1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'***************
'MDIForm1 code *
'***************

Dim t As Integer
Dim Y As Integer
Dim dada As String

Private Sub MDIForm_Unload(Cancel As Integer)
Dim a As Integer
a = MsgBox("Do you want to exit the MMCI Student Information and Cashiering System?", vbYesNo + vbQuestion, "")
If a = vbYes Then
 MsgBox "Automatically Log_Out!!!", vbExclamation, ""
logout
 End
Else
 Cancel = 1
 End If
End Sub

Private Sub MDIForm_Load()
dada = MDIForm1.Caption
t = Len(dada)
Y = 1
Me.Show
frmsplashscreen.Show vbModal

DataEnvironment1.rsCommand1.Open
If DataEnvironment1.rsCommand1.EOF = True Then
    mnuass.Enabled = False
    mnustudinfo.Enabled = False
    mnueditreg.Enabled = False
    mnuRS.Enabled = False
Else
    mnuass.Enabled = True
    mnustudinfo.Enabled = True
    mnueditreg.Enabled = True
End If
DataEnvironment1.rsCommand1.Close


DataEnvironment1.rsCommand3.Open
If DataEnvironment1.rsCommand3.EOF = True Then
    mnubr.Enabled = False
    mnubill.Enabled = False
Else
    mnubr.Enabled = True
    mnubill.Enabled = True
End If
DataEnvironment1.rsCommand3.Close

DataEnvironment1.rsCommand4.Open
If DataEnvironment1.rsCommand4.EOF = True Then
    mnuar.Enabled = False
    mnubill.Enabled = False
Else
    mnuar.Enabled = True
    mnubill.Enabled = True
End If
DataEnvironment1.rsCommand4.Close

DataEnvironment1.rsCommand5.Open
If DataEnvironment1.rsCommand5.EOF = True Then
    mnuappr.Enabled = False
    mnuai.Enabled = False
    mnueditapp.Enabled = False
Else
    mnuappr.Enabled = True
    mnuai.Enabled = True
    mnueditapp.Enabled = True
End If
DataEnvironment1.rsCommand5.Close

DataEnvironment1.rsCommand6.Open
If DataEnvironment1.rsCommand6.EOF = True Then
    mnuID.Enabled = False
Else
    mnuID.Enabled = True
End If
DataEnvironment1.rsCommand6.Close

End Sub

Private Sub mnuabout_Click()
frmabout.Show
End Sub

Private Sub mnuaddsec_Click()
frmaddsection.Show vbModal
End Sub

Private Sub mnuai_Click()
frmai.Show vbModal
End Sub

Private Sub mnuapp_Click()
frmapplication.Show vbModal
End Sub

Private Sub mnuappr_Click()
OpenConnection
Dim rResult
    rResult = MsgBox("Do you want to delete all the records from application?", vbQuestion + vbYesNo, "")
    If rResult = vbYes Then
        con.Execute "Delete from application"
        MsgBox "Successfully Deleted!!!", vbInformation + vbOKOnly, ""
        mnuappr.Enabled = False
        mnuai.Enabled = False
        mnueditapp.Enabled = False
    End If
CloseConnection
End Sub

Private Sub mnuAPR_Click()
DataEnvironment1.rsCommand3.Open
rptallpayment.Sections("Section5").Controls("l1").Caption = Now
rptallpayment.Sections("Section5").Controls("labelu").Caption = MDIForm1.StatusBar1.Panels(5).Text
rptallpayment.Show vbModal
End Sub
Private Sub mnuar_Click()
OpenConnection
   Dim rResult
   rResult = MsgBox("Do you want to delete all the records from assessment?", vbQuestion + vbYesNo, "")
   If rResult = vbYes Then
       con.Execute "Delete from Assessment"
       MsgBox "Successfully Deleted!!!", vbInformation + vbOKOnly, ""
       mnuar.Enabled = False
   End If
CloseConnection
End Sub

Private Sub mnuAS_Click()
rptstudentlist.Sections("Section5").Controls("label21").Caption = MDIForm1.StatusBar1.Panels(5).Text
rptstudentlist.Sections("Section5").Controls("label23").Caption = Now
rptstudentlist.Show vbModal
End Sub

Private Sub mnuass_Click()
frmassess.Show vbModal
End Sub

Private Sub mnuau_Click()
frmsec.Show vbModal
End Sub

Private Sub mnuBA_Click()
frmbyacc.Show vbModal
End Sub

Private Sub mnubill_Click()
frmbilling.Show vbModal
End Sub

Private Sub mnubr_Click()
DataEnvironment1.rsCommand3.Open
OpenConnection
   Dim rResult
   rResult = MsgBox("Do you want to delete all the records from billing?", vbQuestion + vbYesNo, "")
   If rResult = vbYes Then
       con.Execute "Delete from Billing"
       MsgBox "Successfully Deleted!!!", vbInformation + vbOKOnly, ""
       mnubr.Enabled = False
   End If
CloseConnection
End Sub

Private Sub mnuBS_Click()
frmrptgl.Show vbModal
End Sub

Private Sub mnuBSY_Click()
frmrptsy.Show vbModal
End Sub

Private Sub mnucal_Click()
On Error GoTo err
Shell "calc.exe", vbModal
Exit Sub
err:
MsgBox "You don't have a Calculator installed in your computer.", vbExclamation, ""
End Sub

Private Sub mnuchangepass_Click()
frmchangepass.Show vbModal
End Sub

Private Sub mnudis_Click()
frmdiscount.Show vbModal
End Sub

Private Sub mnueditapp_Click()
frmeditapp.Show vbModal
End Sub

Private Sub mnueditreg_Click()
frmeditreg.Show vbModal
End Sub

Private Sub mnuExit_Click()
Dim a As Integer
a = MsgBox("Do you want to exit the MMCI Student Information and Cashiering System?", vbYesNo + vbQuestion, "")
If a = vbYes Then
 MsgBox "Automatically Log_Out!!!", vbExclamation, ""
logout
 End
Else
 Cancel = 1
 End If
End Sub

Private Sub mnuregistration_Click()
frmreg.Show vbModal
End Sub

Private Sub mnuShortcutkey_Click()
frmshortcutkey.Show vbModal
End Sub

Private Sub mnustudrecord_Click()
frmstudrec.Show vbModal
End Sub

Private Sub mnuID_Click()
OpenConnection
Dim rResult
   rResult = MsgBox("Do you want to reset the student number of the student?", vbQuestion + vbYesNo, "")
   If rResult = vbYes Then
       con.Execute "Delete from ID"
       MsgBox "Successfully Deleted!!!", vbInformation + vbOKOnly, ""
       mnuID.Enabled = False
   End If
CloseConnection
End Sub

Private Sub mnulock_Click()
Dim a As Integer
a = MsgBox("Do you want to Lock the MMCI System?", vbQuestion + vbYesNo, "")
If a = vbYes Then
 MsgBox "System has been locked please enter password to unlock the system!!!", vbExclamation, ""
 frmunlock.Show vbModal
Else
 Cancel = 1
 End If
End Sub

Private Sub mnulogreport_Click()
DataEnvironment1.rsCommand2.Open
rptlogreport.Sections(5).Controls("label21").Caption = MDIForm1.StatusBar1.Panels(5)
rptlogreport.Sections(5).Controls("label6").Caption = Now
rptlogreport.Show vbModal
End Sub

Private Sub mnunote_Click()
On Error GoTo err2
Shell "notepad.exe", vbModal
Exit Sub
err2:
MsgBox "You don't have a NotePad installed in your computer.", vbExclamation, ""
End Sub

Private Sub mnuparticular_Click()
frmparticular.Show vbModal
End Sub

Private Sub mnupay_Click()
frmviewpaymentrecords.Show vbModal
End Sub

Private Sub mnupen_Click()
frmpenalty.Show vbModal
End Sub
Private Sub mnureg_Click()
frmreg.Show vbModal
End Sub

Private Sub mnushort_Click()
frmshortcutkey.Show vbModal
End Sub

Private Sub mnuswitch_Click()
If MsgBox("Are you sure you want to Log Out?", vbQuestion + vbYesNo, "") = vbNo Then Exit Sub
 Me.StatusBar1.Panels(5).Text = "Waiting...."
logout
frmlogin.Show vbModal
End Sub

Private Sub mnusy_Click()
frmsy.Show vbModal
End Sub

Private Sub mnuuser_Click()
frmusermanual.Show
End Sub

Private Sub Timer3_Timer()
MDIForm1.Caption = Mid$(dada, Y, t)
Y = Y + 0.8
If Y > t Then
Y = 1
End If
End Sub

Private Sub Toolbar1_ButtonClick(ByVal Button As MSComctlLib.Button)
Select Case Button.Key
    Case "cal"
            mnucal_Click
    Case "notepad"
            mnunote_Click
    Case "exit"
            mnuExit_Click
End Select
End Sub

Private Sub Toolbar1_ButtonMenuClick(ByVal ButtonMenu As MSComctlLib.ButtonMenu)
Select Case ButtonMenu.Key
     Case "studinfo"
            mnustudinfo_click
     Case "studrec"
            mnustudrec_click
    Case "ai"
            mnuai_Click
    End Select
End Sub

Private Sub mnustudentlist_click()
frmapplication.Show vbModal
End Sub

Private Sub mnustudinfo_click()
frmstudinfo.Show vbModal
End Sub

Private Sub mnustudrec_click()
frmstudrec.Show vbModal
End Sub

Public Sub registrar()
Me.mnuaccounting.Enabled = False
Me.mnuregistrar.Enabled = True
mnulogreport.Enabled = False
Me.mnuau.Enabled = False
Me.mnusm.Enabled = False
Me.mnuPR.Enabled = False
End Sub
Public Sub admin()
Me.mnuregistrar.Enabled = True
Me.mnuaccounting.Enabled = True
mnulogreport.Enabled = True
Me.mnuau.Enabled = True
Me.mnusm.Enabled = True
Me.mnuPR.Enabled = True
End Sub

Public Sub accounting()
Me.mnuregistrar.Enabled = False
Me.mnuaccounting.Enabled = True
mnulogreport.Enabled = False
Me.mnuau.Enabled = False
Me.mnusm.Enabled = False
Me.mnuPR.Enabled = False
End Sub

Public Sub logout()
OpenConnection
With rsLOGS
    .Find "logid= '" & (MDIForm1.StatusBar1.Panels(2)) & "'", 0, adSearchForward, 1
If Not .EOF Then
    .Fields(4) = Now
    .Update
End If
End With
CloseConnection
End Sub
