VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Begin VB.Form frmeditreg 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Edit Registration Form"
   ClientHeight    =   7665
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   11685
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   7665
   ScaleWidth      =   11685
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox Text5 
      Height          =   1095
      Left            =   14160
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   42
      Top             =   4920
      Width           =   2055
   End
   Begin VB.TextBox Text6 
      Height          =   1095
      Left            =   14160
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   41
      Top             =   6120
      Width           =   2055
   End
   Begin VB.TextBox Text3 
      Height          =   405
      Left            =   12600
      TabIndex        =   37
      Text            =   "Text3"
      Top             =   4920
      Width           =   975
   End
   Begin VB.TextBox Text2 
      Height          =   405
      Left            =   12600
      TabIndex        =   36
      Text            =   "Text2"
      Top             =   4440
      Width           =   975
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   12600
      TabIndex        =   35
      Text            =   "Text1"
      Top             =   3960
      Width           =   975
   End
   Begin MSDataGridLib.DataGrid dtges 
      Bindings        =   "frmeditreg.frx":0000
      Height          =   975
      Left            =   12480
      TabIndex        =   6
      Top             =   1440
      Visible         =   0   'False
      Width           =   2415
      _ExtentX        =   4260
      _ExtentY        =   1720
      _Version        =   393216
      HeadLines       =   1
      RowHeight       =   15
      BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ColumnCount     =   2
      BeginProperty Column00 
         DataField       =   ""
         Caption         =   ""
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
      EndProperty
      BeginProperty Column01 
         DataField       =   ""
         Caption         =   ""
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
      EndProperty
      SplitCount      =   1
      BeginProperty Split0 
         BeginProperty Column00 
         EndProperty
         BeginProperty Column01 
         EndProperty
      EndProperty
   End
   Begin vkUserContolsXP.vkTextBox txtstudno 
      Height          =   375
      Left            =   2040
      TabIndex        =   3
      Top             =   2040
      Width           =   2055
      _ExtentX        =   3625
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Alignment       =   2
      BorderColor     =   4210816
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkLabel vkLabel1 
      Height          =   375
      Left            =   360
      TabIndex        =   2
      Top             =   2040
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Enter Student No."
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   495
      Left            =   8520
      TabIndex        =   0
      Top             =   6960
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   8640
      Top             =   120
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   1095
      Left            =   240
      TabIndex        =   4
      Top             =   1560
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   1931
      Caption         =   "Search"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
   End
   Begin vkUserContolsXP.vkCommand cmdcancel 
      Height          =   495
      Left            =   9960
      TabIndex        =   5
      Top             =   6960
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   873
      Caption         =   "&Clear"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   4095
      Left            =   240
      TabIndex        =   7
      Top             =   2760
      Width           =   11175
      _ExtentX        =   19711
      _ExtentY        =   7223
      Caption         =   "Edit Registration Form"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin MSMask.MaskEdBox txtmcpno 
         Height          =   375
         Left            =   6480
         TabIndex        =   40
         Top             =   3480
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BackColor       =   16777215
         MaxLength       =   12
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Mask            =   "####-#######"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox txtfcpno 
         Height          =   375
         Left            =   6480
         TabIndex        =   39
         Top             =   3000
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BackColor       =   16777215
         MaxLength       =   12
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Mask            =   "####-#######"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox txtcpno 
         Height          =   375
         Left            =   6480
         TabIndex        =   38
         Top             =   1560
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BackColor       =   16777215
         MaxLength       =   12
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Mask            =   "####-#######"
         PromptChar      =   "_"
      End
      Begin MSComCtl2.DTPicker dtpdateofbirth 
         Height          =   375
         Left            =   1800
         TabIndex        =   34
         Top             =   2520
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         _Version        =   393216
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         CustomFormat    =   "MMM-dd-yyyy"
         Format          =   21299203
         CurrentDate     =   40095
      End
      Begin vkUserContolsXP.vkTextBox txtmname 
         Height          =   375
         Left            =   1800
         TabIndex        =   33
         Top             =   3480
         Width           =   2895
         _ExtentX        =   5106
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtfname 
         Height          =   375
         Left            =   1800
         TabIndex        =   32
         Top             =   3000
         Width           =   2895
         _ExtentX        =   5106
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin VB.ComboBox cbosection 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmeditreg.frx":0014
         Left            =   10200
         List            =   "frmeditreg.frx":0024
         Style           =   2  'Dropdown List
         TabIndex        =   31
         Top             =   2520
         Width           =   735
      End
      Begin VB.ComboBox cbogl 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmeditreg.frx":0034
         Left            =   6480
         List            =   "frmeditreg.frx":0053
         Style           =   2  'Dropdown List
         TabIndex        =   30
         Top             =   2520
         Width           =   2775
      End
      Begin vkUserContolsXP.vkTextBox txtadd 
         Height          =   375
         Left            =   6480
         TabIndex        =   29
         Top             =   2040
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin VB.ComboBox cbogender 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmeditreg.frx":00CE
         Left            =   6480
         List            =   "frmeditreg.frx":00D8
         Style           =   2  'Dropdown List
         TabIndex        =   28
         Top             =   1080
         Width           =   855
      End
      Begin vkUserContolsXP.vkTextBox txtage 
         Height          =   375
         Left            =   3840
         TabIndex        =   27
         Top             =   2520
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtln 
         Height          =   375
         Left            =   1800
         TabIndex        =   26
         Top             =   2040
         Width           =   2895
         _ExtentX        =   5106
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtmi 
         Height          =   375
         Left            =   1800
         TabIndex        =   25
         Top             =   1560
         Width           =   2895
         _ExtentX        =   5106
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtfn 
         Height          =   375
         Left            =   1800
         TabIndex        =   24
         Top             =   1080
         Width           =   2895
         _ExtentX        =   5106
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel15 
         Height          =   375
         Left            =   4920
         TabIndex        =   23
         Top             =   3480
         Width           =   2295
         _ExtentX        =   4048
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel3 
         Height          =   375
         Left            =   240
         TabIndex        =   22
         Top             =   1080
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "First Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel4 
         Height          =   375
         Left            =   240
         TabIndex        =   21
         Top             =   1560
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Middle Initial"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel5 
         Height          =   375
         Left            =   240
         TabIndex        =   20
         Top             =   2040
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Last Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel6 
         Height          =   375
         Left            =   3360
         TabIndex        =   19
         Top             =   2520
         Width           =   495
         _ExtentX        =   873
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Age"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel7 
         Height          =   375
         Left            =   4920
         TabIndex        =   18
         Top             =   1080
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Gender"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel9 
         Height          =   375
         Left            =   240
         TabIndex        =   17
         Top             =   480
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "School Year"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel10 
         Height          =   375
         Left            =   4920
         TabIndex        =   16
         Top             =   2520
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Grade Level"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel2 
         Height          =   375
         Left            =   4920
         TabIndex        =   15
         Top             =   2040
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Address"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel8 
         Height          =   375
         Left            =   4920
         TabIndex        =   14
         Top             =   1560
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.ComboBox cbosy 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         Left            =   1800
         Style           =   2  'Dropdown List
         TabIndex        =   13
         Top             =   480
         Width           =   1815
      End
      Begin vkUserContolsXP.vkLabel vkLabel12 
         Height          =   375
         Left            =   240
         TabIndex        =   12
         Top             =   3000
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Father's Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel13 
         Height          =   375
         Left            =   4920
         TabIndex        =   11
         Top             =   3000
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel14 
         Height          =   375
         Left            =   240
         TabIndex        =   10
         Top             =   3480
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Mother's Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel16 
         Height          =   375
         Left            =   240
         TabIndex        =   9
         Top             =   2520
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Birthday"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel17 
         Height          =   375
         Left            =   9360
         TabIndex        =   8
         Top             =   2520
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Section"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin VB.Label LblTitle 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Edit Student Registration Form "
      BeginProperty Font 
         Name            =   "Monotype Corsiva"
         Size            =   24
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   585
      Left            =   1320
      TabIndex        =   1
      Top             =   240
      Width           =   6075
   End
   Begin VB.Line Line1 
      X1              =   0
      X2              =   11640
      Y1              =   1200
      Y2              =   1200
   End
   Begin VB.Line Line2 
      X1              =   0
      X2              =   11640
      Y1              =   1320
      Y2              =   1320
   End
   Begin VB.Image Image1 
      Height          =   1095
      Left            =   240
      Picture         =   "frmeditreg.frx":00E2
      Stretch         =   -1  'True
      Top             =   0
      Width           =   1095
   End
End
Attribute VB_Name = "frmeditreg"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*****************
' frmeditreg code*
'*****************

Private Sub cbogl_Click()
Me.cbosection.SetFocus
End Sub

Private Sub cbogl_LostFocus()
Me.cbosection.clear
Dim rs As New ADODB.Recordset
rs.Open "select section from sec where grade_level = '" & Me.cbogl.Text & "'", con
If rs.EOF Then Exit Sub
rs.MoveFirst
    Do While Not rs.EOF
        Me.cbosection.AddItem rs!Section
        rs.MoveNext
    Loop
    rs.Close
End Sub

Private Sub cbosection_Click()
Me.txtfcpno.SetFocus
End Sub

Private Sub cbosy_Click()
Me.txtfn.SetFocus
End Sub

Private Sub cmdcancel_Click()
Call cleartextfields
unlocked
disabletextfields
Me.txtstudno.SetFocus
Me.cmdsave.Enabled = False
Me.cmdcancel.Enabled = False
End Sub

Private Sub cmdexit_Click()
Unload Me
End Sub

Private Sub cmdsave_Click()
If Me.txtstudno.Text = "" Then
    MsgBox "Please Enter Student Number...", vbCritical, ""
    txtstudno.SetFocus
Exit Sub
End If
If Me.txtfn.Text = "" Then
    MsgBox "Please Enter Student First Name...", vbCritical, ""
    txtfn.SetFocus
Exit Sub
End If
If Me.txtadd.Text = "" Then
    MsgBox "Please Enter Student Address...", vbCritical, ""
    txtadd.SetFocus
Exit Sub
End If
If Me.txtmi.Text = "" Then
    MsgBox "Please Enter Student Middle Initial...", vbCritical, ""
    txtmi.SetFocus
Exit Sub
End If
If Me.txtln.Text = "" Then
    MsgBox "Please Enter Student Last Name...", vbCritical, ""
    txtlname.SetFocus
Exit Sub
End If
If Me.txtcpno.Text = "" Then
    MsgBox "Please Enter Student First Name...", vbCritical, ""
    txtcpno.SetFocus
Exit Sub
End If
If Me.txtage.Text = "" Then
    MsgBox "Please Enter Student Age...", vbCritical, ""
    txtage.SetFocus
Exit Sub
End If
If Me.cbogender.Text = "" Then
    MsgBox "Please Enter Student Gender...", vbCritical, ""
    Me.cbogender.SetFocus
Exit Sub
End If
If Me.cbogl.Text = "" Then
    MsgBox "Please Enter Student Grade Level...", vbCritical, ""
    Me.cbogl.SetFocus
Exit Sub
End If
If IsNumeric(txtage.Text) = False Then
    MsgBox "Only number required on this field...", vbCritical, ""
    txtage.SetFocus
Exit Sub
End If
If Me.cbosy.Text = "" Then
    MsgBox "Please Enter School Year...", vbCritical, ""
    cbosy.SetFocus
Exit Sub
End If
If Me.txtfname.Text = "" Then
    MsgBox "Please Enter Student Father's Name...", vbCritical + vbOKOnly, ""
    Me.txtfname.SetFocus
Exit Sub
End If
If Me.txtmname.Text = "" Then
    MsgBox "Please Enter Student Mother's Name...", vbCritical + vbOKOnly, ""
    Me.txtmname.SetFocus
Exit Sub
End If
If Me.txtfcpno.Text = "" Then
    MsgBox "Please Enter Student Father's Contact Number...", vbCritical + vbOKOnly, ""
    Me.txtfcpno.SetFocus
Exit Sub
End If
If Me.txtmcpno.Text = "" Then
    MsgBox "Please Enter Student Mother's Contact Number...", vbCritical + vbOKOnly, ""
    Me.txtmcpno.SetFocus
Exit Sub
End If
act
save
Me.txtstudno.SetFocus
End Sub

Private Sub dtpdateofbirth_Change()
Me.Text1.Text = Me.dtpdateofbirth.Year
Me.Text2.Text = Me.dtpdateofbirth.Month
Me.Text3.Text = Me.dtpdateofbirth.Day


If (Me.Text2.Text < Month(Now)) Or (Me.Text1.Text = Year(Now)) And (Me.Text3.Text < Day(Now)) Then
    Me.txtage.Text = (Year(Now) - Me.Text1.Text) - 1
    Exit Sub
Else
    Me.txtage.Text = Year(Now) - Me.Text1.Text
    Exit Sub
End If
End Sub

Private Sub Form_Activate()
Me.txtstudno.SetFocus
End Sub

Private Sub Form_Load()
Dim i As Integer
Call OpenConnection
disabletextfields
For i = 1 To rsSCHOOLYEAR.RecordCount 'count all records
cbosy.AddItem rsSCHOOLYEAR.Fields(0) 'adding all the records  from the category table
rsSCHOOLYEAR.MoveNext 'move to next record
Next i
cmdsave.Enabled = False
cmdcancel.Enabled = False
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim a As Integer
If cmdsave.Enabled = True Then
    a = MsgBox("Are you sure you want to quit this form with out saving?", vbYesNo + vbQuestion, "")
        If a = vbYes Then
            Call CloseConnection
            Unload Me
        Else
            Cancel = 1
            End If
Else
    Call CloseConnection
    Unload Me
End If
End Sub

Sub enabletextfields()
txtfn.Enabled = True
txtage.Enabled = True
txtadd.Enabled = True
txtcpno.Enabled = True
cbogender.Enabled = True
cbogl.Enabled = True
cbosection.Enabled = True
cbosy.Enabled = True
cmdsave.Enabled = True
cmdcancel.Enabled = True
Me.dtpdateofbirth.Enabled = True
txtfcpno.Enabled = True
txtmcpno.Enabled = True
End Sub

Sub disabletextfields()
txtfn.Enabled = False
txtage.Enabled = False
txtadd.Enabled = False
txtcpno.Enabled = False
txtfcpno.Enabled = False
txtmcpno.Enabled = False
cbogender.Enabled = False
cbogl.Enabled = False
cbosy.Enabled = False
cmdsave.Enabled = True
cbosection.Enabled = False
cmdcancel.Enabled = True
Me.dtpdateofbirth.Enabled = False
End Sub

Sub cleartextfields()
Dim strMask As String
strMask = Me.txtcpno.Mask
strMask = Me.txtmcpno.Mask
strMask = Me.txtfcpno.Mask

txtstudno.Text = ""
txtfn.Text = ""
txtage.Text = ""
txtadd.Text = ""
txtcpno.Mask = ""
txtcpno.Text = ""
txtfname.Text = ""
txtfcpno.Mask = ""
txtfcpno.Text = ""
txtmname.Text = ""
txtmcpno.Mask = ""
txtmcpno.Text = ""
txtln.Text = ""
txtmi.Text = ""
Me.Text5.Text = ""
Me.Text6.Text = ""
cbogender.ListIndex = -1
cbogl.ListIndex = -1
cbosy.ListIndex = -1
cbosection.ListIndex = -1
Me.txtfcpno.Mask = strMask
Me.txtmcpno.Mask = strMask
Me.txtcpno.Mask = strMask
End Sub

Private Sub txtcpno_KeyPress(KeyAscii As Integer)
If KeyAscii < 48 Or KeyAscii > 57 Then
    KeyAscii = 0
End If
End Sub

Private Sub txtfcpno_KeyPress(KeyAscii As Integer)
If KeyAscii < 48 Or KeyAscii > 57 Then
    KeyAscii = 0
End If
End Sub

Private Sub txtmcpno_KeyPress(KeyAscii As Integer)
If KeyAscii < 48 Or KeyAscii > 57 Then
    KeyAscii = 0
End If
End Sub

Private Sub txtstudno_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
    enabletextfields
If Len(Me.txtstudno.Text) <= 0 Then Exit Sub
With rsREGISTRATION
    .Find "Student_Number= '" & Trim(Me.txtstudno.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
        locked
        Me.cbosy.SetFocus
        Me.dtpdateofbirth.Enabled = True
        Me.txtstudno.Text = .Fields(0)
        Me.txtln.Text = .Fields(1)
        Me.txtfn.Text = .Fields(2)
        Me.txtmi.Text = .Fields(3)
        Me.txtage.Text = .Fields(4)
        Me.cbogender.Text = .Fields(5)
        Me.dtpdateofbirth.Value = .Fields(6)
        Me.txtadd.Text = .Fields(7)
        Me.txtcpno.Text = .Fields(8)
        Me.cbogl.Text = .Fields(9)
        Me.cbosection.Text = .Fields(10)
        Me.cbosy.Text = .Fields(11)
        Me.txtfname.Text = .Fields(12)
        Me.txtfcpno.Text = .Fields(13)
        Me.txtmname.Text = .Fields(14)
        Me.txtmcpno.Text = .Fields(15)
        
Me.Text6.Text = "Edit Student #" + Me.txtstudno.Text

With rsLOGS
.Find "logid ='" & MDIForm1.StatusBar2.Panels(6) & "'", 0, adSearchForward, 1
If Not .EOF Then
    Me.Text5.Text = .Fields(5)
End If
End With
        Else
        MsgBox "Student Information Not Exist!!!", vbCritical, ""
        cleartextfields
        disabletextfields
        cmdsave.Enabled = False
        cmdcancel.Enabled = False
        End If
End With
End If
End Sub

Public Sub locked()
Me.txtstudno.locked = True
End Sub
Public Sub unlocked()
Me.txtstudno.locked = False
End Sub

Public Sub save()
With rsREGISTRATION
    .Fields(0) = Me.txtstudno.Text
    .Fields(1) = Me.txtln.Text
    .Fields(2) = Me.txtfn.Text
    .Fields(3) = Me.txtmi.Text
    .Fields(4) = Me.txtage.Text
    .Fields(5) = Me.cbogender.Text
    .Fields(6) = Me.dtpdateofbirth.Value
    .Fields(7) = Me.txtadd.Text
    .Fields(8) = Me.txtcpno.Text
    .Fields(9) = Me.cbogl.Text
    .Fields(10) = Me.cbosection.Text
    .Fields(11) = Me.cbosy.Text
    .Fields(12) = Me.txtfname.Text
    .Fields(13) = Me.txtfcpno.Text
    .Fields(14) = Me.txtmname.Text
    .Fields(15) = Me.txtmcpno.Text
    .Fields(16) = Now
    .Update
    MsgBox "Successfully Updated!!!" & Chr(13) & Chr(13) & "Student Number and Student Name!" & Chr(13) & Chr(13) & "Student Number = " & Me.txtstudno.Text & Chr(13) & "Student Name  = " & Me.txtfn.Text, vbInformation, ""
 End With
cleartextfields
disabletextfields
Me.txtstudno.SetFocus
cmdsave.Enabled = False
cmdcancel.Enabled = False
unlocked
End Sub

Public Sub act()
With rsLOGS
    .Find "logid = '" & MDIForm1.StatusBar2.Panels(6) & "'", 0, adSearchForward, 1
If Not .EOF Then
    .Fields(5) = Me.Text5.Text + ", " + Me.Text6.Text
    .Update
End If
End With
End Sub

