VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Begin VB.Form frmunlock 
   BackColor       =   &H80000009&
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   1545
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   5745
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmunlock.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmunlock.frx":000C
   ScaleHeight     =   1545
   ScaleWidth      =   5745
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin vkUserContolsXP.vkTextBox txtunlock 
      Height          =   375
      Left            =   1920
      TabIndex        =   1
      Top             =   840
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      PassWordChar    =   "*"
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkLabel vkLabel1 
      Height          =   375
      Left            =   1680
      TabIndex        =   0
      Top             =   360
      Width           =   3855
      _ExtentX        =   6800
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Enter Password to Unlock the System"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.Image Image1 
      Height          =   1215
      Left            =   120
      Picture         =   "frmunlock.frx":208B1
      Stretch         =   -1  'True
      Top             =   120
      Width           =   1575
   End
End
Attribute VB_Name = "frmunlock"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim iLoginFailure As Integer
Private Sub Form_Activate()
Me.txtunlock.SetFocus
End Sub

Private Sub Form_Initialize()
iLoginFailure = 3
End Sub

Private Sub Form_Load()
OpenConnection
End Sub

Private Sub Form_Unload(Cancel As Integer)
CloseConnection
End Sub

Private Sub txtunlock_KeyPress(KeyAscii As Integer)
If iLoginFailure > 0 Then
If KeyAscii = 13 Then
With rsUSERLEVEL
    .MoveFirst
        While .EOF = False
            If .Fields(3) = MDIForm1.StatusBar2.Panels(2) Then
                If .Fields(4) = Me.txtunlock.Text Then
                    MsgBox "System has been unlocked!!!", vbInformation + vbOKOnly, ""
                    Unload Me
                    iLoginFailure = 3
                    Exit Sub
                Else
                    MsgBox "Invalid password!!!", vbCritical + vbOKOnly, ""
                    Me.txtunlock.Text = ""
                    iLoginFailure = iLoginFailure - 1
                    Exit Sub
                End If
            End If
    .MoveNext
        Wend
End With
End If
Else
    MsgBox "Sorry! You Have To Unlock the System Within Three Tries! ", vbCritical, ""
    MsgBox "Your Password will reset better call the admin to change your password!", vbCritical, ""
    With rsUSERLEVEL
        .Find "userid = '" & MDIForm1.StatusBar2.Panels(7) & "'", 0, adSearchForward, 1
    If .EOF = True Then
        MsgBox "employee id not exist!!!", vbCritical, ""
        Exit Sub
    Else
        .Fields(4) = "mmci"
        .Update
    End If
    End With
'CloseConnection
Unload Me
iLoginFailure = 3
MDIForm1.StatusBar1.Panels(5) = "Waiting..."
frmlogin.Show vbModal
End If
End Sub
