VERSION 5.00
Begin VB.Form frmwelcome 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   3750
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   6510
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmwelcome.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmwelcome.frx":000C
   ScaleHeight     =   3750
   ScaleWidth      =   6510
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer1 
      Left            =   120
      Top             =   4800
   End
   Begin VB.Shape Shape2 
      Height          =   3255
      Left            =   240
      Shape           =   4  'Rounded Rectangle
      Top             =   240
      Width           =   6015
   End
   Begin VB.Shape Shape1 
      Height          =   3495
      Left            =   120
      Shape           =   4  'Rounded Rectangle
      Top             =   120
      Width           =   6255
   End
   Begin VB.Image Image1 
      Height          =   1440
      Left            =   2520
      Picture         =   "frmwelcome.frx":208B1
      Stretch         =   -1  'True
      Top             =   360
      Width           =   1560
   End
   Begin VB.Label lbl2 
      BackStyle       =   0  'Transparent
      Caption         =   "Welcome to MMCI"
      BeginProperty Font 
         Name            =   "Garamond"
         Size            =   20.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1680
      TabIndex        =   2
      Top             =   1800
      Width           =   3375
   End
   Begin VB.Label l1 
      BackStyle       =   0  'Transparent
      Caption         =   "Student Information and Cashiering System"
      BeginProperty Font 
         Name            =   "Garamond"
         Size            =   15
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   480
      TabIndex        =   1
      Top             =   2280
      Width           =   6135
   End
   Begin VB.Label lbl1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "a"
      BeginProperty Font 
         Name            =   "Garamond"
         Size            =   20.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   240
      TabIndex        =   0
      Top             =   2880
      Width           =   6015
   End
End
Attribute VB_Name = "frmwelcome"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*****************
' frmwelcome code*
'*****************
Dim bhide As Boolean

Private Sub Form_Activate()
Me.Height = 0
bhide = False
Timer1.Interval = 30
End Sub

Private Sub Form_Click()
Timer1.Interval = 20
bhide = True
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Timer1.Interval = 20
bhide = True
End If
End Sub

Private Sub Timer1_Timer()
If bhide = False Then
    If Me.Height >= 3885 Then
        Me.Width = 6600
        Me.Height = 3885
        Timer1.Interval = 0
        Else
        Me.Height = Me.Height + 300
    End If
Else
 If Me.Height <= 600 Then
        Me.Width = 0
        Me.Height = 0
        Timer1.Interval = 0
        Unload Me
        Else
        Me.Height = Me.Height - 300
        DoEvents
    End If
End If
 Me.Top = (Screen.Height / 2) - (Me.Height / 2)
End Sub

