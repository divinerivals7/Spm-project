VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Begin VB.Form frmusermanual 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "User Manual"
   ClientHeight    =   9960
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   15270
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   9960
   ScaleWidth      =   15270
   StartUpPosition =   2  'CenterScreen
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   5535
      Left            =   240
      TabIndex        =   0
      Top             =   1680
      Width           =   2415
      _ExtentX        =   4260
      _ExtentY        =   9763
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   16512
      TitleColor2     =   16512
      BorderColor     =   16512
      Begin vkUserContolsXP.vkOptionButton opt 
         Height          =   375
         Left            =   120
         TabIndex        =   17
         Top             =   360
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Log In"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt13 
         Height          =   375
         Left            =   120
         TabIndex        =   15
         Top             =   5040
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Particular"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt12 
         Height          =   375
         Left            =   120
         TabIndex        =   14
         Top             =   4680
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Payment"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt11 
         Height          =   375
         Left            =   120
         TabIndex        =   13
         Top             =   4320
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Assessment"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt10 
         Height          =   375
         Left            =   120
         TabIndex        =   12
         Top             =   3960
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "School Year"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt9 
         Height          =   375
         Left            =   120
         TabIndex        =   11
         Top             =   3600
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Edit Registration Form"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt8 
         Height          =   375
         Left            =   120
         TabIndex        =   10
         Top             =   3240
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Edit Application Form"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt7 
         Height          =   375
         Left            =   120
         TabIndex        =   9
         Top             =   2880
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Registration Form"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt6 
         Height          =   375
         Left            =   120
         TabIndex        =   8
         Top             =   2520
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Application Form"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt5 
         Height          =   375
         Left            =   120
         TabIndex        =   7
         Top             =   2160
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "System Lock"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt4 
         Height          =   375
         Left            =   120
         TabIndex        =   6
         Top             =   1800
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Change Password"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt3 
         Height          =   375
         Left            =   120
         TabIndex        =   5
         Top             =   1440
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Add User"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt2 
         Height          =   375
         Left            =   120
         TabIndex        =   4
         Top             =   1080
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Student Information"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt1 
         Height          =   375
         Left            =   120
         TabIndex        =   3
         Top             =   720
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Applicant Information"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   -480
      Top             =   7440
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   8055
      Left            =   2760
      TabIndex        =   1
      Top             =   1680
      Width           =   12255
      _ExtentX        =   21616
      _ExtentY        =   14208
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   16512
      TitleColor2     =   16512
      BorderColor     =   16512
      Begin VB.PictureBox img 
         Height          =   7575
         Left            =   120
         ScaleHeight     =   7515
         ScaleWidth      =   11955
         TabIndex        =   16
         Top             =   360
         Width           =   12015
      End
   End
   Begin ComctlLib.ImageList il 
      Left            =   7560
      Top             =   360
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   800
      ImageHeight     =   500
      MaskColor       =   12632256
      _Version        =   327682
      BeginProperty Images {0713E8C2-850A-101B-AFC0-4210102A8DA7} 
         NumListImages   =   15
         BeginProperty ListImage1 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":0000
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":124FD2
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":249FA4
            Key             =   ""
         EndProperty
         BeginProperty ListImage4 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":36EF76
            Key             =   ""
         EndProperty
         BeginProperty ListImage5 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":493F48
            Key             =   ""
         EndProperty
         BeginProperty ListImage6 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":5B8F1A
            Key             =   ""
         EndProperty
         BeginProperty ListImage7 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":6DDEEC
            Key             =   ""
         EndProperty
         BeginProperty ListImage8 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":802EBE
            Key             =   ""
         EndProperty
         BeginProperty ListImage9 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":927E90
            Key             =   ""
         EndProperty
         BeginProperty ListImage10 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":A4CE62
            Key             =   ""
         EndProperty
         BeginProperty ListImage11 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":B71E34
            Key             =   ""
         EndProperty
         BeginProperty ListImage12 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":C96E06
            Key             =   ""
         EndProperty
         BeginProperty ListImage13 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":DBBDD8
            Key             =   ""
         EndProperty
         BeginProperty ListImage14 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":EE0DAA
            Key             =   ""
         EndProperty
         BeginProperty ListImage15 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmusermanual.frx":1005D7C
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Image Image1 
      Height          =   1440
      Left            =   600
      Picture         =   "frmusermanual.frx":112AD4E
      Stretch         =   -1  'True
      Top             =   120
      Width           =   1560
   End
   Begin VB.Label LblTitle 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "MMCI User Manual"
      BeginProperty Font 
         Name            =   "Monotype Corsiva"
         Size            =   26.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   645
      Left            =   2370
      TabIndex        =   2
      Top             =   480
      Width           =   4695
   End
End
Attribute VB_Name = "frmusermanual"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'********************
' frmsuermanual code*
'********************

Private Sub Form_Load()
Me.img.Picture = il.ListImages.Item(1).Picture
End Sub

Private Sub opt_Change(Value As CheckBoxConstants)
    Me.img.Picture = il.ListImages.Item(2).Picture
End Sub

Private Sub opt1_Change(Value As CheckBoxConstants)
    Me.img.Picture = il.ListImages.Item(3).Picture
End Sub

Private Sub opt10_Change(Value As CheckBoxConstants)
Me.img.Picture = il.ListImages.Item(12).Picture
End Sub

Private Sub opt11_Change(Value As CheckBoxConstants)
    Me.img.Picture = il.ListImages.Item(13).Picture
End Sub

Private Sub opt12_Change(Value As CheckBoxConstants)
    Me.img.Picture = il.ListImages.Item(14).Picture
End Sub

Private Sub opt13_Change(Value As CheckBoxConstants)
    Me.img.Picture = il.ListImages.Item(15).Picture
End Sub

Private Sub opt2_Change(Value As CheckBoxConstants)
    Me.img.Picture = il.ListImages.Item(4).Picture
End Sub

Private Sub opt3_Change(Value As CheckBoxConstants)
Me.img.Picture = il.ListImages.Item(5).Picture
End Sub

Private Sub opt4_Change(Value As CheckBoxConstants)
Me.img.Picture = il.ListImages.Item(6).Picture
End Sub

Private Sub opt5_Change(Value As CheckBoxConstants)
Me.img.Picture = il.ListImages.Item(7).Picture
End Sub

Private Sub opt6_Change(Value As CheckBoxConstants)
Me.img.Picture = il.ListImages.Item(8).Picture
End Sub

Private Sub opt7_Change(Value As CheckBoxConstants)
Me.img.Picture = il.ListImages.Item(9).Picture
End Sub

Private Sub opt8_Change(Value As CheckBoxConstants)
Me.img.Picture = il.ListImages.Item(10).Picture
End Sub

Private Sub opt9_Change(Value As CheckBoxConstants)
Me.img.Picture = il.ListImages.Item(11).Picture
End Sub
