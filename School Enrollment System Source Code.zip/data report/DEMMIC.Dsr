VERSION 5.00
Begin {C0E45035-5775-11D0-B388-00A0C9055D8E} DataEnvironment1 
   ClientHeight    =   6045
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   8265
   _ExtentX        =   14579
   _ExtentY        =   10663
   FolderFlags     =   1
   TypeLibGuid     =   "{103BD61F-A793-498C-B9FC-69A02C790AF2}"
   TypeInfoGuid    =   "{F676A6AE-4110-4438-9E77-445E71727448}"
   TypeInfoCookie  =   0
   Version         =   4
   NumConnections  =   1
   BeginProperty Connection1 
      ConnectionName  =   "Connection1"
      ConnDispId      =   1001
      SourceOfData    =   3
      ConnectionSource=   "Provider=MSDASQL.1;Persist Security Info=False;Data Source=MMIC;Initial Catalog=MMIC"
      Expanded        =   -1  'True
      IsSQL           =   -1  'True
      QuoteChar       =   34
      SeparatorChar   =   46
   EndProperty
   NumRecordsets   =   6
   BeginProperty Recordset1 
      CommandName     =   "Command1"
      CommDispId      =   1002
      RsDispId        =   1041
      CommandText     =   "dbo.REGISTRATION"
      ActiveConnectionName=   "Connection1"
      CommandType     =   2
      dbObjectType    =   1
      IsRSReturning   =   -1  'True
      NumFields       =   19
      BeginProperty Field1 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Student_Number"
         Caption         =   "Student_Number"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "LastName"
         Caption         =   "LastName"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "FirstName"
         Caption         =   "FirstName"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "MI"
         Caption         =   "MI"
      EndProperty
      BeginProperty Field5 
         Precision       =   18
         Size            =   19
         Scale           =   0
         Type            =   131
         Name            =   "Age"
         Caption         =   "Age"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Gender"
         Caption         =   "Gender"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Birthday"
         Caption         =   "Birthday"
      EndProperty
      BeginProperty Field8 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Address"
         Caption         =   "Address"
      EndProperty
      BeginProperty Field9 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Contact_Number"
         Caption         =   "Contact_Number"
      EndProperty
      BeginProperty Field10 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Grade_Level"
         Caption         =   "Grade_Level"
      EndProperty
      BeginProperty Field11 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Section"
         Caption         =   "Section"
      EndProperty
      BeginProperty Field12 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "School_Year"
         Caption         =   "School_Year"
      EndProperty
      BeginProperty Field13 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Father's_Name"
         Caption         =   "Father's_Name"
      EndProperty
      BeginProperty Field14 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Father's_Contact_No"
         Caption         =   "Father's_Contact_No"
      EndProperty
      BeginProperty Field15 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Mother's_Name"
         Caption         =   "Mother's_Name"
      EndProperty
      BeginProperty Field16 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Mother's_Contact_No"
         Caption         =   "Mother's_Contact_No"
      EndProperty
      BeginProperty Field17 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Date_Of_Registration"
         Caption         =   "Date_Of_Registration"
      EndProperty
      BeginProperty Field18 
         Precision       =   10
         Size            =   4
         Scale           =   0
         Type            =   3
         Name            =   "App_No"
         Caption         =   "App_No"
      EndProperty
      BeginProperty Field19 
         Precision       =   10
         Size            =   4
         Scale           =   0
         Type            =   3
         Name            =   "Billno"
         Caption         =   "Billno"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset2 
      CommandName     =   "Command2"
      CommDispId      =   1006
      RsDispId        =   1042
      CommandText     =   "dbo.LOGS"
      ActiveConnectionName=   "Connection1"
      CommandType     =   2
      dbObjectType    =   1
      Expanded        =   -1  'True
      IsRSReturning   =   -1  'True
      NumFields       =   6
      BeginProperty Field1 
         Precision       =   18
         Size            =   19
         Scale           =   0
         Type            =   131
         Name            =   "logid"
         Caption         =   "logid"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Username"
         Caption         =   "Username"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Userlevel"
         Caption         =   "Userlevel"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Logintime"
         Caption         =   "Logintime"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Logouttime"
         Caption         =   "Logouttime"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   100
         Scale           =   0
         Type            =   200
         Name            =   "Activity"
         Caption         =   "Activity"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset3 
      CommandName     =   "Command3"
      CommDispId      =   1025
      RsDispId        =   1050
      CommandText     =   "dbo.BILLING"
      ActiveConnectionName=   "Connection1"
      CommandType     =   2
      dbObjectType    =   1
      IsRSReturning   =   -1  'True
      NumFields       =   13
      BeginProperty Field1 
         Precision       =   10
         Size            =   19
         Scale           =   0
         Type            =   131
         Name            =   "Billno"
         Caption         =   "Billno"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Student_Number"
         Caption         =   "Student_Number"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Full_Name"
         Caption         =   "Full_Name"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Grade_Level"
         Caption         =   "Grade_Level"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Section"
         Caption         =   "Section"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "School_Year"
         Caption         =   "School_Year"
      EndProperty
      BeginProperty Field7 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   20
         Name            =   "Student_Charge"
         Caption         =   "Student_Charge"
      EndProperty
      BeginProperty Field8 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   20
         Name            =   "Student_Current_Payment"
         Caption         =   "Student_Current_Payment"
      EndProperty
      BeginProperty Field9 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   20
         Name            =   "Student_Balance"
         Caption         =   "Student_Balance"
      EndProperty
      BeginProperty Field10 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Student_DateofPayment"
         Caption         =   "Student_DateofPayment"
      EndProperty
      BeginProperty Field11 
         Precision       =   10
         Size            =   4
         Scale           =   0
         Type            =   3
         Name            =   "Assess_No"
         Caption         =   "Assess_No"
      EndProperty
      BeginProperty Field12 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "discount"
         Caption         =   "discount"
      EndProperty
      BeginProperty Field13 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Received_By"
         Caption         =   "Received_By"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset4 
      CommandName     =   "Command4"
      CommDispId      =   1029
      RsDispId        =   1044
      CommandText     =   "dbo.ASSESSMENT"
      ActiveConnectionName=   "Connection1"
      CommandType     =   2
      dbObjectType    =   1
      IsRSReturning   =   -1  'True
      NumFields       =   7
      BeginProperty Field1 
         Precision       =   19
         Size            =   19
         Scale           =   0
         Type            =   131
         Name            =   "Assess_No"
         Caption         =   "Assess_No"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Student_Number"
         Caption         =   "Student_Number"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Student_Name"
         Caption         =   "Student_Name"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Grade_Level"
         Caption         =   "Grade_Level"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "School_Year"
         Caption         =   "School_Year"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Total_Fee"
         Caption         =   "Total_Fee"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Date_Of_Assessment"
         Caption         =   "Date_Of_Assessment"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset5 
      CommandName     =   "Command5"
      CommDispId      =   1033
      RsDispId        =   1045
      CommandText     =   "dbo.APPLICATION"
      ActiveConnectionName=   "Connection1"
      CommandType     =   2
      dbObjectType    =   1
      IsRSReturning   =   -1  'True
      NumFields       =   24
      BeginProperty Field1 
         Precision       =   18
         Size            =   19
         Scale           =   0
         Type            =   131
         Name            =   "App_No"
         Caption         =   "App_No"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Regular_School"
         Caption         =   "Regular_School"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Lastname"
         Caption         =   "Lastname"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Firstname"
         Caption         =   "Firstname"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "MI"
         Caption         =   "MI"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Age"
         Caption         =   "Age"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Gender"
         Caption         =   "Gender"
      EndProperty
      BeginProperty Field8 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Religion"
         Caption         =   "Religion"
      EndProperty
      BeginProperty Field9 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Date_Of_Birth"
         Caption         =   "Date_Of_Birth"
      EndProperty
      BeginProperty Field10 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Place_Of_Birth"
         Caption         =   "Place_Of_Birth"
      EndProperty
      BeginProperty Field11 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Address"
         Caption         =   "Address"
      EndProperty
      BeginProperty Field12 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Contact_Number"
         Caption         =   "Contact_Number"
      EndProperty
      BeginProperty Field13 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Previous_Schooling"
         Caption         =   "Previous_Schooling"
      EndProperty
      BeginProperty Field14 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Fathers_Name"
         Caption         =   "Fathers_Name"
      EndProperty
      BeginProperty Field15 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Fathers_Occupation"
         Caption         =   "Fathers_Occupation"
      EndProperty
      BeginProperty Field16 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Fathers_Office_Name"
         Caption         =   "Fathers_Office_Name"
      EndProperty
      BeginProperty Field17 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Fathers_Office_Contact_Number"
         Caption         =   "Fathers_Office_Contact_Number"
      EndProperty
      BeginProperty Field18 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Fathers_Office_Address"
         Caption         =   "Fathers_Office_Address"
      EndProperty
      BeginProperty Field19 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Mothers_Name"
         Caption         =   "Mothers_Name"
      EndProperty
      BeginProperty Field20 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Mothers_Occupation"
         Caption         =   "Mothers_Occupation"
      EndProperty
      BeginProperty Field21 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Mothers_Office_Name"
         Caption         =   "Mothers_Office_Name"
      EndProperty
      BeginProperty Field22 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Mothers_Office_Contact_Number"
         Caption         =   "Mothers_Office_Contact_Number"
      EndProperty
      BeginProperty Field23 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Mothers_Office_Address"
         Caption         =   "Mothers_Office_Address"
      EndProperty
      BeginProperty Field24 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "Date_Of_Application"
         Caption         =   "Date_Of_Application"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset6 
      CommandName     =   "Command6"
      CommDispId      =   1037
      RsDispId        =   1046
      CommandText     =   "dbo.ID"
      ActiveConnectionName=   "Connection1"
      CommandType     =   2
      dbObjectType    =   1
      IsRSReturning   =   -1  'True
      NumFields       =   1
      BeginProperty Field1 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "ID"
         Caption         =   "ID"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
End
Attribute VB_Name = "DataEnvironment1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
