VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Begin VB.Form frmviewpaymentrecords 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "View Payment Records"
   ClientHeight    =   7980
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   9570
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   7980
   ScaleWidth      =   9570
   StartUpPosition =   2  'CenterScreen
   Begin vkUserContolsXP.vkCommand cmdprint 
      Height          =   495
      Left            =   7800
      TabIndex        =   20
      Top             =   7320
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   873
      Caption         =   "&Print"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin MSAdodcLib.Adodc adobilling 
      Height          =   375
      Left            =   6480
      Top             =   360
      Visible         =   0   'False
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   661
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   2
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   3
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   "DSN=MMIC"
      OLEDBString     =   ""
      OLEDBFile       =   ""
      DataSourceName  =   "MMIC"
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   "BILLING"
      Caption         =   "Adodc1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin vkUserContolsXP.vkLabel vkLabel1 
      Height          =   375
      Left            =   240
      TabIndex        =   4
      Top             =   240
      Width           =   1095
      _ExtentX        =   1931
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Seacrh by"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.ComboBox cbosearch 
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      ItemData        =   "frmviewpaymentrecords.frx":0000
      Left            =   1440
      List            =   "frmviewpaymentrecords.frx":000A
      Style           =   2  'Dropdown List
      TabIndex        =   3
      Top             =   240
      Width           =   1815
   End
   Begin vkUserContolsXP.vkTextBox txtsearch 
      Height          =   375
      Left            =   3360
      TabIndex        =   2
      Top             =   240
      Width           =   2295
      _ExtentX        =   4048
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      LegendForeColor =   14117668
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   9600
      Top             =   -600
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame3 
      Height          =   3255
      Left            =   240
      TabIndex        =   0
      Top             =   840
      Width           =   9135
      _ExtentX        =   16113
      _ExtentY        =   5741
      Caption         =   "Payment Records"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin MSDataGridLib.DataGrid dtgbilling 
         Bindings        =   "frmviewpaymentrecords.frx":0025
         Height          =   2775
         Left            =   120
         TabIndex        =   1
         Top             =   360
         Width           =   8895
         _ExtentX        =   15690
         _ExtentY        =   4895
         _Version        =   393216
         BackColor       =   12640511
         HeadLines       =   1
         RowHeight       =   24
         BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ColumnCount     =   2
         BeginProperty Column00 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         BeginProperty Column01 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         SplitCount      =   1
         BeginProperty Split0 
            BeginProperty Column00 
            EndProperty
            BeginProperty Column01 
            EndProperty
         EndProperty
      End
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   3015
      Left            =   240
      TabIndex        =   5
      Top             =   4200
      Width           =   9135
      _ExtentX        =   16113
      _ExtentY        =   5318
      Caption         =   "Student Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkLabel vkLabel6 
         Height          =   375
         Left            =   240
         TabIndex        =   19
         Top             =   1920
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Section"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtsection 
         Height          =   375
         Left            =   1920
         TabIndex        =   18
         Top             =   1920
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin MSMask.MaskEdBox msktb 
         Height          =   375
         Left            =   7200
         TabIndex        =   17
         Top             =   960
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Format          =   "P #,##0.00;($#,##0.00)"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox msktc 
         Height          =   375
         Left            =   7200
         TabIndex        =   16
         Top             =   480
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Format          =   "P #,##0.00;($#,##0.00)"
         PromptChar      =   "_"
      End
      Begin vkUserContolsXP.vkLabel vkLabel9 
         Height          =   375
         Left            =   5760
         TabIndex        =   15
         Top             =   960
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Total Balance"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel7 
         Height          =   375
         Left            =   5760
         TabIndex        =   14
         Top             =   480
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Total Charges"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtgl 
         Height          =   375
         Left            =   1920
         TabIndex        =   13
         Top             =   1440
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel5 
         Height          =   375
         Left            =   240
         TabIndex        =   12
         Top             =   1440
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Grade Level"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtfn 
         Height          =   375
         Left            =   1920
         TabIndex        =   11
         Top             =   960
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   4210816
      End
      Begin vkUserContolsXP.vkLabel vkLabel4 
         Height          =   375
         Left            =   240
         TabIndex        =   10
         Top             =   960
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Student Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtstudno 
         Height          =   375
         Left            =   1920
         TabIndex        =   9
         Top             =   480
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel2 
         Height          =   375
         Left            =   240
         TabIndex        =   8
         Top             =   480
         Width           =   1575
         _ExtentX        =   2778
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Student Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtsy 
         Height          =   375
         Left            =   1920
         TabIndex        =   7
         Top             =   2400
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel3 
         Height          =   375
         Left            =   240
         TabIndex        =   6
         Top             =   2400
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "School Year"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
End
Attribute VB_Name = "frmviewpaymentrecords"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'****************************
' frmviewpaymentrecords code*
'****************************
Private Sub cbosearch_Click()
Me.txtsearch.SetFocus
End Sub
Private Sub cmdprint_Click()
CloseConnection
Set Me.dtgbilling.DataSource = Me.adobilling.Recordset
dbgrid
frmbyacc.Show vbModal
End Sub

Private Sub dtgbilling_Click()
With adobilling.Recordset
    If .RecordCount < 1 Then MsgBox "No Data Selected", vbExclamation, "": Exit Sub
        Me.txtstudno.Text = dtgbilling.Columns(1)
        Me.txtfn.Text = dtgbilling.Columns(2)
        Me.txtgl.Text = dtgbilling.Columns(3)
        Me.txtsection.Text = dtgbilling.Columns(4)
        Me.txtsy.Text = dtgbilling.Columns(5)
        Me.msktc.Text = dtgbilling.Columns(6)
        Me.msktb.Text = dtgbilling.Columns(8)
        dbgrid
End With
End Sub

Private Sub Form_Activate()
OpenConnection
Me.cbosearch.SetFocus
End Sub

Private Sub Form_Load()
dbgrid
End Sub

Private Sub Form_Unload(Cancel As Integer)
CloseConnection
End Sub

Private Sub txtsearch_Change()
If Me.txtsearch.Text = "" Then
clear
Set dtgbilling.DataSource = rsBILLING
dbgrid
Exit Sub
End If

Dim rs As New ADODB.Recordset

If Me.cbosearch.Text = "Student_ID" Then
    rs.Open "select * from billing where Student_Number like '" & Trim(txtsearch.Text) & "%'", con, adOpenKeyset, adLockOptimistic
    Set dtgbilling.DataSource = rs
    searchid
    dbgrid
ElseIf Me.cbosearch.Text = "Full_Name" Then
    rs.Open "select * from billing where Full_Name like '" & Trim(txtsearch.Text) & "%'", con, adOpenKeyset, adLockOptimistic
    Set dtgbilling.DataSource = rs
    searchname
    dbgrid
End If
End Sub

Public Sub dbgrid()
dtgbilling.Columns(0).Width = 0
dtgbilling.Columns(1).Width = 1700
dtgbilling.Columns(2).Width = 3000
dtgbilling.Columns(3).Width = 1700
dtgbilling.Columns(4).Width = 1700
dtgbilling.Columns(5).Width = 1900
dtgbilling.Columns(6).Width = 2100
dtgbilling.Columns(7).Width = 1900
dtgbilling.Columns(8).Width = 2100
End Sub

Public Sub searchid()
With rsBILLING
.MoveFirst
    While .EOF = False
    If .Fields(1) = Me.txtsearch.Text Then
        Me.txtstudno.Text = dtgbilling.Columns(1)
        Me.txtfn.Text = dtgbilling.Columns(2)
        Me.txtgl.Text = dtgbilling.Columns(3)
        Me.txtsection.Text = dtgbilling.Columns(4)
        Me.txtsy.Text = dtgbilling.Columns(5)
        Me.msktc.Text = dtgbilling.Columns(6)
        Me.msktb.Text = dtgbilling.Columns(8)
        dbgrid
        Exit Sub
    Else
        clear
    End If
    .MoveNext
Wend
End With
End Sub

Public Sub clear()
Me.txtstudno.Text = ""
Me.txtfn.Text = ""
Me.txtgl.Text = ""
Me.txtsy.Text = ""
Me.msktc.Text = ""
Me.msktb.Text = ""
Me.txtsection.Text = ""
End Sub
Public Sub searchname()
With rsBILLING
.MoveFirst
    While .EOF = False
    If .Fields(2) = Me.txtsearch.Text Then
        Me.txtstudno.Text = dtgbilling.Columns(1)
        Me.txtfn.Text = dtgbilling.Columns(2)
        Me.txtgl.Text = dtgbilling.Columns(3)
        Me.txtsection.Text = dtgbilling.Columns(4)
        Me.txtsy.Text = dtgbilling.Columns(5)
        Me.msktc.Text = dtgbilling.Columns(6)
        Me.msktb.Text = dtgbilling.Columns(8)
        dbgrid
        Exit Sub
    Else
        clear
    End If
    .MoveNext
Wend
End With
End Sub

