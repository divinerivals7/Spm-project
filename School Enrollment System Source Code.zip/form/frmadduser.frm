VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Begin VB.Form frmadduser 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Add User"
   ClientHeight    =   5235
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   7260
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5235
   ScaleWidth      =   7260
   StartUpPosition =   2  'CenterScreen
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   495
      Left            =   4440
      TabIndex        =   9
      Top             =   4440
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   873
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   -240
      Top             =   5640
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   3855
      Left            =   240
      TabIndex        =   0
      Top             =   360
      Width           =   6735
      _ExtentX        =   11880
      _ExtentY        =   6800
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkLabel vkLabel4 
         Height          =   375
         Left            =   360
         TabIndex        =   13
         Top             =   480
         Width           =   1575
         _ExtentX        =   2778
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Emp Id"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtid 
         Height          =   375
         Left            =   1560
         TabIndex        =   12
         Top             =   480
         Width           =   1575
         _ExtentX        =   2778
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtpassword 
         Height          =   375
         Left            =   1560
         TabIndex        =   8
         Top             =   3120
         Width           =   4935
         _ExtentX        =   8705
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         PassWordChar    =   "*"
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel ads 
         Height          =   255
         Left            =   360
         TabIndex        =   7
         Top             =   3120
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   450
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Password"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtusername 
         Height          =   375
         Left            =   1560
         TabIndex        =   6
         Top             =   2400
         Width           =   4935
         _ExtentX        =   8705
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel3 
         Height          =   375
         Left            =   360
         TabIndex        =   5
         Top             =   2400
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Username"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.ComboBox cbouserlevel 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmadduser.frx":0000
         Left            =   1560
         List            =   "frmadduser.frx":000D
         Style           =   2  'Dropdown List
         TabIndex        =   4
         Top             =   1680
         Width           =   3495
      End
      Begin vkUserContolsXP.vkLabel vkLabel2 
         Height          =   255
         Left            =   360
         TabIndex        =   3
         Top             =   1680
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   450
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "User Level"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtfullname 
         Height          =   375
         Left            =   1560
         TabIndex        =   2
         Top             =   1080
         Width           =   4935
         _ExtentX        =   8705
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel1 
         Height          =   255
         Left            =   360
         TabIndex        =   1
         Top             =   1080
         Width           =   1575
         _ExtentX        =   2778
         _ExtentY        =   450
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Full Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin vkUserContolsXP.vkCommand cmdcancel 
      Height          =   495
      Left            =   5760
      TabIndex        =   10
      Top             =   4440
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   873
      Caption         =   "&Clear"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmdadd 
      Height          =   495
      Left            =   3120
      TabIndex        =   11
      Top             =   4440
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   873
      Caption         =   "&Add"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmadduser"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'****************
'frmadduser code*
'****************
Private Sub cbouserlevel_Click()
Me.txtusername.SetFocus
End Sub

Private Sub cmdadd_Click()
enable
temp = rsUSERLEVEL.RecordCount + 1 'count all records then +1
Me.txtid.Text = "Emp-" & temp 'this will serve as the student number of the student
Me.txtfullname.SetFocus
End Sub

Private Sub cmdcancel_Click()
clear
End Sub

Private Sub cmdsave_Click()
If Me.txtfullname.Text = "" Then
    MsgBox "Please Enter Full Name!!", vbCritical, ""
    Me.txtfullname.SetFocus
    Exit Sub
End If
If Me.txtusername.Text = "" Then
    MsgBox "Please Enter Username!!", vbCritical, ""
    txtusername.SetFocus
    Exit Sub
End If
If Me.txtpassword.Text = "" Then
    MsgBox "Please Enter Password!!", vbCritical, ""
    txtpassword.SetFocus
    Exit Sub
End If
If Me.cbouserlevel.Text = "" Then
    MsgBox "Please Enter User Level", vbCritical, ""
    cbouserlevel.SetFocus
    Exit Sub
End If

If Len(Me.txtusername.Text) < 5 Then
    MsgBox "Minimum of 5 characters for username", vbCritical, ""
    Me.txtusername.SetFocus
    Exit Sub
End If

If Len(Me.txtpassword.Text) < 5 Then
    MsgBox "Minimum of 5 characters for password", vbCritical, ""
    Me.txtpassword.SetFocus
    Exit Sub
End If

With rsUSERLEVEL
    .AddNew
    .Fields(0) = Me.txtid.Text
    .Fields(1) = Me.txtfullname.Text
    .Fields(2) = Me.cbouserlevel.Text
    .Fields(3) = Me.txtusername.Text
    .Fields(4) = Me.txtpassword.Text
    .Update
    MsgBox "Successfully Saved!!", vbInformation + vbOKOnly, ""
 End With
clear
disable
End Sub

Private Sub Form_Load()
OpenConnection
disable
End Sub
Public Sub disable()
Me.cbouserlevel.Enabled = False
Me.txtfullname.Enabled = False
Me.txtusername.Enabled = False
cmdsave.Enabled = False
cmdcancel.Enabled = False
End Sub
Public Sub enable()
Me.cbouserlevel.Enabled = True
Me.txtfullname.Enabled = True
Me.txtusername.Enabled = True
Me.txtpassword.Enabled = True
cmdsave.Enabled = True
cmdcancel.Enabled = True
End Sub
Public Sub clear()
Me.cbouserlevel.ListIndex = -1
Me.txtfullname.Text = ""
Me.txtid.Text = ""
Me.txtusername.Text = ""
Me.txtpassword.Text = ""
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim a As Integer
If cmdsave.Enabled = True Then
    a = MsgBox("Are you sure you want to quit this form with out saving?", vbYesNo + vbQuestion, "")
        If a = vbYes Then
            Call CloseConnection
            Unload Me
        Else
            Cancel = 1
            End If
Else
    Call CloseConnection
    Unload Me
End If
End Sub

Private Sub txtfullname_KeyPress(KeyAscii As Integer)
If Chr(KeyAscii) Like "[0-9]" And KeyAscii <> 8 Then KeyAscii = 0
End Sub
