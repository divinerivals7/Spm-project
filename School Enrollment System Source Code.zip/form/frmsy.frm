VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Begin VB.Form frmsy 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "School Year"
   ClientHeight    =   6600
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4665
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6600
   ScaleWidth      =   4665
   StartUpPosition =   1  'CenterOwner
   Begin VB.TextBox Text2 
      Height          =   495
      Left            =   5400
      TabIndex        =   9
      Text            =   "Text2"
      Top             =   2040
      Width           =   1335
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   5400
      TabIndex        =   6
      Text            =   "Text1"
      Top             =   1680
      Visible         =   0   'False
      Width           =   975
   End
   Begin MSAdodcLib.Adodc Adosy 
      Height          =   330
      Left            =   3720
      Top             =   0
      Visible         =   0   'False
      Width           =   1200
      _ExtentX        =   2117
      _ExtentY        =   582
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   2
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   3
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   "DSN=MMIC"
      OLEDBString     =   ""
      OLEDBFile       =   ""
      DataSourceName  =   "MMIC"
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   "SCHOOLYEAR"
      Caption         =   "Adosy"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   -360
      Top             =   -480
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   4215
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   4215
      _ExtentX        =   7435
      _ExtentY        =   7435
      Caption         =   "School Year"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin MSDataGridLib.DataGrid dtgsy 
         Bindings        =   "frmsy.frx":0000
         Height          =   3495
         Left            =   240
         TabIndex        =   1
         Top             =   480
         Width           =   3735
         _ExtentX        =   6588
         _ExtentY        =   6165
         _Version        =   393216
         BackColor       =   12640511
         HeadLines       =   1
         RowHeight       =   24
         BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ColumnCount     =   2
         BeginProperty Column00 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         BeginProperty Column01 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         SplitCount      =   1
         BeginProperty Split0 
            BeginProperty Column00 
            EndProperty
            BeginProperty Column01 
            EndProperty
         EndProperty
      End
   End
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   1215
      Left            =   240
      TabIndex        =   2
      Top             =   4560
      Width           =   4215
      _ExtentX        =   7435
      _ExtentY        =   2143
      Caption         =   "School Year From"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkTextBox txt2 
         Height          =   495
         Left            =   2280
         TabIndex        =   4
         Top             =   480
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   873
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Alignment       =   2
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txt1 
         Height          =   495
         Left            =   240
         TabIndex        =   3
         Top             =   480
         Width           =   1575
         _ExtentX        =   2778
         _ExtentY        =   873
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Alignment       =   2
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin VB.Line Line1 
         BorderWidth     =   2
         X1              =   1920
         X2              =   2160
         Y1              =   720
         Y2              =   720
      End
   End
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   495
      Left            =   1680
      TabIndex        =   5
      Top             =   5880
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmdadd 
      Height          =   495
      Left            =   240
      TabIndex        =   7
      Top             =   5880
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Add"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmddelete 
      Height          =   495
      Left            =   3120
      TabIndex        =   8
      Top             =   5880
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Delete"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmsy"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'************
' frmsy code*
'************
Private Sub cmdadd_Click()
enablefield
Me.txt1.SetFocus
End Sub

Private Sub cmddelete_Click()
With rsREGISTRATION
    .Find "School_Year= '" & Trim(Me.Text2.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
     MsgBox "Cannot delete the selected school year!!!", vbCritical, ""
Exit Sub
End If
End With
If Adosy.Recordset.RecordCount = 0 Then
    MsgBox "Database empty", vbInformation, "Delete Record"
    cmddelete.Enabled = False
Exit Sub
End If
If MsgBox("Are you sure you want to delete this record?", vbQuestion + vbYesNo, "") = vbYes Then
    Adosy.Recordset.Delete
    MsgBox "Record Deleted", vbInformation + vbOKOnly, ""
    clearfield
End If
End Sub

Private Sub dtgsy_Click()
With Me.Adosy.Recordset
    If .RecordCount < 1 Then MsgBox "No Data Selected", vbExclamation: Exit Sub
End With
cmddelete.Enabled = True
dtgsy.MarqueeStyle = dbgHighlightRow
Me.Text2.Text = dtgsy.Columns(0)
End Sub

Private Sub dtgsy_HeadClick(ByVal ColIndex As Integer)
With Adosy.Recordset
    If (.Sort = .Fields(ColIndex).[Name] & " Asc") Then
        .Sort = .Fields(ColIndex).[Name] & " Desc"
    Else
        .Sort = .Fields(ColIndex).[Name] & " Asc"
    End If
End With
End Sub

Private Sub Form_Load()
Call OpenConnection
disablefield
cmdsave.Enabled = False
cmddelete.Enabled = False
'db
End Sub

Private Sub Form_Unload(Cancel As Integer)
Unload Me
CloseConnection
End Sub
Private Sub cmdcancel_Click()
clearfield
End Sub

Private Sub cmdsave_Click()
If Len(Me.txt1.Text) <> 4 Then Exit Sub
With Adosy.Recordset
    .Find "School_Year='" & Trim(Me.txt1.Text & " - " & Me.txt2.Text) & "'", 0, adSearchForward, 1
    If .EOF <> True Then
    MsgBox "School Year already exist!", vbInformation, "Save School Year"
    Me.txt1.SetFocus
    Exit Sub
Else
    .AddNew
    .Fields(0) = Me.txt1.Text & " - " & Me.txt2.Text
    .Update
     MsgBox "School Year = " & Me.txt1.Text & " - " & Me.txt2.Text, vbInformation + vbOKOnly, ""
    End If
 End With
clearfield
disablefield
End Sub

Private Sub Form_Activate()
Me.txt1.SetFocus
End Sub

Private Sub clearfield()
txt1.Text = ""
txt2.Text = ""
Text1.Text = ""
End Sub
Private Sub disablefield()
txt1.Enabled = False
txt2.Enabled = False
cmdsave.Enabled = False
End Sub
Private Sub enablefield()
txt1.Enabled = True
txt2.Enabled = True
cmdsave.Enabled = True
End Sub

Private Sub txt1_Change()
Dim a As String
a = (Val(Me.txt1.Text)) + (Val(1))
Me.txt2.Text = a
End Sub
Private Sub txt1_KeyPress(KeyAscii As Integer)
If KeyAscii < 48 Or KeyAscii > 57 Then
    KeyAscii = 0
End If
End Sub
