VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Begin VB.Form frmlogin 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   3840
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   5550
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmLogin.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmLogin.frx":000C
   ScaleHeight     =   3840
   ScaleWidth      =   5550
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.ComboBox cbousername 
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      Left            =   2040
      Style           =   2  'Dropdown List
      TabIndex        =   7
      Top             =   1560
      Width           =   2895
   End
   Begin VB.Timer T1 
      Interval        =   80
      Left            =   1680
      Top             =   4995
   End
   Begin VB.Timer Timer1 
      Interval        =   900
      Left            =   5520
      Top             =   4995
   End
   Begin VB.Timer Timer2 
      Interval        =   900
      Left            =   3855
      Top             =   5010
   End
   Begin VB.Timer Timer4 
      Interval        =   900
      Left            =   6690
      Top             =   5025
   End
   Begin vkUserContolsXP.vkCommand cmdOK 
      Height          =   495
      Left            =   2160
      TabIndex        =   0
      Top             =   2760
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&OK"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmdexit 
      Height          =   495
      Left            =   3600
      TabIndex        =   1
      Top             =   2760
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&EXIT"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkTextBox txtPassword 
      Height          =   375
      Left            =   2040
      TabIndex        =   6
      Top             =   2160
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      PassWordChar    =   "*"
      LegendForeColor =   14117668
   End
   Begin VB.Shape Shape1 
      Height          =   3375
      Left            =   240
      Shape           =   4  'Rounded Rectangle
      Top             =   240
      Width           =   5055
   End
   Begin VB.Image Image2 
      Height          =   1095
      Left            =   240
      Picture         =   "frmLogin.frx":208B1
      Stretch         =   -1  'True
      Top             =   480
      Width           =   1095
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackColor       =   &H000000FF&
      BackStyle       =   0  'Transparent
      Caption         =   "USER NAME:"
      BeginProperty Font 
         Name            =   "Garamond"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00400000&
      Height          =   195
      Left            =   600
      TabIndex        =   5
      Top             =   1680
      Width           =   1155
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      BackColor       =   &H000000FF&
      BackStyle       =   0  'Transparent
      Caption         =   "PASSWORD:"
      BeginProperty Font 
         Name            =   "Garamond"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00400000&
      Height          =   195
      Index           =   1
      Left            =   600
      TabIndex        =   4
      Top             =   2280
      Width           =   1020
   End
   Begin VB.Label LblTitle 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Molina Montessori Center, Inc"
      BeginProperty Font 
         Name            =   "Garamond"
         Size            =   15.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00400000&
      Height          =   360
      Left            =   480
      TabIndex        =   3
      Top             =   480
      Width           =   5295
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "San Marcos, Calumpit Bulacan"
      BeginProperty Font 
         Name            =   "Garamond"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00400000&
      Height          =   270
      Left            =   1800
      TabIndex        =   2
      Top             =   840
      Width           =   3210
   End
   Begin VB.Shape Shape2 
      Height          =   3615
      Left            =   120
      Shape           =   4  'Rounded Rectangle
      Top             =   120
      Width           =   5295
   End
End
Attribute VB_Name = "frmlogin"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'**************
' Log In Code *
'**************
Dim iLoginFailure As Integer
Private Sub cmdcancel_Click()
Unload Me
frmchooselogin.Show vbModal
End Sub

Private Sub cbousername_Click()
Me.txtpassword.SetFocus
End Sub

Private Sub cmdexit_Click()
Dim a As Integer
a = MsgBox("Do you want to exit the MMCI Student Information and Cashiering?", vbYesNo + vbQuestion, "")
If a = vbYes Then
 MsgBox "Program Terminated!!!", vbExclamation, ""
 End
 MDIForm1.Hide
 Exit Sub
Else
 Cancel = 1
 End If
End Sub

Private Sub cmdok_Click()
If iLoginFailure > 0 Then
With rsUSERLEVEL
    .MoveFirst
        While .EOF = False
            If .Fields(3) = Me.cbousername.Text Then
                If .Fields(4) = Me.txtpassword.Text Then
                    If .Fields(2) = "administrator" Then
                        MDIForm1.StatusBar1.Panels(5) = "Admin - " & cbousername.Text 'display user in panel 5
                        MDIForm1.StatusBar1.Panels(1) = .Fields(2)
                        MDIForm1.StatusBar2.Panels(1) = Me.txtpassword.Text 'display password in panel 1
                        MDIForm1.StatusBar2.Panels(2) = Me.cbousername.Text 'display password in panel 2
                        MDIForm1.StatusBar2.Panels(5) = "A"
                        MDIForm1.StatusBar2.Panels(7) = .Fields(0)
                        iLoginFailure = 3
                        MDIForm1.admin
                        login
                        CloseConnection
                        Unload Me
                        splash
                        Exit Sub
                    ElseIf .Fields(2) = "accountant" Then
                        MDIForm1.StatusBar1.Panels(5) = "Accountant - " & cbousername.Text 'display user in panel 5
                        MDIForm1.StatusBar1.Panels(1) = .Fields(2)
                        MDIForm1.StatusBar2.Panels(1) = Me.txtpassword.Text 'display password in panel 3
                        MDIForm1.StatusBar2.Panels(2) = Me.cbousername.Text 'display password in panel 3
                        MDIForm1.StatusBar2.Panels(7) = .Fields(0)
                        iLoginFailure = 3
                        MDIForm1.accounting
                        login
                        CloseConnection
                        Unload Me
                        splash
                        Exit Sub
                    ElseIf .Fields(2) = "registrar" Then
                        MDIForm1.StatusBar1.Panels(5) = "Registrar - " & cbousername.Text 'display user in panel 5
                        MDIForm1.StatusBar1.Panels(1) = .Fields(2)
                        MDIForm1.StatusBar2.Panels(1) = Me.txtpassword.Text 'display password in panel 3
                        MDIForm1.StatusBar2.Panels(2) = Me.cbousername.Text 'display password in panel 3
                        MDIForm1.StatusBar2.Panels(7) = .Fields(0)
                        iLoginFailure = 3
                        MDIForm1.registrar
                        login
                        CloseConnection
                        Unload Me
                        splash
                        Exit Sub
                    End If
                End If
            End If
        .MoveNext
        Wend
        MsgBox "Invalid Password!!!...", vbCritical, ""
        iLoginFailure = iLoginFailure - 1
        Me.txtpassword.Text = ""
        Me.txtpassword.SetFocus
        Exit Sub
    End With
Else
   MsgBox "Sorry! You Have To Login Within Three Tries! " & Chr(13) & Chr(9) & "Program will close!!!...", vbCritical, ""
    End
End If
CloseConnection
End Sub

Private Sub Form_Activate()
Me.cbousername.SetFocus
End Sub

Private Sub Form_Initialize()
iLoginFailure = 3
End Sub
Private Sub Form_Load()
OpenConnection
Dim rs As New ADODB.Recordset
rs.Open "select distinct Username from userlevel", con, adOpenKeyset, adLockOptimistic
If rs.EOF Then Exit Sub
rs.MoveFirst
    Do While Not rs.EOF
        cbousername.AddItem rs!UserName
        rs.MoveNext
    Loop
    rs.Close
End Sub

Private Sub txtpassword_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Call cmdok_Click
End If
End Sub
Private Sub txtUserName_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Call cmdok_Click
End If
End Sub
Private Sub Form_KeyPress(KeyAscii As Integer)
If KeyAscii = 27 Then
    Call cmdexit_Click
End If
End Sub

Private Sub vkCommand1_Click()
Unload Me
CloseConnection
frmchangepass.Show vbModal
End Sub

Public Sub login()
With rsLOGS
    .AddNew
    .Fields(1) = Me.cbousername.Text
    .Fields(2) = MDIForm1.StatusBar1.Panels(1)
    .Fields(3) = Now
    .Fields(5) = "Log in"
    .Update
End With
MDIForm1.StatusBar1.Panels(2) = rsLOGS.Fields(0)
MDIForm1.StatusBar2.Panels(6) = rsLOGS.Fields(0)
End Sub

Public Sub splash()
frmwelcome.lbl1.Caption = MDIForm1.StatusBar1.Panels(5)
frmwelcome.Show vbModal
End Sub
