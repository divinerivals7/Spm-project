VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Begin VB.Form frmreg 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Registration Form"
   ClientHeight    =   8355
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   11610
   LinkTopic       =   "Form3"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   8355
   ScaleWidth      =   11610
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox Text5 
      Height          =   1095
      Left            =   2520
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   41
      Top             =   8640
      Width           =   2055
   End
   Begin VB.TextBox Text6 
      Height          =   1095
      Left            =   4680
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   40
      Top             =   8640
      Width           =   2055
   End
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   1095
      Left            =   240
      TabIndex        =   24
      Top             =   1680
      Width           =   4335
      _ExtentX        =   7646
      _ExtentY        =   1931
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkTextBox txtapno 
         Height          =   375
         Left            =   2760
         TabIndex        =   26
         Top             =   480
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Alignment       =   2
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel11 
         Height          =   375
         Left            =   240
         TabIndex        =   25
         Top             =   480
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Enter Application Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin vkUserContolsXP.vkCommand cmdadd 
      Height          =   495
      Left            =   7200
      TabIndex        =   12
      Top             =   7560
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Add"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmdcancel 
      Height          =   495
      Left            =   10080
      TabIndex        =   11
      Top             =   7560
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Clear"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   8640
      Top             =   240
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   4575
      Left            =   240
      TabIndex        =   1
      Top             =   2880
      Width           =   11175
      _ExtentX        =   19711
      _ExtentY        =   8070
      Caption         =   "Registration Form"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin MSMask.MaskEdBox txtmcpno 
         Height          =   375
         Left            =   6480
         TabIndex        =   39
         Top             =   3960
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BackColor       =   16777215
         MaxLength       =   12
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Mask            =   "####-#######"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox txtfcpno 
         Height          =   375
         Left            =   6480
         TabIndex        =   38
         Top             =   3480
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BackColor       =   16777215
         MaxLength       =   12
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Mask            =   "####-#######"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox txtcpno 
         Height          =   375
         Left            =   6480
         TabIndex        =   37
         Top             =   1920
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BackColor       =   16777215
         MaxLength       =   12
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Mask            =   "####-#######"
         PromptChar      =   "_"
      End
      Begin VB.ComboBox cbosection 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmreg.frx":0000
         Left            =   10200
         List            =   "frmreg.frx":0002
         Style           =   2  'Dropdown List
         TabIndex        =   36
         Top             =   2880
         Width           =   735
      End
      Begin vkUserContolsXP.vkLabel vkLabel17 
         Height          =   375
         Left            =   9360
         TabIndex        =   35
         Top             =   2880
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Section"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtbday 
         Height          =   375
         Left            =   1800
         TabIndex        =   34
         Top             =   2880
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel16 
         Height          =   375
         Left            =   240
         TabIndex        =   33
         Top             =   2880
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Birthday"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel15 
         Height          =   375
         Left            =   4920
         TabIndex        =   32
         Top             =   3960
         Width           =   2295
         _ExtentX        =   4048
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtmname 
         Height          =   375
         Left            =   1800
         TabIndex        =   31
         Top             =   3960
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel14 
         Height          =   375
         Left            =   240
         TabIndex        =   30
         Top             =   3960
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Mother's Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel13 
         Height          =   375
         Left            =   4920
         TabIndex        =   29
         Top             =   3480
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtfname 
         Height          =   375
         Left            =   1800
         TabIndex        =   28
         Top             =   3360
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel12 
         Height          =   375
         Left            =   240
         TabIndex        =   27
         Top             =   3360
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Father's Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.ComboBox cbosy 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         Left            =   1800
         Locked          =   -1  'True
         Style           =   2  'Dropdown List
         TabIndex        =   23
         Top             =   960
         Width           =   1815
      End
      Begin VB.ComboBox cbogl 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmreg.frx":0004
         Left            =   6480
         List            =   "frmreg.frx":0023
         Style           =   2  'Dropdown List
         TabIndex        =   22
         Top             =   2880
         Width           =   2775
      End
      Begin vkUserContolsXP.vkLabel vkLabel8 
         Height          =   375
         Left            =   4920
         TabIndex        =   21
         Top             =   1920
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel1 
         Height          =   375
         Left            =   4920
         TabIndex        =   20
         Top             =   2400
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Address"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtadd 
         Height          =   375
         Left            =   6480
         TabIndex        =   19
         Top             =   2400
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin VB.ComboBox cbogender 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmreg.frx":009E
         Left            =   6480
         List            =   "frmreg.frx":00A8
         Locked          =   -1  'True
         Style           =   2  'Dropdown List
         TabIndex        =   18
         Top             =   1440
         Width           =   855
      End
      Begin vkUserContolsXP.vkTextBox txtage 
         Height          =   375
         Left            =   3600
         TabIndex        =   17
         Top             =   2880
         Width           =   975
         _ExtentX        =   1720
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtln 
         Height          =   375
         Left            =   1800
         TabIndex        =   16
         Top             =   2400
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtmi 
         Height          =   375
         Left            =   1800
         TabIndex        =   15
         Top             =   1920
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtfn 
         Height          =   375
         Left            =   1800
         TabIndex        =   14
         Top             =   1440
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel10 
         Height          =   375
         Left            =   4920
         TabIndex        =   10
         Top             =   2880
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Grade Level"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel9 
         Height          =   375
         Left            =   240
         TabIndex        =   9
         Top             =   960
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "School Year"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel7 
         Height          =   375
         Left            =   4920
         TabIndex        =   8
         Top             =   1440
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Gender"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel6 
         Height          =   375
         Left            =   3000
         TabIndex        =   7
         Top             =   2880
         Width           =   495
         _ExtentX        =   873
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Age"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel5 
         Height          =   375
         Left            =   240
         TabIndex        =   6
         Top             =   2400
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Last Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel4 
         Height          =   375
         Left            =   240
         TabIndex        =   5
         Top             =   1920
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Middle Initial"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel3 
         Height          =   375
         Left            =   240
         TabIndex        =   4
         Top             =   1440
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "First Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtstudno 
         Height          =   375
         Left            =   1800
         TabIndex        =   3
         Top             =   480
         Width           =   975
         _ExtentX        =   1720
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel2 
         Height          =   375
         Left            =   240
         TabIndex        =   2
         Top             =   480
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Student No"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   495
      Left            =   8640
      TabIndex        =   13
      Top             =   7560
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.Image Image1 
      Height          =   1095
      Left            =   240
      Picture         =   "frmreg.frx":00B2
      Stretch         =   -1  'True
      Top             =   120
      Width           =   1095
   End
   Begin VB.Line Line2 
      X1              =   120
      X2              =   11760
      Y1              =   1440
      Y2              =   1440
   End
   Begin VB.Line Line1 
      X1              =   0
      X2              =   11640
      Y1              =   1320
      Y2              =   1320
   End
   Begin VB.Label LblTitle 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Registration Form "
      BeginProperty Font 
         Name            =   "Monotype Corsiva"
         Size            =   24
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   585
      Left            =   1440
      TabIndex        =   0
      Top             =   360
      Width           =   3525
   End
End
Attribute VB_Name = "frmreg"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'**************
' frmreg code *
'**************
Private Sub cbogl_Click()
Me.cbosection.SetFocus
End Sub

Private Sub cbogl_LostFocus()
Me.cbosection.clear
Dim rs As New ADODB.Recordset
rs.Open "select section from sec where grade_level = '" & Me.cbogl.Text & "'", con
If rs.EOF Then Exit Sub
rs.MoveFirst
    Do While Not rs.EOF
        Me.cbosection.AddItem rs!Section
        rs.MoveNext
    Loop
    rs.Close
End Sub

Private Sub cbosection_Click()
Me.txtfcpno.SetFocus
End Sub

Private Sub cmdadd_Click()
Dim temp As Integer
enabletextfields
cleartextfields

temp = rsID.RecordCount + 1 'count all records then +1
Me.txtstudno.Text = Format(Now(), "yyyy-") & temp 'this will serve as the student number of the student

Me.txtapno.locked = False
Me.txtapno.SetFocus
cmdcancel.Enabled = True

Me.Text6.Text = "Add Student #" + Me.txtstudno.Text

With rsLOGS
.Find "logid ='" & MDIForm1.StatusBar2.Panels(6) & "'", 0, adSearchForward, 1
If Not .EOF Then
    Me.Text5.Text = .Fields(5)
End If
End With
End Sub

Private Sub cmdcancel_Click()
Call cleartextfields
Me.cmdsave.Enabled = False
Me.cmdcancel.Enabled = False
Me.txtapno.locked = True
Me.txtapno.SetFocus
End Sub

Private Sub cmdexit_Click()
Unload Me
End Sub

Private Sub cmdsave_Click()
If Me.cbogl.ListIndex = -1 Then
    MsgBox "Please Enter Student Grade Level...", vbCritical + vbOKOnly, ""
    Me.cbogl.SetFocus
Exit Sub
End If
If Me.cbosection.ListIndex = -1 Then
    MsgBox "Please Enter Student Section...", vbCritical + vbOKOnly, ""
    Me.cbosection.SetFocus
Exit Sub
End If
If Me.txtfcpno.Text = "" Then
    MsgBox "Please Enter Student Father's Contact No...", vbCritical + vbOKOnly, ""
    Me.txtfcpno.SetFocus
Exit Sub
End If
If Me.txtmcpno.Text = "" Then
    MsgBox "Please Enter Student Mother's Contact No...", vbCritical + vbOKOnly, ""
    Me.txtmcpno.SetFocus
Exit Sub
End If
act
save
End Sub

Private Sub Form_Load()
Dim i As Integer
Call OpenConnection
disabletextfields
For i = 1 To rsSCHOOLYEAR.RecordCount 'count all records
cbosy.AddItem rsSCHOOLYEAR.Fields(0) 'adding all the records  from the category table
rsSCHOOLYEAR.MoveNext 'move to next record
Next i

cmdsave.Enabled = False
cmdcancel.Enabled = False
Me.txtapno.locked = True
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim a As Integer
If cmdsave.Enabled = True Then
    a = MsgBox("Are you sure you want to quit this form with out saving?", vbYesNo + vbQuestion, "")
        If a = vbYes Then
            Call CloseConnection
            Unload Me
        Else
            Cancel = 1
            End If
Else
    Call CloseConnection
    Unload Me
End If
End Sub

Sub enabletextfields()
txtstudno.Enabled = True
txtfn.Enabled = True
txtmi.Enabled = True
txtln.Enabled = True
txtage.Enabled = True
txtadd.Enabled = True
txtcpno.Enabled = True
cbogender.Enabled = True
cbogl.Enabled = True
cbosy.Enabled = True
cbosection.Enabled = True
Me.txtfname.Enabled = True
Me.txtmname.Enabled = True
Me.txtfcpno.Enabled = True
Me.txtmcpno.Enabled = True
End Sub

Sub disabletextfields()
txtstudno.Enabled = False
txtfn.Enabled = False
txtmi.Enabled = False
txtadd.Enabled = False
txtcpno.Enabled = False
txtln.Enabled = False
txtage.Enabled = False
cbogender.Enabled = False
cbogl.Enabled = False
cbosy.Enabled = False
cbosection.Enabled = False
Me.txtfname.Enabled = False
Me.txtmname.Enabled = False
Me.txtfcpno.Enabled = False
Me.txtmcpno.Enabled = False
End Sub

Sub cleartextfields()
Dim strMask As String
strMask = Me.txtcpno.Mask
strMask = Me.txtmcpno.Mask
strMask = Me.txtfcpno.Mask
Me.txtbday.Text = ""
Me.txtapno.Text = ""
txtstudno.Text = ""
txtfn.Text = ""
txtmi.Text = ""
txtln.Text = ""
txtage.Text = ""
txtadd.Text = ""
txtcpno.Mask = ""
txtcpno.Text = ""
txtfname.Text = ""
txtfcpno.Mask = ""
txtfcpno.Text = ""
txtmname.Text = ""
txtmcpno.Mask = ""
txtmcpno.Text = ""
Me.Text5.Text = ""
Me.Text6.Text = ""
cbogender.ListIndex = -1
cbogl.ListIndex = -1
cbosy.ListIndex = -1
cbosection.ListIndex = -1
Me.txtfcpno.Mask = strMask
Me.txtmcpno.Mask = strMask
Me.txtcpno.Mask = strMask
End Sub

Public Sub save()
On Error GoTo err:
With rsREGISTRATION
    .AddNew 'add new information
    .Fields(0) = Me.txtstudno.Text
    .Fields(1) = Me.txtln.Text
    .Fields(2) = Me.txtfn.Text
    .Fields(3) = Me.txtmi.Text
    .Fields(4) = Me.txtage.Text
    .Fields(5) = Me.cbogender.Text
    .Fields(6) = Me.txtbday.Text
    .Fields(7) = Me.txtadd.Text
    .Fields(8) = Me.txtcpno.Text
    .Fields(9) = Me.cbogl.Text
    .Fields(10) = Me.cbosection.Text
    .Fields(11) = Me.cbosy.Text
    .Fields(12) = Me.txtfname.Text
    .Fields(13) = Me.txtfcpno.Text
    .Fields(14) = Me.txtmname.Text
    .Fields(15) = Me.txtmcpno.Text
    .Fields(16) = Now
    .Fields(17) = Me.txtapno.Text
    .Update
    MsgBox "Student Number and Student Name!" & Chr(13) & Chr(13) & Chr(13) & "Student Number = " & Me.txtstudno.Text & Chr(13) & "Student Name  = " & Me.txtln.Text & "," & Me.txtfn.Text & " " & Me.txtmi.Text, vbInformation + vbOKOnly, ""
    MDIForm1.mnustudinfo.Enabled = True
    MDIForm1.mnuass.Enabled = True
    MDIForm1.mnueditreg.Enabled = True
    MDIForm1.mnuRS.Enabled = True
    MDIForm1.mnuID.Enabled = True
End With

With rsID
    .AddNew
    .Fields(0) = Me.txtstudno.Text
    .Update
End With
cleartextfields
disabletextfields
cmdsave.Enabled = False
cmdcancel.Enabled = False
Exit Sub
err:
MsgBox "student number already occupied!!!", vbCritical, ""
End Sub

Private Sub txtapno_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
    If IsNumeric(Me.txtapno.Text) = False Then
        MsgBox "Please input number to search for applicant number!!!", vbCritical, ""
        Me.txtapno.SetFocus
        cleartextfields
        Me.cmdsave.Enabled = False
        Me.cmdcancel.Enabled = False
        Exit Sub
    End If
    enabletextfields
If Len(Me.txtapno.Text) <= 0 Then Exit Sub
On Error GoTo e:
With rsREGISTRATION
    .Find "App_no = '" & Trim(Me.txtapno.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
    MsgBox "Invalid Application Number!!!", vbCritical, ""
    Me.txtapno.SetFocus
    cleartextfields
    Me.cmdsave.Enabled = False
    Me.cmdcancel.Enabled = False
    Exit Sub
    End If
End With

With rsAPPLICATION
    .Find "App_No= '" & Trim(Me.txtapno.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
        cmdsave.Enabled = True
        cmdcancel.Enabled = True
        Me.txtapno.locked = True
        Me.cbogl.SetFocus
        
        Me.txtfn.Text = .Fields(3)
        Me.txtmi.Text = .Fields(4)
        Me.txtln.Text = .Fields(2)
        Me.txtage.Text = .Fields(5)
        Me.cbogender = .Fields(6)
        Me.txtadd.Text = .Fields(10)
        Me.txtbday.Text = .Fields(8)
        Me.txtcpno.Text = .Fields(11)
        Me.cbosy.Text = .Fields(1)
        Me.txtfname.Text = .Fields(13)
        Me.txtmname.Text = .Fields(18)
        'Me.cbosy.Text = .Fields(7)
        Else
        MsgBox "Applicant Number Not Exist!!!", vbCritical + vbOKOnly, ""
        Me.txtapno.locked = True
        cmdsave.Enabled = False
        cmdcancel.Enabled = False
        cleartextfields
        disabletextfields
        End If
End With
End If
Exit Sub
e:
MsgBox "Kindly please close first the form...", vbInformation, ""
End Sub
Public Sub searchapp()
With rsREGISTRATION
    .Find "App_no = '" & Trim(Me.txtapno.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
    MsgBox "Invalid Application Number!!!", vbCritical, ""
    Me.txtapno.SetFocus
    Exit Sub
    End If
End With
End Sub

Private Sub txtcpno_KeyPress(KeyAscii As Integer)
If KeyAscii < 48 Or KeyAscii > 57 Then
    KeyAscii = 0
End If
End Sub

Private Sub txtfcpno_KeyPress(KeyAscii As Integer)
If KeyAscii < 48 Or KeyAscii > 57 Then
    KeyAscii = 0
End If

End Sub

Private Sub txtmcpno_KeyPress(KeyAscii As Integer)
If KeyAscii < 48 Or KeyAscii > 57 Then
    KeyAscii = 0
End If
End Sub

Public Sub act()
With rsLOGS
    .Find "logid = '" & MDIForm1.StatusBar2.Panels(6) & "'", 0, adSearchForward, 1
If Not .EOF Then
    .Fields(5) = Me.Text5.Text + ", " + Me.Text6.Text
    .Update
End If
End With
End Sub
