VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Begin VB.Form frmabout 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "About Us"
   ClientHeight    =   9165
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   14415
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   9165
   ScaleWidth      =   14415
   StartUpPosition =   2  'CenterScreen
   Begin vbskpro.Skinner Skinner1 
      Left            =   -480
      Top             =   5040
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   2295
      Left            =   240
      TabIndex        =   0
      Top             =   1920
      Width           =   2295
      _ExtentX        =   4048
      _ExtentY        =   4048
      Caption         =   "Programmers"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   16512
      TitleColor2     =   16512
      BorderColor     =   16512
      Begin vkUserContolsXP.vkOptionButton opt5 
         Height          =   375
         Left            =   240
         TabIndex        =   5
         Top             =   1800
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Marianne"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt4 
         Height          =   375
         Left            =   240
         TabIndex        =   4
         Top             =   1440
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Irwin"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt3 
         Height          =   375
         Left            =   240
         TabIndex        =   3
         Top             =   1080
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Alyssa"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt2 
         Height          =   375
         Left            =   240
         TabIndex        =   2
         Top             =   720
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Paolo"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
      Begin vkUserContolsXP.vkOptionButton opt1 
         Height          =   375
         Left            =   240
         TabIndex        =   1
         Top             =   360
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Jerry"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Group           =   1
      End
   End
   Begin vkUserContolsXP.vkFrame vkalyssa 
      Height          =   6975
      Left            =   2640
      TabIndex        =   39
      Top             =   1920
      Visible         =   0   'False
      Width           =   11535
      _ExtentX        =   20346
      _ExtentY        =   12303
      Caption         =   "Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   16512
      TitleColor2     =   16512
      BorderColor     =   16512
      Begin vkUserContolsXP.vkLabel vkLabel39 
         Height          =   375
         Left            =   4440
         TabIndex        =   52
         Top             =   1200
         Width           =   3135
         _ExtentX        =   5530
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "and Cashiering System"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel38 
         Height          =   375
         Left            =   2400
         TabIndex        =   51
         Top             =   720
         Width           =   7215
         _ExtentX        =   12726
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Molina Montessori  Center, Inc. Student Inofrmation"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel37 
         Height          =   375
         Left            =   5040
         TabIndex        =   50
         Top             =   5400
         Width           =   2055
         _ExtentX        =   3625
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "4E - G2"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel36 
         Height          =   255
         Left            =   3120
         TabIndex        =   49
         Top             =   4920
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   450
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Course: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel35 
         Height          =   375
         Left            =   3120
         TabIndex        =   48
         Top             =   5400
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Year and Section:"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel34 
         Height          =   375
         Left            =   5040
         TabIndex        =   47
         Top             =   4920
         Width           =   5415
         _ExtentX        =   9551
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Bachelor of Science and Information Technology"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel33 
         Height          =   375
         Left            =   3120
         TabIndex        =   46
         Top             =   4440
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "E-mail address: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel32 
         Height          =   375
         Left            =   5040
         TabIndex        =   45
         Top             =   4440
         Width           =   3375
         _ExtentX        =   5953
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "alyssaanneesguerra@gmail.com"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel31 
         Height          =   375
         Left            =   3120
         TabIndex        =   44
         Top             =   3960
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact No:"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel30 
         Height          =   375
         Left            =   3120
         TabIndex        =   43
         Top             =   3480
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Address: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel29 
         Height          =   375
         Left            =   5040
         TabIndex        =   42
         Top             =   3960
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "09067427943"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel28 
         Height          =   375
         Left            =   5040
         TabIndex        =   41
         Top             =   3480
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "#0306 Mercado, Hagonoy, Bulacan"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel27 
         Height          =   375
         Left            =   3120
         TabIndex        =   40
         Top             =   3000
         Width           =   5295
         _ExtentX        =   9340
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "ESGUERRA, ALYSSA ANNE R."
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.Line Line6 
         BorderWidth     =   3
         X1              =   480
         X2              =   10920
         Y1              =   6120
         Y2              =   6120
      End
      Begin VB.Line Line5 
         BorderWidth     =   3
         X1              =   480
         X2              =   10920
         Y1              =   2280
         Y2              =   2280
      End
      Begin VB.Image Image5 
         Height          =   2220
         Left            =   480
         Picture         =   "frmabout.frx":0000
         Stretch         =   -1  'True
         Top             =   2880
         Width           =   2370
      End
   End
   Begin vkUserContolsXP.vkFrame vkpaolo 
      Height          =   6975
      Left            =   2640
      TabIndex        =   25
      Top             =   1920
      Visible         =   0   'False
      Width           =   11535
      _ExtentX        =   20346
      _ExtentY        =   12303
      Caption         =   "Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   16512
      TitleColor2     =   16512
      BorderColor     =   16512
      Begin vkUserContolsXP.vkLabel vkLabel26 
         Height          =   375
         Left            =   3120
         TabIndex        =   38
         Top             =   3000
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "CRUZ, PAOLO A."
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel25 
         Height          =   375
         Left            =   5040
         TabIndex        =   37
         Top             =   3480
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "#549 San Miguel, Hagonoy, Bulacan"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel24 
         Height          =   375
         Left            =   5040
         TabIndex        =   36
         Top             =   3960
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "0916-5068255"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel23 
         Height          =   375
         Left            =   3120
         TabIndex        =   35
         Top             =   3480
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Address: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel22 
         Height          =   375
         Left            =   3120
         TabIndex        =   34
         Top             =   3960
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact No:"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel21 
         Height          =   375
         Left            =   5040
         TabIndex        =   33
         Top             =   4440
         Width           =   3375
         _ExtentX        =   5953
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "cruzpaoloarellano@yahoo.com"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel20 
         Height          =   375
         Left            =   3120
         TabIndex        =   32
         Top             =   4440
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "E-mail address: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel19 
         Height          =   375
         Left            =   5040
         TabIndex        =   31
         Top             =   4920
         Width           =   5415
         _ExtentX        =   9551
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Bachelor of Science and Information Technology"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel18 
         Height          =   375
         Left            =   3120
         TabIndex        =   30
         Top             =   5400
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Year and Section:"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel17 
         Height          =   255
         Left            =   3120
         TabIndex        =   29
         Top             =   4920
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   450
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Course: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel16 
         Height          =   375
         Left            =   5040
         TabIndex        =   28
         Top             =   5400
         Width           =   2055
         _ExtentX        =   3625
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "4E - G2"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel15 
         Height          =   375
         Left            =   2400
         TabIndex        =   27
         Top             =   720
         Width           =   7215
         _ExtentX        =   12726
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Molina Montessori  Center, Inc. Student Inofrmation"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel14 
         Height          =   375
         Left            =   4440
         TabIndex        =   26
         Top             =   1200
         Width           =   3135
         _ExtentX        =   5530
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "and Cashiering System"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.Image Image4 
         Height          =   2220
         Left            =   480
         Picture         =   "frmabout.frx":36A7
         Stretch         =   -1  'True
         Top             =   2880
         Width           =   2370
      End
      Begin VB.Line Line4 
         BorderWidth     =   3
         X1              =   480
         X2              =   10920
         Y1              =   2280
         Y2              =   2280
      End
      Begin VB.Line Line3 
         BorderWidth     =   3
         X1              =   480
         X2              =   10920
         Y1              =   6120
         Y2              =   6120
      End
   End
   Begin vkUserContolsXP.vkFrame vkjerry 
      Height          =   6975
      Left            =   2640
      TabIndex        =   11
      Top             =   1920
      Visible         =   0   'False
      Width           =   11535
      _ExtentX        =   20346
      _ExtentY        =   12303
      Caption         =   "Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   16512
      TitleColor2     =   16512
      BorderColor     =   16512
      Begin vkUserContolsXP.vkLabel vkLabel13 
         Height          =   375
         Left            =   4440
         TabIndex        =   24
         Top             =   1200
         Width           =   3135
         _ExtentX        =   5530
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "and Cashiering System"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel12 
         Height          =   375
         Left            =   2400
         TabIndex        =   23
         Top             =   720
         Width           =   7215
         _ExtentX        =   12726
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Molina Montessori  Center, Inc. Student Inofrmation"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel11 
         Height          =   375
         Left            =   5040
         TabIndex        =   22
         Top             =   5400
         Width           =   2055
         _ExtentX        =   3625
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "4E - G2"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel10 
         Height          =   255
         Left            =   3120
         TabIndex        =   21
         Top             =   4920
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   450
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Course: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel9 
         Height          =   375
         Left            =   3120
         TabIndex        =   20
         Top             =   5400
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Year and Section:"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel8 
         Height          =   375
         Left            =   5040
         TabIndex        =   19
         Top             =   4920
         Width           =   5415
         _ExtentX        =   9551
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Bachelor of Science and Information Technology"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel7 
         Height          =   375
         Left            =   3120
         TabIndex        =   18
         Top             =   4440
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "E-mail address: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel6 
         Height          =   375
         Left            =   5040
         TabIndex        =   17
         Top             =   4440
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "jqbaltar@yahoo.com "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel5 
         Height          =   375
         Left            =   3120
         TabIndex        =   16
         Top             =   3960
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact No:"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel4 
         Height          =   375
         Left            =   3120
         TabIndex        =   15
         Top             =   3480
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Address: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel3 
         Height          =   375
         Left            =   5040
         TabIndex        =   14
         Top             =   3960
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "0926-7374723"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel2 
         Height          =   375
         Left            =   5040
         TabIndex        =   13
         Top             =   3480
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "#359 Barihan, City of Malolos"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel1 
         Height          =   375
         Left            =   3120
         TabIndex        =   12
         Top             =   3000
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "BALTAR, JERRY Q."
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.Line Line2 
         BorderWidth     =   3
         X1              =   480
         X2              =   10920
         Y1              =   6120
         Y2              =   6120
      End
      Begin VB.Line Line1 
         BorderWidth     =   3
         X1              =   480
         X2              =   10920
         Y1              =   2280
         Y2              =   2280
      End
      Begin VB.Image Image3 
         Height          =   2055
         Left            =   600
         Picture         =   "frmabout.frx":16BA4
         Stretch         =   -1  'True
         Top             =   3120
         Width           =   2340
      End
   End
   Begin vkUserContolsXP.vkFrame vkyhan 
      Height          =   6975
      Left            =   2640
      TabIndex        =   67
      Top             =   1920
      Visible         =   0   'False
      Width           =   11535
      _ExtentX        =   20346
      _ExtentY        =   12303
      Caption         =   "Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   16512
      TitleColor2     =   16512
      BorderColor     =   16512
      Begin vkUserContolsXP.vkLabel vkLabel65 
         Height          =   375
         Left            =   4440
         TabIndex        =   80
         Top             =   1200
         Width           =   3135
         _ExtentX        =   5530
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "and Cashiering System"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel64 
         Height          =   375
         Left            =   2400
         TabIndex        =   79
         Top             =   720
         Width           =   7215
         _ExtentX        =   12726
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Molina Montessori  Center, Inc. Student Inofrmation"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel63 
         Height          =   375
         Left            =   5040
         TabIndex        =   78
         Top             =   5400
         Width           =   2055
         _ExtentX        =   3625
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "4E - G2"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel62 
         Height          =   255
         Left            =   3120
         TabIndex        =   77
         Top             =   4920
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   450
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Course: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel61 
         Height          =   375
         Left            =   3120
         TabIndex        =   76
         Top             =   5400
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Year and Section:"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel60 
         Height          =   375
         Left            =   5040
         TabIndex        =   75
         Top             =   4920
         Width           =   5415
         _ExtentX        =   9551
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Bachelor of Science and Information Technology"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel59 
         Height          =   375
         Left            =   3120
         TabIndex        =   74
         Top             =   4440
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "E-mail address: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel58 
         Height          =   375
         Left            =   5040
         TabIndex        =   73
         Top             =   4440
         Width           =   3375
         _ExtentX        =   5953
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "yhanpineda@yahoo.com"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel57 
         Height          =   375
         Left            =   3120
         TabIndex        =   72
         Top             =   3960
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact No:"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel56 
         Height          =   375
         Left            =   3120
         TabIndex        =   71
         Top             =   3480
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Address: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel55 
         Height          =   375
         Left            =   5040
         TabIndex        =   70
         Top             =   3960
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "+63905-586-6648"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel54 
         Height          =   375
         Left            =   5040
         TabIndex        =   69
         Top             =   3480
         Width           =   5055
         _ExtentX        =   8916
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Damayan St. Zone 7 San Pedro Hagonoy,Bulacan"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel53 
         Height          =   375
         Left            =   3120
         TabIndex        =   68
         Top             =   3000
         Width           =   5295
         _ExtentX        =   9340
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "PINEDA, MARIANNE B."
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.Line Line10 
         BorderWidth     =   3
         X1              =   480
         X2              =   10920
         Y1              =   6120
         Y2              =   6120
      End
      Begin VB.Line Line9 
         BorderWidth     =   3
         X1              =   480
         X2              =   10920
         Y1              =   2280
         Y2              =   2280
      End
      Begin VB.Image Image7 
         Height          =   2220
         Left            =   480
         Picture         =   "frmabout.frx":2F2E4
         Stretch         =   -1  'True
         Top             =   2880
         Width           =   2370
      End
   End
   Begin vkUserContolsXP.vkFrame vkirwin 
      Height          =   6975
      Left            =   2640
      TabIndex        =   53
      Top             =   1920
      Visible         =   0   'False
      Width           =   11535
      _ExtentX        =   20346
      _ExtentY        =   12303
      Caption         =   "Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   16512
      TitleColor2     =   16512
      BorderColor     =   16512
      Begin vkUserContolsXP.vkLabel vkLabel52 
         Height          =   375
         Left            =   3120
         TabIndex        =   66
         Top             =   3000
         Width           =   5295
         _ExtentX        =   9340
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "MOLINA, IRWIN JAN A."
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel51 
         Height          =   375
         Left            =   5040
         TabIndex        =   65
         Top             =   3480
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "#177 San Marcos Calumpit, Bulacan"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel50 
         Height          =   375
         Left            =   5040
         TabIndex        =   64
         Top             =   3960
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "09067427943"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel49 
         Height          =   375
         Left            =   3120
         TabIndex        =   63
         Top             =   3480
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Address: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel48 
         Height          =   375
         Left            =   3120
         TabIndex        =   62
         Top             =   3960
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact No:"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel47 
         Height          =   375
         Left            =   5040
         TabIndex        =   61
         Top             =   4440
         Width           =   3375
         _ExtentX        =   5953
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "alyssaanneesguerra@gmail.com"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel46 
         Height          =   375
         Left            =   3120
         TabIndex        =   60
         Top             =   4440
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "E-mail address: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel45 
         Height          =   375
         Left            =   5040
         TabIndex        =   59
         Top             =   4920
         Width           =   5415
         _ExtentX        =   9551
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Bachelor of Science and Information Technology"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel44 
         Height          =   375
         Left            =   3120
         TabIndex        =   58
         Top             =   5400
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Year and Section:"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel43 
         Height          =   255
         Left            =   3120
         TabIndex        =   57
         Top             =   4920
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   450
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Course: "
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel42 
         Height          =   375
         Left            =   5040
         TabIndex        =   56
         Top             =   5400
         Width           =   2055
         _ExtentX        =   3625
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "4E - G2"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel41 
         Height          =   375
         Left            =   2400
         TabIndex        =   55
         Top             =   720
         Width           =   7215
         _ExtentX        =   12726
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Molina Montessori  Center, Inc. Student Inofrmation"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel40 
         Height          =   375
         Left            =   4440
         TabIndex        =   54
         Top             =   1200
         Width           =   3135
         _ExtentX        =   5530
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "and Cashiering System"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.Image Image6 
         Height          =   2220
         Left            =   480
         Picture         =   "frmabout.frx":3DE77
         Stretch         =   -1  'True
         Top             =   2880
         Width           =   2370
      End
      Begin VB.Line Line8 
         BorderWidth     =   3
         X1              =   480
         X2              =   10920
         Y1              =   2280
         Y2              =   2280
      End
      Begin VB.Line Line7 
         BorderWidth     =   3
         X1              =   480
         X2              =   10920
         Y1              =   6120
         Y2              =   6120
      End
   End
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   6975
      Left            =   2640
      TabIndex        =   6
      Top             =   1920
      Width           =   11535
      _ExtentX        =   20346
      _ExtentY        =   12303
      Caption         =   "Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   16512
      TitleColor2     =   16512
      BorderColor     =   16512
      Begin VB.PictureBox img 
         Height          =   6495
         Left            =   120
         ScaleHeight     =   6435
         ScaleWidth      =   11235
         TabIndex        =   7
         Top             =   360
         Width           =   11295
      End
   End
   Begin ComctlLib.ImageList il 
      Left            =   480
      Top             =   600
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   800
      ImageHeight     =   500
      MaskColor       =   12632256
      _Version        =   327682
      BeginProperty Images {0713E8C2-850A-101B-AFC0-4210102A8DA7} 
         NumListImages   =   1
         BeginProperty ListImage1 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmabout.frx":540D3
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Image Image2 
      Height          =   1350
      Left            =   11280
      Picture         =   "frmabout.frx":1790A5
      Top             =   360
      Width           =   1350
   End
   Begin VB.Image Image1 
      Height          =   1350
      Left            =   2040
      Picture         =   "frmabout.frx":17A532
      Top             =   360
      Width           =   1350
   End
   Begin VB.Label Label3 
      BackStyle       =   0  'Transparent
      Caption         =   "City of Malolos, Bulacan"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   15.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5520
      TabIndex        =   10
      Top             =   1200
      Width           =   4215
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Caption         =   "Bulacan State University"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   15.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5520
      TabIndex        =   9
      Top             =   480
      Width           =   4575
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "College of Information and Communications Technology"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   15.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3600
      TabIndex        =   8
      Top             =   840
      Width           =   8535
   End
End
Attribute VB_Name = "frmabout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'***************
' frmabout code*
'***************
Private Sub Form_Load()
img.Picture = Me.il.ListImages.Item(1).Picture
End Sub

Private Sub opt1_Change(Value As CheckBoxConstants)
vkjerry.Visible = True
vkpaolo.Visible = False
vkalyssa.Visible = False
vkirwin.Visible = False
End Sub

Private Sub opt2_Change(Value As CheckBoxConstants)
vkpaolo.Visible = True
vkjerry.Visible = False
vkalyssa.Visible = False
vkirwin.Visible = False
vkyhan.Visible = False
End Sub

Private Sub opt3_Change(Value As CheckBoxConstants)
vkalyssa.Visible = True
vkpaolo.Visible = False
vkjerry.Visible = False
vkirwin.Visible = False
vkyhan.Visible = False
End Sub

Private Sub opt4_Change(Value As CheckBoxConstants)
vkirwin.Visible = True
vkpaolo.Visible = False
vkjerry.Visible = False
vkalyssa.Visible = False
vkyhan.Visible = False
End Sub

Private Sub opt5_Change(Value As CheckBoxConstants)
vkyhan.Visible = True
vkpaolo.Visible = False
vkjerry.Visible = False
vkalyssa.Visible = False
vkirwin.Visible = False
End Sub
