VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Begin VB.Form frmrptgl 
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   2460
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   6945
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2460
   ScaleWidth      =   6945
   StartUpPosition =   2  'CenterScreen
   Begin vbskpro.Skinner Skinner1 
      Left            =   480
      Top             =   1920
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkLabel vkLabel9 
      Height          =   375
      Left            =   600
      TabIndex        =   0
      Top             =   960
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Grade Level"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   1335
      Left            =   360
      TabIndex        =   1
      Top             =   360
      Width           =   6375
      _ExtentX        =   11245
      _ExtentY        =   2355
      Caption         =   "Search Grade Level and Section to be printed"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkLabel vkLabel17 
         Height          =   375
         Left            =   4080
         TabIndex        =   5
         Top             =   600
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Section"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.ComboBox cbosection 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmrptgl.frx":0000
         Left            =   4920
         List            =   "frmrptgl.frx":0002
         Style           =   2  'Dropdown List
         TabIndex        =   4
         Top             =   600
         Width           =   735
      End
      Begin VB.ComboBox cbogl 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmrptgl.frx":0004
         Left            =   1560
         List            =   "frmrptgl.frx":0023
         Style           =   2  'Dropdown List
         TabIndex        =   3
         Top             =   600
         Width           =   2055
      End
   End
   Begin vkUserContolsXP.vkCommand cmdok 
      Height          =   495
      Left            =   5400
      TabIndex        =   2
      Top             =   1800
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Ok"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmrptgl"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'****************
' frmrptgl code *
'****************
Private Sub cbogl_Click()
Me.cbosection.SetFocus
Me.cbosection.clear
End Sub

Private Sub cbogl_LostFocus()
Dim rs As New ADODB.Recordset
rs.Open "select Section from sec where Grade_Level = '" & Me.cbogl.Text & "'", con
If rs.EOF Then Exit Sub
rs.MoveFirst
    Do While Not rs.EOF
        Me.cbosection.AddItem rs!Section
        rs.MoveNext
    Loop
    rs.Close
End Sub

Private Sub cbosection_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
    cmdok_Click
End If
End Sub

Private Sub cmdok_Click()
Dim rsgl As New ADODB.Recordset

If Me.cbogl.Text = "" Or Me.cbosection.Text = "" Then
    MsgBox "Please select both fields", vbCritical, ""
    Exit Sub
Else
    rsgl.Open "select * from registration where Grade_Level = '" & frmrptgl.cbogl.Text & "'" & " and Section = '" & Me.cbosection.Text & "'", con, adOpenKeyset, adLockOptimistic
    Set rptstudlistbygl.DataSource = rsgl

    rptstudlistbygl.Sections("Section5").Controls("label21").Caption = MDIForm1.StatusBar1.Panels(5).Text
        rptstudlistbygl.Sections("Section5").Controls("label25").Caption = Now
    rptstudlistbygl.Sections(2).Controls("lblgl").Caption = Me.cbogl.Text
    rptstudlistbygl.Sections(2).Controls("label23").Caption = Me.cbosection.Text
    rptstudlistbygl.Show vbModal
End If
End Sub

Private Sub Form_Load()
OpenConnection
End Sub

Private Sub Form_Unload(Cancel As Integer)
CloseConnection
End Sub
