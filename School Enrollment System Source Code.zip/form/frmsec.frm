VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Begin VB.Form frmsec 
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   1590
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   5460
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1590
   ScaleWidth      =   5460
   StartUpPosition =   2  'CenterScreen
   Begin vbskpro.Skinner Skinner1 
      Left            =   600
      Top             =   1800
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   1095
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   4935
      _ExtentX        =   8705
      _ExtentY        =   1931
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkTextBox txtpassword 
         Height          =   375
         Left            =   1920
         TabIndex        =   2
         Top             =   480
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         PassWordChar    =   "*"
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel1 
         Height          =   375
         Left            =   240
         TabIndex        =   1
         Top             =   480
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Enter Password"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
End
Attribute VB_Name = "frmsec"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Activate()
txtpassword.SetFocus
End Sub

Private Sub Form_Load()
OpenConnection
End Sub

Private Sub Form_Unload(Cancel As Integer)
CloseConnection
End Sub

Private Sub txtpassword_KeyPress(KeyAscii As Integer)
Dim rs As New ADODB.Recordset
rs.Open "Select Password from USERLEVEL where User_Level like '" & "administrator" & "%'", con, adOpenKeyset, adLockOptimistic
If KeyAscii = 13 Then
    If txtpassword.Text = rs!Password Then
        Unload Me
      '  CloseConnection
        frmadduser.Show vbModal
    Else
        MsgBox "Invalid Password!!!", vbCritical + vbOKOnly, ""
        Me.txtpassword.Text = ""
    End If
End If
End Sub

Public Sub sec()
Dim rs As New ADODB.Recordset
rs.Open "Select Password from USERLEVEL where User_Level like '" & "administrator" & "%'", con, adOpenKeyset, adLockOptimistic
Me.txtpassword.Text = rs!Password
End Sub

