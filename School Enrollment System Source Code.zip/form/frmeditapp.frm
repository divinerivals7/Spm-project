VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Begin VB.Form frmeditapp 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Edit Application Form"
   ClientHeight    =   10980
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   12285
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   10980
   ScaleWidth      =   12285
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox Text6 
      Height          =   1095
      Left            =   13200
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   58
      Top             =   6840
      Width           =   2055
   End
   Begin VB.TextBox Text5 
      Height          =   1095
      Left            =   13200
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   57
      Top             =   5640
      Width           =   2055
   End
   Begin VB.TextBox Text3 
      Height          =   405
      Left            =   12840
      TabIndex        =   8
      Text            =   "Text3"
      Top             =   4920
      Width           =   975
   End
   Begin VB.TextBox Text2 
      Height          =   405
      Left            =   12840
      TabIndex        =   7
      Text            =   "Text2"
      Top             =   4440
      Width           =   975
   End
   Begin VB.TextBox Text4 
      Height          =   375
      Left            =   12840
      TabIndex        =   6
      Text            =   "Text1"
      Top             =   3960
      Width           =   975
   End
   Begin vkUserContolsXP.vkTextBox txtan 
      Height          =   375
      Left            =   3480
      TabIndex        =   3
      Top             =   1680
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Alignment       =   2
      BorderColor     =   4210816
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkLabel vkLabel22 
      Height          =   375
      Left            =   360
      TabIndex        =   2
      Top             =   1680
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Enter Student Application Number"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   10560
      Top             =   -360
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   495
      Left            =   9000
      TabIndex        =   0
      Top             =   10320
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   873
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   975
      Left            =   240
      TabIndex        =   4
      Top             =   1320
      Width           =   5655
      _ExtentX        =   9975
      _ExtentY        =   1720
      Caption         =   "Search"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
   End
   Begin vkUserContolsXP.vkCommand cmdcancel 
      Height          =   495
      Left            =   10560
      TabIndex        =   5
      Top             =   10320
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   873
      Caption         =   "&Clear"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   4215
      Left            =   240
      TabIndex        =   9
      Top             =   2400
      Width           =   11775
      _ExtentX        =   20770
      _ExtentY        =   7435
      Caption         =   "Student Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   16512
      BorderColor     =   4210816
      Begin MSMask.MaskEdBox txtcpno 
         Height          =   375
         Left            =   6360
         TabIndex        =   54
         Top             =   2040
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BackColor       =   16777215
         MaxLength       =   12
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Mask            =   "####-#######"
         PromptChar      =   "_"
      End
      Begin VB.TextBox txtps 
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   2160
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   53
         Text            =   "frmeditapp.frx":0000
         Top             =   3480
         Width           =   9375
      End
      Begin vkUserContolsXP.vkTextBox txtpb 
         Height          =   375
         Left            =   2160
         TabIndex        =   52
         Top             =   3000
         Width           =   9375
         _ExtentX        =   16536
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtadd 
         Height          =   375
         Left            =   6360
         TabIndex        =   51
         Top             =   2520
         Width           =   5175
         _ExtentX        =   9128
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin VB.ComboBox cbogender 
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmeditapp.frx":0006
         Left            =   6360
         List            =   "frmeditapp.frx":0010
         Style           =   2  'Dropdown List
         TabIndex        =   50
         Top             =   1560
         Width           =   2415
      End
      Begin vkUserContolsXP.vkTextBox txtother 
         Height          =   375
         Left            =   8880
         TabIndex        =   49
         Top             =   1080
         Width           =   2655
         _ExtentX        =   4683
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin VB.ComboBox cboreligion 
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmeditapp.frx":001A
         Left            =   6360
         List            =   "frmeditapp.frx":0030
         TabIndex        =   48
         Text            =   "cboreligion"
         Top             =   1080
         Width           =   2415
      End
      Begin vkUserContolsXP.vkTextBox txtage 
         Height          =   375
         Left            =   4320
         TabIndex        =   47
         Top             =   2520
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin MSComCtl2.DTPicker dtpdateofbirth 
         Height          =   375
         Left            =   2160
         TabIndex        =   46
         Top             =   2520
         Width           =   1575
         _ExtentX        =   2778
         _ExtentY        =   661
         _Version        =   393216
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         CustomFormat    =   "MMM-dd-yyyy"
         Format          =   21364739
         CurrentDate     =   40095
      End
      Begin vkUserContolsXP.vkTextBox txtln 
         Height          =   375
         Left            =   2160
         TabIndex        =   45
         Top             =   2040
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtmi 
         Height          =   375
         Left            =   2160
         TabIndex        =   44
         Top             =   1560
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtfirstname 
         Height          =   375
         Left            =   2160
         TabIndex        =   43
         Top             =   1080
         Width           =   3015
         _ExtentX        =   5318
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin VB.ComboBox cbors 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         Left            =   2160
         Style           =   2  'Dropdown List
         TabIndex        =   42
         Top             =   480
         Width           =   2175
      End
      Begin vkUserContolsXP.vkLabel vkLabel10 
         Height          =   375
         Left            =   240
         TabIndex        =   22
         Top             =   2520
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Date of Birth"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel6 
         Height          =   375
         Left            =   5280
         TabIndex        =   21
         Top             =   1080
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Religion"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel5 
         Height          =   375
         Left            =   3840
         TabIndex        =   20
         Top             =   2520
         Width           =   495
         _ExtentX        =   873
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Age"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel3 
         Height          =   375
         Left            =   240
         TabIndex        =   19
         Top             =   1560
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Middle Initial"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel2 
         Height          =   375
         Left            =   240
         TabIndex        =   18
         Top             =   1080
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "First Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.TextBox Text1 
         Appearance      =   0  'Flat
         Height          =   285
         Left            =   5520
         TabIndex        =   17
         Top             =   -600
         Width           =   2655
      End
      Begin vkUserContolsXP.vkLabel vkLabel21 
         Height          =   375
         Left            =   240
         TabIndex        =   16
         Top             =   2040
         Width           =   975
         _ExtentX        =   1720
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Last Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel1 
         Height          =   375
         Left            =   240
         TabIndex        =   15
         Top             =   480
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "School Year"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel4 
         Height          =   375
         Left            =   5280
         TabIndex        =   14
         Top             =   1560
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Gender"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel7 
         Height          =   375
         Left            =   5280
         TabIndex        =   13
         Top             =   2040
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Tel / CP #"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel8 
         Height          =   375
         Left            =   5280
         TabIndex        =   12
         Top             =   2520
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Address"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel9 
         Height          =   375
         Left            =   240
         TabIndex        =   11
         Top             =   3480
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Previous Schooling"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel20 
         Height          =   375
         Left            =   240
         TabIndex        =   10
         Top             =   3000
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Place of Birth"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin vkUserContolsXP.vkFrame vkFrame3 
      Height          =   3495
      Left            =   240
      TabIndex        =   23
      Top             =   6720
      Width           =   11775
      _ExtentX        =   20770
      _ExtentY        =   6165
      Caption         =   "Parent Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin MSMask.MaskEdBox txtmot 
         Height          =   375
         Left            =   7680
         TabIndex        =   56
         Top             =   2400
         Width           =   3855
         _ExtentX        =   6800
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BackColor       =   16777215
         MaxLength       =   12
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Mask            =   "####-#######"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox txtfot 
         Height          =   375
         Left            =   7680
         TabIndex        =   55
         Top             =   960
         Width           =   3855
         _ExtentX        =   6800
         _ExtentY        =   661
         _Version        =   393216
         Appearance      =   0
         BackColor       =   16777215
         MaxLength       =   12
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Mask            =   "####-#######"
         PromptChar      =   "_"
      End
      Begin vkUserContolsXP.vkLabel vkLabel23 
         Height          =   375
         Left            =   240
         TabIndex        =   41
         Top             =   480
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Father's Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel11 
         Height          =   375
         Left            =   6240
         TabIndex        =   40
         Top             =   480
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Occupation"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel12 
         Height          =   375
         Left            =   240
         TabIndex        =   39
         Top             =   960
         Width           =   2055
         _ExtentX        =   3625
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Office Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel13 
         Height          =   375
         Left            =   6240
         TabIndex        =   38
         Top             =   960
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Office Tel #"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel14 
         Height          =   375
         Left            =   240
         TabIndex        =   37
         Top             =   1440
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Office Address"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel15 
         Height          =   375
         Left            =   240
         TabIndex        =   36
         Top             =   1920
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Mother's Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel16 
         Height          =   375
         Left            =   6240
         TabIndex        =   35
         Top             =   1920
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Occupation"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel17 
         Height          =   375
         Left            =   240
         TabIndex        =   34
         Top             =   2400
         Width           =   2055
         _ExtentX        =   3625
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Office Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel18 
         Height          =   375
         Left            =   6240
         TabIndex        =   33
         Top             =   2400
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Office Tel #"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel19 
         Height          =   375
         Left            =   240
         TabIndex        =   32
         Top             =   2880
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Office Address"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtfname 
         Height          =   375
         Left            =   2160
         TabIndex        =   31
         Top             =   480
         Width           =   3855
         _ExtentX        =   6800
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtfo 
         Height          =   375
         Left            =   7680
         TabIndex        =   30
         Top             =   480
         Width           =   3855
         _ExtentX        =   6800
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtfon 
         Height          =   375
         Left            =   2160
         TabIndex        =   29
         Top             =   960
         Width           =   3855
         _ExtentX        =   6800
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtfoa 
         Height          =   375
         Left            =   2160
         TabIndex        =   28
         Top             =   1440
         Width           =   9375
         _ExtentX        =   16536
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtmname 
         Height          =   375
         Left            =   2160
         TabIndex        =   27
         Top             =   1920
         Width           =   3855
         _ExtentX        =   6800
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtmo 
         Height          =   375
         Left            =   7680
         TabIndex        =   26
         Top             =   1920
         Width           =   3855
         _ExtentX        =   6800
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtmon 
         Height          =   375
         Left            =   2160
         TabIndex        =   25
         Top             =   2400
         Width           =   3855
         _ExtentX        =   6800
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtmoa 
         Height          =   375
         Left            =   2160
         TabIndex        =   24
         Top             =   2880
         Width           =   9375
         _ExtentX        =   16536
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
   End
   Begin VB.Label LblTitle 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Edit Application Strudent Form"
      BeginProperty Font 
         Name            =   "Monotype Corsiva"
         Size            =   24
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   585
      Left            =   2040
      TabIndex        =   1
      Top             =   120
      Width           =   6015
   End
   Begin VB.Image Image2 
      Height          =   975
      Left            =   240
      Picture         =   "frmeditapp.frx":007B
      Stretch         =   -1  'True
      Top             =   0
      Width           =   1695
   End
   Begin VB.Line Line1 
      X1              =   0
      X2              =   13440
      Y1              =   960
      Y2              =   960
   End
   Begin VB.Line Line2 
      X1              =   0
      X2              =   13440
      Y1              =   1080
      Y2              =   1080
   End
End
Attribute VB_Name = "frmeditapp"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'******************
' frmeditapp code *
'******************
Private Const CB_FINDSTRING = &H14C
Private Const CB_SHOWDROPDOWN = &H14F
Private Const LB_FINDSTRING = &H18F
Private Const CB_ERR = (-1)

Private Declare Function SendMessage Lib _
    "user32" Alias "SendMessageA" (ByVal _
    hwnd As Long, ByVal wMsg As Long, _
    ByVal wParam As Long, lParam As Any) _
    As Long

Private Sub cbogender_Click()
Me.cboreligion.SetFocus
End Sub

Private Sub cboreligion_Click()
On Error GoTo er:
If cboreligion.Text = "Others" Then
    Me.txtother.Enabled = True
    Me.txtother.SetFocus
Else
    Me.txtother.Text = ""
    Me.txtother.Enabled = False
End If
er:
End Sub

Private Sub cbors_Click()
Me.txtfirstname.SetFocus
End Sub

Private Sub cmdsave_Click()
If Me.cbors.Text = "" Then
    MsgBox "Please Enter School Year...", vbCritical, ""
    txtrs.SetFocus
Exit Sub
End If
If Me.txtfirstname.Text = "" Then
    MsgBox "Please Enter Student First Name...", vbCritical, ""
    txtfirstname.SetFocus
Exit Sub
End If
If Me.txtmi.Text = "" Then
    MsgBox "Please Enter Student Middle Initial...", vbCritical, ""
    txtmi.SetFocus
Exit Sub
End If
If Me.txtln.Text = "" Then
    MsgBox "Please Enter Student Last Name...", vbCritical, ""
    txtln.SetFocus
Exit Sub
End If
If Me.txtage.Text = "" Then
    MsgBox "Student Age is less than 4 please make the date of birth is correct", vbCritical, ""
    Me.dtpdateofbirth.SetFocus
Exit Sub
End If
If IsNumeric(txtage.Text) = False Then
    MsgBox "Only number required on this field...", vbCritical, ""
    txtage.SetFocus
Exit Sub
End If
If Me.cbogender.Text = "" Then
    MsgBox "Please Enter Student Gender...", vbCritical, ""
    Me.cbogender.SetFocus
Exit Sub
End If
If Me.cboreligion.Text = "" Then
    MsgBox "Please Enter Student Religion...", vbCritical, ""
    Me.cboreligion.SetFocus
Exit Sub
End If
If Me.txtpb.Text = "" Then
    MsgBox "Please Enter Student Place of Birth...", vbCritical, ""
    Me.txtpb.SetFocus
Exit Sub
End If
If Me.txtadd.Text = "" Then
    MsgBox "Please Enter Student Address...", vbCritical, ""
    txtadd.SetFocus
Exit Sub
End If
If Me.txtcpno.Text = "" Then
    MsgBox "Please Enter Student Contact Number...", vbCritical, ""
    txtcpno.SetFocus
Exit Sub
End If
If Me.txtps.Text = "" Then
    MsgBox "Please Enter Student Previous Schooling...", vbCritical, ""
    Me.txtps.SetFocus
Exit Sub
End If
If Me.txtfname.Text = "" Then
    MsgBox "Please Enter Student Father's Name...", vbCritical, ""
    Me.txtfname.SetFocus
Exit Sub
End If
If Me.txtfo.Text = "" Then
    MsgBox "Please Enter Student Father's Occupation...", vbCritical, ""
    Me.txtfo.SetFocus
Exit Sub
End If
If Me.txtmname.Text = "" Then
    MsgBox "Please Enter Student Mother's Name...", vbCritical, ""
    Me.txtmname.SetFocus
Exit Sub
End If
If Me.txtmo.Text = "" Then
    MsgBox "Please Enter Student Mother's Occupation...", vbCritical, ""
    Me.txtmo.SetFocus
Exit Sub
End If

If txtfot.Text = "" Then
    Me.txtfot.Text = "0"
End If
If txtmot.Text = "" Then
    Me.txtfot.Text = "0"
End If

If Me.cboreligion.Text = "Others" Then
    act
    save
    Exit Sub
Else
    act
    save1
End If
End Sub

Private Sub txtstudno_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
'Call cmdok_Click
End If
End Sub
Private Sub cmdcancel_Click()
Call cleartextfields
disabletextfields
cmdsave.Enabled = False
cmdcancel.Enabled = False
Me.txtan.locked = False
Me.txtan.SetFocus
End Sub

Private Sub cmdexit_Click()
Unload Me
End Sub

Private Sub dtpdateofbirth_Change()
Me.Text4.Text = Me.dtpdateofbirth.Year
Me.Text2.Text = Me.dtpdateofbirth.Month
Me.Text3.Text = Me.dtpdateofbirth.Day

If (Me.Text2.Text < Month(Now)) Or (Me.Text1.Text = Year(Now)) And (Me.Text3.Text < Day(Now)) Then
    Me.txtage.Text = (Year(Now) - Me.Text4.Text) - 1
    Exit Sub
Else
    Me.txtage.Text = Year(Now) - Me.Text4.Text
    Exit Sub
End If
End Sub

Private Sub Form_Activate()
Me.txtan.SetFocus
End Sub

Private Sub Form_Load()
Dim i As Integer
Call OpenConnection
txtan.Enabled = True
txtother.Enabled = False
disabletextfields
For i = 1 To rsSCHOOLYEAR.RecordCount 'count all records
cbors.AddItem rsSCHOOLYEAR.Fields(0) 'adding all the records  from the category table
rsSCHOOLYEAR.MoveNext 'move to next record
Next i
cmdsave.Enabled = False
cmdcancel.Enabled = False
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim a As Integer
If cmdsave.Enabled = True Then
    a = MsgBox("Are you sure you want to quit this form with out saving?", vbYesNo + vbQuestion, "")
        If a = vbYes Then
            Call CloseConnection
            Unload Me
        Else
            Cancel = 1
            End If
Else
    Call CloseConnection
    Unload Me
End If
End Sub


Sub enabletextfields()
cbors.Enabled = True
txtan.Enabled = True
txtfirstname.Enabled = True
txtmi.Enabled = True
txtln.Enabled = True
txtage.Enabled = True
cbogender.Enabled = True
cboreligion.Enabled = True
dtpdateofbirth.Enabled = True
txtpb.Enabled = True
txtadd.Enabled = True
txtcpno.Enabled = True
txtps.Enabled = True
txtfname.Enabled = True
txtfo.Enabled = True
txtfon.Enabled = True
txtfot.Enabled = True
txtfoa.Enabled = True
txtmname.Enabled = True
txtmo.Enabled = True
txtmon.Enabled = True
txtmot.Enabled = True
txtmoa.Enabled = True
cmdsave.Enabled = True
cmdcancel.Enabled = True
End Sub

Sub disabletextfields()
cbors.Enabled = False
'txtan.Enabled = False
txtfirstname.Enabled = False
txtmi.Enabled = False
txtln.Enabled = False
txtage.Enabled = False
cbogender.Enabled = False
dtpdateofbirth.Enabled = False
cboreligion.Enabled = False
txtpb.Enabled = False
txtadd.Enabled = False
txtcpno.Enabled = False
txtps.Enabled = False
txtfname.Enabled = False
txtfo.Enabled = False
txtfon.Enabled = False
txtfot.Enabled = False
txtfoa.Enabled = False
txtmname.Enabled = False
txtmo.Enabled = False
txtmon.Enabled = False
txtmot.Enabled = False
txtmoa.Enabled = False
cmdsave.Enabled = False
cmdcancel.Enabled = False
End Sub

Sub cleartextfields()

Dim strMask As String
strMask = Me.txtcpno.Mask
strMask = Me.txtfot.Mask
strMask = Me.txtmot.Mask

cbors.ListIndex = -1
txtfirstname.Text = ""
txtln.Text = ""
txtmi.Text = ""
txtan.Text = ""
txtage.Text = ""
cbogender.ListIndex = -1
cboreligion.ListIndex = -1
txtpb.Text = ""
txtadd.Text = ""
txtcpno.Mask = ""
txtmot.Mask = ""
txtfot.Mask = ""
txtcpno.Text = ""
txtps.Text = ""
txtfname.Text = ""
txtfo.Text = ""
txtfon.Text = ""
txtfot.Text = ""
txtfoa.Text = ""
Me.Text5.Text = ""
Me.Text6.Text = ""
txtmname.Text = ""
txtmo.Text = ""
txtmon.Text = ""
txtmot.Text = ""
txtmoa.Text = ""
Me.Text5.Text = ""
Me.Text6.Text = ""
Me.txtcpno.Mask = strMask
Me.txtfot.Mask = strMask
Me.txtmot.Mask = strMask
End Sub

Private Sub txtage_Change()
If Val(Me.txtage.Text) < 4 Then
    Me.txtage.Text = ""
End If
End Sub

Private Sub txtan_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
    If IsNumeric(Me.txtan.Text) = False Then
        MsgBox "Only number required on this field!!!", vbCritical, ""
        Me.txtan.SetFocus
    Exit Sub
    End If
    enabletextfields
If Len(Me.txtan.Text) <= 0 Then Exit Sub
    Me.cbors.SetFocus

With rsAPPLICATION
    .Find "App_No= '" & Trim(Me.txtan.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
        Me.txtan.locked = True
        Me.txtan.SetFocus
        Me.txtan.Text = .Fields(0)
        Me.cbors.Text = .Fields(1)
        Me.txtfirstname.Text = .Fields(3)
        Me.txtmi.Text = .Fields(4)
        Me.txtln.Text = .Fields(2)
        Me.txtage.Text = .Fields(5)
        Me.cbogender.Text = .Fields(6)
        Me.cboreligion.Text = .Fields(7)
        Me.dtpdateofbirth.Value = .Fields(8)
        Me.txtpb.Text = .Fields(9)
        Me.txtadd.Text = .Fields(10)
        Me.txtcpno.Text = .Fields(11)
        Me.txtps.Text = .Fields(12)
        Me.txtfname.Text = .Fields(13)
        Me.txtfo.Text = .Fields(14)
        Me.txtfon.Text = .Fields(15)
        Me.txtfot.Text = .Fields(16)
        Me.txtfoa.Text = .Fields(17)
        Me.txtmname.Text = .Fields(18)
        Me.txtmo.Text = .Fields(19)
        Me.txtmon.Text = .Fields(20)
        Me.txtmot.Text = .Fields(21)
        Me.txtmoa.Text = .Fields(22)
        Me.Text6.Text = "Edit Applicant #" + Me.txtan.Text
With rsLOGS
.Find "logid ='" & MDIForm1.StatusBar2.Panels(6) & "'", 0, adSearchForward, 1
If Not .EOF Then
    Me.Text5.Text = .Fields(5)
End If
End With
        Else
        MsgBox "Student Application Number Not Exist!!!", vbCritical, ""
        Me.txtan.locked = False
        cleartextfields
        disabletextfields
        End If
End With
End If
End Sub

Public Sub save()
With rsAPPLICATION
        .Fields(1) = Me.cbors.Text
        .Fields(3) = Me.txtfirstname.Text
        .Fields(4) = Me.txtmi.Text
        .Fields(2) = Me.txtln.Text
        .Fields(5) = Me.txtage.Text
        .Fields(6) = Me.cbogender.Text
        .Fields(7) = Me.txtother.Text
        .Fields(8) = Me.dtpdateofbirth.Value
        .Fields(9) = Me.txtpb.Text
        .Fields(10) = Me.txtadd.Text
        .Fields(11) = Me.txtcpno.Text
        .Fields(12) = Me.txtps.Text
        .Fields(13) = Me.txtfname.Text
        .Fields(14) = Me.txtfo.Text
        .Fields(15) = Me.txtfon.Text
        .Fields(16) = Me.txtfot.Text
        .Fields(17) = Me.txtfoa.Text
        .Fields(18) = Me.txtmname.Text
        .Fields(19) = Me.txtmo.Text
        .Fields(20) = Me.txtmon.Text
        .Fields(21) = Me.txtmot.Text
        .Fields(22) = Me.txtmoa.Text
        .Fields(23) = Now
    .Update
    MsgBox "Successfully Updated!!!" & Chr(13) & Chr(13) & "Applicant Number and Student Name!" & Chr(13) & Chr(13) & "Application Number = " & Me.txtan.Text & Chr(13) & "Student Name  = " & Me.txtln.Text & ", " & Me.txtfirstname.Text & " " & Me.txtmi.Text, vbInformation + vbOKOnly, ""
 End With
cleartextfields
disabletextfields
cmdsave.Enabled = False
cmdcancel.Enabled = False
Me.txtan.locked = False
Me.txtan.SetFocus
End Sub

Public Sub save1()
With rsAPPLICATION
    .Fields(1) = Me.cbors.Text
    .Fields(2) = Me.txtln.Text
    .Fields(3) = Me.txtfirstname.Text
    .Fields(4) = Me.txtmi.Text
    .Fields(5) = Me.txtage.Text
    .Fields(6) = Me.cbogender.Text
    .Fields(7) = Me.cboreligion.Text
    .Fields(8) = Me.dtpdateofbirth.Value
    .Fields(9) = Me.txtpb.Text
    .Fields(10) = Me.txtadd.Text
    .Fields(11) = Me.txtcpno.Text
    .Fields(12) = Me.txtps.Text
    .Fields(13) = Me.txtfname.Text
    .Fields(14) = Me.txtfo.Text
    .Fields(15) = Me.txtfon.Text
    .Fields(16) = Me.txtfot.Text
    .Fields(17) = Me.txtfoa.Text
    .Fields(18) = Me.txtmname.Text
    .Fields(19) = Me.txtmo.Text
    .Fields(20) = Me.txtmon.Text
    .Fields(21) = Me.txtmot.Text
    .Fields(22) = Me.txtmoa.Text
    .Fields(23) = Now
    .Update
    MsgBox "Applicant Number and Applicant Name!" & Chr(13) & Chr(13) & Chr(13) & "Applicant Number = " & .Fields(0) & Chr(13) & "Applicant Name  = " & Me.txtln.Text & "," & Me.txtfirstname.Text & " " & Me.txtmi.Text, vbInformation, ""
    MDIForm1.mnuappr.Enabled = True
    MDIForm1.mnuai.Enabled = True
    MDIForm1.mnueditapp.Enabled = True
 End With
cleartextfields
disabletextfields
cmdsave.Enabled = False
cmdcancel.Enabled = False
Me.txtan.locked = False
Me.txtan.SetFocus
End Sub


Private Sub cboreligion_GotFocus()
    SendMessage cboreligion.hwnd, CB_SHOWDROPDOWN, 1, ByVal 0&
End Sub

Private Sub cboreligion_KeyPress(KeyAscii As Integer)
Dim CB As Long
    Dim FindString As String
    
    If KeyAscii < 32 Or KeyAscii > 127 Then Exit Sub
    
    If cboreligion.SelLength = 0 Then
        FindString = cboreligion.Text & Chr$(KeyAscii)
    Else
        FindString = Left$(cboreligion.Text, cboreligion.SelStart) & Chr$(KeyAscii)
    End If
    
    SendMessage cboreligion.hwnd, CB_SHOWDROPDOWN, 1, ByVal 0&

    CB = SendMessage(cboreligion.hwnd, CB_FINDSTRING, -1, ByVal FindString)
    
    If CB <> CB_ERR Then
        cboreligion.ListIndex = CB
        cboreligion.SelStart = Len(FindString)
        cboreligion.SelLength = Len(cboreligion.Text) - cboreligion.SelStart
    End If
    
    KeyAscii = 0
End Sub

Public Sub act()
With rsLOGS
    .Find "logid = '" & MDIForm1.StatusBar2.Panels(6) & "'", 0, adSearchForward, 1
If Not .EOF Then
    .Fields(5) = Me.Text5.Text + ", " + Me.Text6.Text
    .Update
End If
End With
End Sub

Private Sub txtother_KeyPress(KeyAscii As Integer)
If (KeyAscii < 48 Or KeyAscii > 57) And KeyAscii <> 8 Then
KeyAscii = 0
End If
End Sub
