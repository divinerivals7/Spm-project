VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Begin VB.Form frmpenalty 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Penalty"
   ClientHeight    =   2460
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   6300
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2460
   ScaleWidth      =   6300
   StartUpPosition =   2  'CenterScreen
   Begin vbskpro.Skinner Skinner1 
      Left            =   120
      Top             =   2640
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkTextBox aa 
      Height          =   375
      Left            =   1560
      TabIndex        =   0
      Top             =   3000
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   661
      Text            =   "Penalty"
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   615
      Left            =   3480
      TabIndex        =   1
      Top             =   1560
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   1085
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   1095
      Left            =   240
      TabIndex        =   2
      Top             =   240
      Width           =   5775
      _ExtentX        =   10186
      _ExtentY        =   1931
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkLabel vkLabel1 
         Height          =   375
         Left            =   120
         TabIndex        =   4
         Top             =   480
         Width           =   4335
         _ExtentX        =   7646
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Enter the new amount you want for the penalty"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtpenalty 
         Height          =   375
         Left            =   4680
         TabIndex        =   3
         Top             =   480
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Alignment       =   2
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
   End
   Begin vkUserContolsXP.vkCommand cmdcancel 
      Height          =   615
      Left            =   4800
      TabIndex        =   5
      Top             =   1560
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   1085
      Caption         =   "&Clear"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel2 
      Height          =   255
      Left            =   240
      TabIndex        =   6
      Top             =   1920
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   450
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "(ex: 5% = 0.05 , 10% = 0.10)"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmpenalty"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'******************
' frmpenalty code *
'******************
Private Sub cmdcancel_Click()
Me.txtpenalty.Text = ""
End Sub

Private Sub cmdsave_Click()
If IsNumeric(Me.txtpenalty.Text) = False Then
    MsgBox "Only number required on this field!!", vbCritical, ""
    Me.txtpenalty.SetFocus
Exit Sub
End If
pen
End Sub

Private Sub Form_Activate()
Me.txtpenalty.SetFocus
End Sub

Private Sub Form_Load()
OpenConnection
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim a As Integer
If Me.txtpenalty.Text <> "" Then
    a = MsgBox("Are you sure you want to quit this form with out saving?", vbYesNo + vbQuestion, "")
        If a = vbYes Then
            Call CloseConnection
            Unload Me
        Else
            Cancel = 1
            End If
Else
    Call CloseConnection
    Unload Me
End If
End Sub

Public Sub pen()
With rsDP
    .Find "Name= '" & Trim(Me.aa.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
    .Fields(2) = Me.txtpenalty.Text
    .Update
    MsgBox "Successfully save!!!", vbInformation, ""
    Me.txtpenalty.Text = ""
    End If
End With
End Sub

