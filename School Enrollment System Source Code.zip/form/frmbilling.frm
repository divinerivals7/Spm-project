VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Begin VB.Form frmbilling 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Payment"
   ClientHeight    =   6960
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   10425
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6960
   ScaleWidth      =   10425
   StartUpPosition =   1  'CenterOwner
   Begin VB.TextBox Text5 
      Height          =   1095
      Left            =   2160
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   30
      Top             =   7200
      Width           =   2055
   End
   Begin VB.TextBox Text6 
      Height          =   1095
      Left            =   4320
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   29
      Top             =   7200
      Width           =   2055
   End
   Begin VB.TextBox Text3 
      Height          =   375
      Left            =   10560
      TabIndex        =   26
      Text            =   "Text3"
      Top             =   3000
      Width           =   975
   End
   Begin VB.TextBox Text2 
      Height          =   375
      Left            =   10560
      TabIndex        =   25
      Text            =   "Text2"
      Top             =   5040
      Width           =   735
   End
   Begin VB.TextBox txtpen 
      Height          =   375
      Left            =   10560
      TabIndex        =   24
      Text            =   "Text3"
      Top             =   5400
      Width           =   735
   End
   Begin VB.TextBox txtdis 
      Height          =   375
      Left            =   10560
      TabIndex        =   23
      Text            =   "Text3"
      Top             =   3600
      Width           =   735
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   10560
      TabIndex        =   20
      Text            =   "Text1"
      Top             =   3960
      Width           =   735
   End
   Begin MSAdodcLib.Adodc adobilling 
      Height          =   330
      Left            =   -960
      Top             =   2880
      Visible         =   0   'False
      Width           =   1200
      _ExtentX        =   2117
      _ExtentY        =   582
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   2
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   3
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   "DSN=MMIC"
      OLEDBString     =   ""
      OLEDBFile       =   ""
      DataSourceName  =   "MMIC"
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   "BILLING"
      Caption         =   "Adodc1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   -480
      Top             =   -240
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   3015
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   9735
      _ExtentX        =   17171
      _ExtentY        =   5318
      Caption         =   "Student Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkTextBox txtsection 
         Height          =   375
         Left            =   1920
         TabIndex        =   28
         Top             =   1920
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel4 
         Height          =   375
         Left            =   240
         TabIndex        =   27
         Top             =   1920
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Section"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel3 
         Height          =   375
         Left            =   240
         TabIndex        =   19
         Top             =   2400
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "School Year"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtsy 
         Height          =   375
         Left            =   1920
         TabIndex        =   18
         Top             =   2400
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel1 
         Height          =   375
         Left            =   240
         TabIndex        =   7
         Top             =   480
         Width           =   1575
         _ExtentX        =   2778
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Student Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtstudno 
         Height          =   375
         Left            =   1920
         TabIndex        =   6
         Top             =   480
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkCommand cmdenter 
         Height          =   375
         Left            =   4560
         TabIndex        =   5
         Top             =   480
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         Caption         =   "&Enter"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel2 
         Height          =   375
         Left            =   240
         TabIndex        =   4
         Top             =   960
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Student Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtfn 
         Height          =   375
         Left            =   1920
         TabIndex        =   3
         Top             =   960
         Width           =   7455
         _ExtentX        =   13150
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   4210816
      End
      Begin vkUserContolsXP.vkLabel vkLabel5 
         Height          =   375
         Left            =   240
         TabIndex        =   2
         Top             =   1440
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Grade Level"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtgl 
         Height          =   375
         Left            =   1920
         TabIndex        =   1
         Top             =   1440
         Width           =   2415
         _ExtentX        =   4260
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
   End
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   2775
      Left            =   360
      TabIndex        =   8
      Top             =   3360
      Width           =   9735
      _ExtentX        =   17171
      _ExtentY        =   4895
      Caption         =   "Payment"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkCheck chkpenalty 
         Height          =   375
         Left            =   1920
         TabIndex        =   22
         Top             =   360
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Penalty"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkCheck chkdiscount 
         Height          =   375
         Left            =   360
         TabIndex        =   21
         Top             =   360
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Discount"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel7 
         Height          =   375
         Left            =   360
         TabIndex        =   14
         Top             =   960
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Total Charges"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txttc 
         Height          =   375
         Left            =   1920
         TabIndex        =   13
         Top             =   960
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Alignment       =   1
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel8 
         Height          =   375
         Left            =   360
         TabIndex        =   12
         Top             =   1560
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Total Payment"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txttp 
         Height          =   375
         Left            =   1920
         TabIndex        =   11
         Top             =   1560
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Alignment       =   1
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel9 
         Height          =   375
         Left            =   360
         TabIndex        =   10
         Top             =   2160
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Total Balance"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtbalance 
         Height          =   375
         Left            =   1920
         TabIndex        =   9
         Top             =   2160
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Alignment       =   1
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
   End
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   495
      Left            =   7560
      TabIndex        =   15
      Top             =   6240
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   873
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmdprint 
      Height          =   495
      Left            =   6240
      TabIndex        =   16
      Top             =   6240
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   873
      Caption         =   "&Print"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmdcancel 
      Height          =   495
      Left            =   8880
      TabIndex        =   17
      Top             =   6240
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   873
      Caption         =   "&Clear"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmbilling"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*****************
' frmbilling code*
'*****************
Private Sub chkdiscount_Click()
Dim temp, q, w As Integer
Dim rsdis As New ADODB.Recordset
rsdis.Open "select Amount from DP where Name = '" & "Discount" & "'", con, adOpenKeyset, adLockOptimistic
Me.txtdis.Text = rsdis!Amount
On Error GoTo err:
With rsBILLING
    .MoveFirst
        While .EOF = False
            If .Fields(1) = Me.txtstudno.Text Then
                If .Fields(11) = "Y" Then
                    MsgBox "Student already have discount!!!", vbCritical, ""
                    cmdsave.Enabled = False
                    Me.chkdiscount.Value = vbUnchecked
                    Exit Sub
                End If
            End If
        .MoveNext
        Wend
    End With
err:
If ((Me.chkdiscount.Value = vbChecked) And (Me.txttc.Text = "")) Then
    MsgBox "No record to compute for discount!!!", vbCritical, ""
    Me.chkdiscount.Value = vbUnchecked
    cleartextfields
    Exit Sub
End If

If Me.chkdiscount.Value = vbChecked Then
    temp = Me.txttc.Text * Me.txtdis.Text
    Me.Text1.Text = temp
    Me.txttc.Text = Me.txttc.Text - Me.Text1.Text
    Me.txtbalance.Text = Me.txttc.Text - Me.txttp.Text
    Me.chkpenalty.Value = vbGrayed
    Me.Text3.Text = "Y"
End If

If Me.chkdiscount.Value = vbUnchecked Then
    Me.txttc.Text = Val(Me.txttc.Text) + Val(Me.Text1.Text)
    Me.txtbalance.Text = Val(Me.txttc.Text) + Val(Me.txttp.Text)
    Me.chkpenalty.Value = vbUnchecked
    Me.Text3.Text = "N"
End If
End Sub

Private Sub chkpenalty_Click()
Dim temp, q, w As Integer
Dim rspen As New ADODB.Recordset
rspen.Open "select Amount from DP where Name = '" & "Penalty" & "'", con, adOpenKeyset, adLockOptimistic
Me.txtpen.Text = rspen!Amount

If ((Me.chkpenalty.Value = vbChecked) And (Me.txttc.Text = "")) Then
    MsgBox "No record to compute for penalty!!!", vbCritical, ""
    Me.chkpenalty.Value = vbUnchecked
    Exit Sub
End If

If Me.chkpenalty.Value = vbChecked Then
    temp = Me.txttc.Text * Me.txtpen.Text
    Me.Text2.Text = temp
    Me.txttc.Text = Val(Me.txttc.Text) + Val(Me.Text2.Text)
    Me.txtbalance.Text = Val(Me.txttc.Text) - Val(Me.txttp.Text)
    Me.chkdiscount.Value = vbGrayed
End If

If Me.chkpenalty.Value = vbUnchecked Then
    Me.txttc.Text = Val(Me.txttc.Text) - Val(Me.Text2.Text)
    Me.txtbalance.Text = Val(Me.txttc.Text) - Val(Me.txttp.Text)
    Me.chkdiscount.Value = vbUnchecked
End If
End Sub

Private Sub cmdcancel_Click()
Call cleartextfields
Me.txtstudno.SetFocus
cmdsave.Enabled = False
cmdprint.Enabled = False
Me.txttp.locked = True
Me.txtstudno.locked = False
Me.chkdiscount.Value = vbUnchecked
Me.chkpenalty.Value = vbUnchecked
End Sub

Private Sub cmdexit_Click()
Unload Me
End Sub


Private Sub cmdenter_Click()
If Len(Me.txtstudno.Text) <= 0 Then Exit Sub

With rsBILLING
    .Find "Student_Number= '" & Trim(Me.txtstudno.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
    
End If
End With

With rsASSESSMENT
    .Find "Student_Number= '" & Trim(Me.txtstudno.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
        Me.txtstudno.locked = True
        Me.txttp.locked = False
        Me.txttp.SetFocus
        Me.txtstudno.Text = .Fields(1)
        Me.txtfn.Text = .Fields(2)
        Me.txtgl.Text = .Fields(3)
        Me.txtsection.Text = .Fields(4)
        Me.txtsy.Text = .Fields(5)
        Me.txttc.Text = .Fields(6)
        Me.txtbalance.Text = 0
        Me.txttp.Text = 0
        MDIForm1.StatusBar2.Panels(3) = .Fields(0)
    
Me.Text6.Text = "Payment Received Student #" + Me.txtstudno.Text

With rsLOGS
.Find "logid ='" & MDIForm1.StatusBar2.Panels(6) & "'", 0, adSearchForward, 1
If Not .EOF Then
    Me.Text5.Text = .Fields(5)
End If
End With
    
Else
        MsgBox "Student Information Not Exist!!!", vbCritical, ""
        cleartextfields
        cmdsave.Enabled = True
        Me.txttp.locked = True
        Me.txtstudno.locked = False
        Exit Sub
        End If

If Me.txttc.Text = 0 Then
    Me.txttp.Text = 0
    Me.txtbalance.Text = 0
    cmdsave.Enabled = False
    cmdprint.Enabled = False
    Me.txttp.locked = True
    Exit Sub
End If
End With
cmdsave.Enabled = True
cmdprint.Enabled = True
End Sub

Private Sub cmdprint_Click()
Dim rspart2 As New ADODB.Recordset
rspart2.Open "Select * from PARTICULAR where Grade_Level like '" & Trim(Me.txtgl.Text) & "%'", con, adOpenKeyset, adLockOptimistic
Set rptpayment.DataSource = rspart2
        
        rptpayment.Sections(2).Controls("ld").Caption = Now
        rptpayment.Sections(2).Controls("label21").Caption = Now
        rptpayment.Sections(2).Controls("L1").Caption = Me.txtstudno.Text
        rptpayment.Sections(2).Controls("label18").Caption = Me.txtstudno.Text
        rptpayment.Sections(2).Controls("L2").Caption = Me.txtfn.Text
        rptpayment.Sections(2).Controls("label23").Caption = Me.txtfn.Text
        rptpayment.Sections(2).Controls("L7").Caption = Me.txtgl.Text
        rptpayment.Sections(2).Controls("label20").Caption = Me.txtgl.Text
        rptpayment.Sections(2).Controls("L8").Caption = Me.txtsy.Text
        rptpayment.Sections(2).Controls("Label25").Caption = Me.txtsy.Text
        rptpayment.Sections(2).Controls("tc").Caption = Me.txttc.Text
        rptpayment.Sections(2).Controls("label30").Caption = Me.txttc.Text
        rptpayment.Sections(2).Controls("tp").Caption = Me.txttp.Text
        rptpayment.Sections(2).Controls("label31").Caption = Me.txttp.Text
        rptpayment.Sections(2).Controls("tb").Caption = Me.txtbalance.Text
        rptpayment.Sections(2).Controls("label32").Caption = Me.txtbalance.Text
        rptpayment.Sections(2).Controls("L17").Caption = Me.txtsection.Text
        rptpayment.Sections(2).Controls("Label36").Caption = Me.txtsection.Text
        rptpayment.Sections(2).Controls("Label39").Caption = MDIForm1.StatusBar1.Panels(5).Text
        rptpayment.Sections("Section5").Controls("labelu").Caption = MDIForm1.StatusBar1.Panels(5).Text
        rptpayment.Show vbModal
End Sub

Private Sub cmdsave_Click()
If txttp.Text = "" Then
   txttp.Text = 0
End If

If Me.txtbalance.Text < 0 Then
    MsgBox "Student Balance cannot be less than 0", vbInformation + vbOKOnly, ""
    Me.txttp.SetFocus
    Exit Sub
End If

act
With rsBILLING
    .AddNew 'add new information
    .Fields(1) = Me.txtstudno.Text
    .Fields(2) = Me.txtfn.Text
    .Fields(3) = Me.txtgl.Text
    .Fields(4) = Me.txtsection.Text
    .Fields(5) = Me.txtsy.Text
    .Fields(6) = Me.txttc.Text
    .Fields(7) = Me.txttp.Text
    .Fields(8) = Me.txtbalance.Text
    .Fields(9) = Now
    .Fields(10) = MDIForm1.StatusBar2.Panels(3)
    .Fields(11) = Me.Text3.Text
    .Fields(12) = MDIForm1.StatusBar2.Panels(2)
    .Update
    
    MDIForm1.StatusBar2.Panels(4) = .Fields(0)
    MsgBox "Information Save!!", vbInformation + vbOKOnly, ""
    Me.txtstudno.locked = False
    Me.chkdiscount.Value = vbUnchecked
    Me.chkpenalty.Value = vbUnchecked
    Me.txttp.locked = True
    MDIForm1.mnubr.Enabled = True
End With

With rsREGISTRATION
    .Find "Student_Number = '" & Trim(Me.txtstudno.Text) & "'", 0, adSearchForward, 1
 If Not .EOF Then
    .Fields(17) = MDIForm1.StatusBar2.Panels(4)
    .Update
End If
End With

With rsASSESSMENT
    .Find "Student_Number= '" & Trim(Me.txtstudno.Text) & "'", 0, adSearchForward, 1
If Not .EOF Then
    .Fields(6) = Me.txtbalance.Text
    .Update
    CloseConnection
End If
End With

OpenConnection
cleartextfields
cmdsave.Enabled = False
cmdprint.Enabled = False
Me.txtstudno.SetFocus
End Sub

Private Sub Form_Load()
OpenConnection
Me.txttp.locked = True
cmdsave.Enabled = False
cmdprint.Enabled = False
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim a As Integer
If cmdsave.Enabled = True Then
    a = MsgBox("Are you sure you want to quit this form with out saving?", vbYesNo + vbQuestion, "")
        If a = vbYes Then
            Call CloseConnection
            Unload Me
        Else
            Cancel = 1
            End If
Else
    Call CloseConnection
    Unload Me
End If
End Sub

Private Sub txtstudno_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
    Call cmdenter_Click
End If
End Sub

Private Sub Form_Activate()
Me.txtstudno.SetFocus
End Sub

Sub enabletextfields()
txtstudno.Enabled = True
txtfn.Enabled = True
txtgl.Enabled = True
txtsection.Enabled = True
txttc.Enabled = True
txttp.Enabled = True
txtbalance.Enabled = True
End Sub

Sub disabletextfields()
txtstudno.Enabled = False
txtfn.Enabled = False
txtgl.Enabled = False
txttc.Enabled = False
txttp.Enabled = False
txtbalance.Enabled = False
txtsection.Enabled = False
End Sub

Sub cleartextfields()
Me.Text5.Text = ""
Me.Text6.Text = ""
Me.Text1.Text = ""
Me.Text2.Text = ""
txtstudno.Text = ""
txtfn.Text = ""
txtgl.Text = ""
txtsection.Text = ""
txttc.Text = ""
txttp.Text = ""
txtsy.Text = ""
txtbalance.Text = ""
End Sub

Private Sub txttp_Change()
Dim a As String
a = (Val(Me.txttc.Text)) - (Val(Me.txttp.Text))
Me.txtbalance.Text = a
End Sub

Private Sub txttp_KeyPress(KeyAscii As Integer)
If (KeyAscii < 48 Or KeyAscii > 57) And KeyAscii <> 8 Then
    KeyAscii = 0
End If
End Sub

Public Sub act()
With rsLOGS
    .Find "logid = '" & MDIForm1.StatusBar2.Panels(6) & "'", 0, adSearchForward, 1
If Not .EOF Then
    .Fields(5) = Me.Text5.Text + ", " + Me.Text6.Text
    .Update
End If
End With
End Sub
