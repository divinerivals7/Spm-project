VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Begin VB.Form frmbyacc 
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   2400
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4125
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2400
   ScaleWidth      =   4125
   StartUpPosition =   2  'CenterScreen
   Begin vbskpro.Skinner Skinner1 
      Left            =   -120
      Top             =   3120
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   1335
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   3615
      _ExtentX        =   6376
      _ExtentY        =   2355
      Caption         =   "Select Accountant Name"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin VB.ComboBox cboaccountantname 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         Left            =   600
         Style           =   2  'Dropdown List
         TabIndex        =   2
         Top             =   600
         Width           =   2415
      End
   End
   Begin vkUserContolsXP.vkCommand cmdok 
      Height          =   495
      Left            =   2520
      TabIndex        =   1
      Top             =   1680
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Ok"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmbyacc"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'***************
' frmbyacc code*
'***************

Private Sub cboaccountantname_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
cmdok_Click
End If
End Sub

Private Sub cmdok_Click()
Dim rs As New ADODB.Recordset
If Me.cboaccountantname.Text = "" Then
    MsgBox "please select accountant name..", vbCritical, ""
    Exit Sub
Else
    rs.Open "select * from billing where Received_By = '" & Me.cboaccountantname.Text & "'", con, adOpenKeyset, adLockOptimistic
    Set rptpaymentbyacc.DataSource = rs
    rptpaymentbyacc.Sections(2).Controls("acc").Caption = Me.cboaccountantname.Text
    rptpaymentbyacc.Sections("Section5").Controls("l1").Caption = Now
    rptpaymentbyacc.Sections("Section5").Controls("l2").Caption = MDIForm1.StatusBar1.Panels(5).Text
    rptpaymentbyacc.Show vbModal
End If
End Sub

Private Sub Form_Activate()
Me.cboaccountantname.SetFocus
End Sub

Private Sub Form_Load()
OpenConnection
Dim rs As New ADODB.Recordset
rs.Open "select distinct Username from userlevel where user_level = '" & "accountant" & "'", con, adOpenKeyset, adLockOptimistic
If rs.EOF Then Exit Sub
rs.MoveFirst
    Do While Not rs.EOF
        Me.cboaccountantname.AddItem rs!UserName
        rs.MoveNext
    Loop
    rs.Close
End Sub

Private Sub Form_Unload(Cancel As Integer)
CloseConnection
End Sub
