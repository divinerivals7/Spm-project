VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Begin VB.Form frmrptsy 
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   2295
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4260
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2295
   ScaleWidth      =   4260
   StartUpPosition =   2  'CenterScreen
   Begin vbskpro.Skinner Skinner1 
      Left            =   240
      Top             =   1920
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin VB.ComboBox cbosy 
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      Left            =   1920
      Style           =   2  'Dropdown List
      TabIndex        =   0
      Top             =   840
      Width           =   1815
   End
   Begin vkUserContolsXP.vkLabel vkLabel9 
      Height          =   375
      Left            =   600
      TabIndex        =   1
      Top             =   840
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "School Year"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   1335
      Left            =   360
      TabIndex        =   2
      Top             =   240
      Width           =   3615
      _ExtentX        =   6376
      _ExtentY        =   2355
      Caption         =   "Search school year to be printed"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
   End
   Begin vkUserContolsXP.vkCommand cmdok 
      Height          =   495
      Left            =   2640
      TabIndex        =   3
      Top             =   1680
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Ok"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmrptsy"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'***************
' frmrptsy code*
'***************
Private Sub cbosy_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
    If Me.cbosy.Text = "" Then
        MsgBox "Please select school year", vbCritical, ""
        Exit Sub
    Else
        cmdok_Click
End If
End If
End Sub

Private Sub cmdok_Click()
Dim rssy As New ADODB.Recordset
If Me.cbosy.Text = "" Then
    MsgBox "please select school year..", vbCritical, ""
    Exit Sub
Else
    rssy.Open "select * from registration where School_Year = '" & frmrptsy.cbosy.Text & "'", con, adOpenKeyset, adLockOptimistic
    Set rptstudbySY.DataSource = rssy

    rptstudbySY.Sections(2).Controls("lblsy").Caption = Me.cbosy.Text
    rptstudbySY.Sections("Section5").Controls("label21").Caption = MDIForm1.StatusBar1.Panels(5).Text
    rptstudbySY.Sections("Section5").Controls("label23").Caption = Now
    rptstudbySY.Show vbModal
End If
End Sub

Private Sub Form_Load()
OpenConnection
For i = 1 To rsSCHOOLYEAR.RecordCount 'count all records
cbosy.AddItem rsSCHOOLYEAR.Fields(0) 'adding all the records  from the category table
rsSCHOOLYEAR.MoveNext 'move to next record
Next i
End Sub

Private Sub Form_Unload(Cancel As Integer)
CloseConnection
End Sub
