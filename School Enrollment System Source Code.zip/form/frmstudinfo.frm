VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Begin VB.Form frmstudinfo 
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   9450
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   13710
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   9450
   ScaleWidth      =   13710
   StartUpPosition =   2  'CenterScreen
   Begin VB.ComboBox cbosearch 
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      ItemData        =   "frmstudinfo.frx":0000
      Left            =   1440
      List            =   "frmstudinfo.frx":000D
      Style           =   2  'Dropdown List
      TabIndex        =   35
      Top             =   1560
      Width           =   2175
   End
   Begin vkUserContolsXP.vkLabel lblrecords 
      Height          =   375
      Left            =   12960
      TabIndex        =   6
      Top             =   1560
      Width           =   495
      _ExtentX        =   873
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Alignment       =   2
   End
   Begin vkUserContolsXP.vkLabel vkLabel2 
      Height          =   375
      Left            =   11040
      TabIndex        =   5
      Top             =   1560
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Number of Records"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel1 
      Height          =   375
      Left            =   240
      TabIndex        =   4
      Top             =   1560
      Width           =   2415
      _ExtentX        =   4260
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Search by:"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkTextBox txtsearch 
      Height          =   375
      Left            =   3840
      TabIndex        =   3
      Top             =   1560
      Width           =   2535
      _ExtentX        =   4471
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Alignment       =   2
      BorderColor     =   4210816
      LegendForeColor =   14117668
   End
   Begin MSDataGridLib.DataGrid dtgsi 
      Bindings        =   "frmstudinfo.frx":0038
      Height          =   6495
      Left            =   360
      TabIndex        =   2
      Top             =   2520
      Width           =   5850
      _ExtentX        =   10319
      _ExtentY        =   11456
      _Version        =   393216
      BackColor       =   12640511
      HeadLines       =   1
      RowHeight       =   19
      BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ColumnCount     =   2
      BeginProperty Column00 
         DataField       =   ""
         Caption         =   ""
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
      EndProperty
      BeginProperty Column01 
         DataField       =   ""
         Caption         =   ""
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
      EndProperty
      SplitCount      =   1
      BeginProperty Split0 
         BeginProperty Column00 
         EndProperty
         BeginProperty Column01 
         EndProperty
      EndProperty
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   9120
      Top             =   0
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   6975
      Left            =   240
      TabIndex        =   1
      Top             =   2160
      Width           =   6135
      _ExtentX        =   10821
      _ExtentY        =   12303
      Caption         =   "Student Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
   End
   Begin vkUserContolsXP.vkTextBox txtstudno 
      Height          =   375
      Left            =   9120
      TabIndex        =   7
      Top             =   2520
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkTextBox txtstudname 
      Height          =   375
      Left            =   9120
      TabIndex        =   8
      Top             =   3000
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkTextBox txtgender 
      Height          =   375
      Left            =   9120
      TabIndex        =   9
      Top             =   3480
      Width           =   735
      _ExtentX        =   1296
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkTextBox txtage 
      Height          =   375
      Left            =   9120
      TabIndex        =   10
      Top             =   3960
      Width           =   735
      _ExtentX        =   1296
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkTextBox txtaddress 
      Height          =   375
      Left            =   9120
      TabIndex        =   11
      Top             =   4920
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkTextBox txtcpno 
      Height          =   375
      Left            =   9120
      TabIndex        =   12
      Top             =   5400
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkTextBox txtgl 
      Height          =   375
      Left            =   9120
      TabIndex        =   13
      Top             =   5880
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin MSAdodcLib.Adodc Adodc1 
      Height          =   375
      Left            =   6480
      Top             =   600
      Visible         =   0   'False
      Width           =   1815
      _ExtentX        =   3201
      _ExtentY        =   661
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   2
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   3
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   "DSN=MMIC"
      OLEDBString     =   ""
      OLEDBFile       =   ""
      DataSourceName  =   "MMIC"
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   "REGISTRATION"
      Caption         =   "Adodc1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin vkUserContolsXP.vkLabel vkLabel3 
      Height          =   375
      Left            =   6720
      TabIndex        =   14
      Top             =   2520
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Student Number"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel4 
      Height          =   375
      Left            =   6720
      TabIndex        =   15
      Top             =   3000
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Student Name"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel5 
      Height          =   375
      Left            =   6720
      TabIndex        =   16
      Top             =   3960
      Width           =   615
      _ExtentX        =   1085
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Age"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel6 
      Height          =   375
      Left            =   6720
      TabIndex        =   17
      Top             =   3480
      Width           =   855
      _ExtentX        =   1508
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Gender"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel7 
      Height          =   375
      Left            =   6720
      TabIndex        =   18
      Top             =   4920
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Address"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel8 
      Height          =   375
      Left            =   6720
      TabIndex        =   19
      Top             =   5400
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Contact Number"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel9 
      Height          =   375
      Left            =   6720
      TabIndex        =   20
      Top             =   5880
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Grade Level"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel10 
      Height          =   375
      Left            =   6720
      TabIndex        =   21
      Top             =   6360
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "School Year"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkTextBox txtsy 
      Height          =   375
      Left            =   9120
      TabIndex        =   22
      Top             =   6360
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkTextBox txtfname 
      Height          =   375
      Left            =   9120
      TabIndex        =   24
      Top             =   6840
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkLabel vkLabel11 
      Height          =   375
      Left            =   6720
      TabIndex        =   25
      Top             =   6840
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Father's Name"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel12 
      Height          =   375
      Left            =   6720
      TabIndex        =   26
      Top             =   7320
      Width           =   2295
      _ExtentX        =   4048
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Father's Contact number"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkTextBox txtfcpno 
      Height          =   375
      Left            =   9120
      TabIndex        =   27
      Top             =   7320
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkTextBox txtmname 
      Height          =   375
      Left            =   9120
      TabIndex        =   28
      Top             =   7800
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkLabel vkLabel13 
      Height          =   375
      Left            =   6720
      TabIndex        =   29
      Top             =   7800
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Mother's Name"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel14 
      Height          =   375
      Left            =   6720
      TabIndex        =   30
      Top             =   8280
      Width           =   2295
      _ExtentX        =   4048
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Mother's Contact number"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkTextBox txtmcpno 
      Height          =   375
      Left            =   9120
      TabIndex        =   31
      Top             =   8280
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkTextBox vkTextBox1 
      Height          =   375
      Left            =   13800
      TabIndex        =   32
      Top             =   3960
      Width           =   735
      _ExtentX        =   1296
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkTextBox txtbday 
      Height          =   375
      Left            =   9120
      TabIndex        =   33
      Top             =   4440
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkLabel vkLabel15 
      Height          =   375
      Left            =   6720
      TabIndex        =   34
      Top             =   4440
      Width           =   1095
      _ExtentX        =   1931
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Birthday"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   6975
      Left            =   6480
      TabIndex        =   23
      Top             =   2160
      Width           =   6975
      _ExtentX        =   12303
      _ExtentY        =   12303
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkTextBox txtsection 
         Height          =   375
         Left            =   5760
         TabIndex        =   37
         Top             =   3720
         Width           =   975
         _ExtentX        =   1720
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel16 
         Height          =   375
         Left            =   4920
         TabIndex        =   36
         Top             =   3720
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Section"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin VB.Image Image1 
      Height          =   1095
      Left            =   240
      Picture         =   "frmstudinfo.frx":004D
      Stretch         =   -1  'True
      Top             =   120
      Width           =   1695
   End
   Begin VB.Line Line2 
      X1              =   0
      X2              =   13680
      Y1              =   1320
      Y2              =   1320
   End
   Begin VB.Line Line1 
      X1              =   0
      X2              =   13680
      Y1              =   1200
      Y2              =   1200
   End
   Begin VB.Label LblTitle 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Student Information "
      BeginProperty Font 
         Name            =   "Monotype Corsiva"
         Size            =   24
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   585
      Left            =   1920
      TabIndex        =   0
      Top             =   360
      Width           =   3975
   End
End
Attribute VB_Name = "frmstudinfo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*****************
'frmstudinfo code*
'*****************
Option Explicit
Private byt_ColSort As Byte

Private Sub cmdexit_Click()
CloseConnection
Unload Me
End Sub

Private Sub cbosearch_Click()
Me.txtsearch.Text = ""
Me.txtsearch.Enabled = True
Me.txtsearch.SetFocus
End Sub

Private Sub dtgsi_Click()
With Adodc1.Recordset
    If .RecordCount < 1 Then MsgBox "No Data Selected", vbExclamation: Exit Sub
End With
dtgsi.MarqueeStyle = dbgHighlightRow
Me.txtstudno.Text = dtgsi.Columns(0)
Me.txtstudname.Text = dtgsi.Columns(1) & ", " & dtgsi.Columns(2) & " " & dtgsi.Columns(3)
Me.txtage.Text = dtgsi.Columns(4)
Me.txtgender.Text = dtgsi.Columns(5)
Me.txtbday.Text = dtgsi.Columns(6)
Me.txtaddress.Text = dtgsi.Columns(7)
Me.txtcpno.Text = dtgsi.Columns(8)
Me.txtgl.Text = dtgsi.Columns(9)
Me.txtsection.Text = dtgsi.Columns(10)
Me.txtsy.Text = dtgsi.Columns(11)
Me.txtfname.Text = dtgsi.Columns(12)
Me.txtfcpno.Text = dtgsi.Columns(13)
Me.txtmname.Text = dtgsi.Columns(14)
Me.txtmcpno.Text = dtgsi.Columns(15)
End Sub

Private Sub dtgsi_HeadClick(ByVal ColIndex As Integer)
With Adodc1.Recordset
        If (.Sort = .Fields(ColIndex).[Name] & " Asc") Then
            .Sort = .Fields(ColIndex).[Name] & " Desc"
        Else
            .Sort = .Fields(ColIndex).[Name] & " Asc"
        End If
    End With
End Sub

Private Sub Form_Load()
OpenConnection
Me.txtsearch.Enabled = False
dbgrid
End Sub

Private Sub Form_Unload(Cancel As Integer)
CloseConnection
Unload Me
End Sub

Private Sub Form_Activate()
Me.lblrecords.Caption = rsREGISTRATION.RecordCount
Me.cbosearch.SetFocus
End Sub

Private Sub txtsearch_Change()
If txtsearch.Text = "" Then
clear
Set dtgsi.DataSource = rsREGISTRATION
dbgrid
Exit Sub
End If
Dim rssearch As New ADODB.Recordset

If cbosearch.Text = "Student_Number" Then
rssearch.Open "select * from REGISTRATION where Student_Number like '" & Trim(txtsearch.Text) & "%'", con, adOpenKeyset, adLockOptimistic
Set dtgsi.DataSource = rssearch
searchid
dbgrid
    
ElseIf cbosearch.Text = "First Name" Then
rssearch.Open " select * from REGISTRATION where FirstName like '" & Trim(txtsearch.Text) & "%'", con, adOpenKeyset, adLockOptimistic
Set dtgsi.DataSource = rssearch
searchfn
dbgrid

ElseIf cbosearch.Text = "Last Name" Then
rssearch.Open " select * from REGISTRATION where LastName like '" & txtsearch.Text & "%'", con, adOpenKeyset, adLockOptimistic
Set dtgsi.DataSource = rssearch
searchln
dbgrid
End If
End Sub
Public Sub dbgrid()
dtgsi.Columns(0).Width = 1400
dtgsi.Columns(1).Width = 1500
dtgsi.Columns(2).Width = 1500
dtgsi.Columns(3).Width = 500
dtgsi.Columns(4).Width = 500
dtgsi.Columns(5).Width = 1000
dtgsi.Columns(6).Width = 1000
End Sub

Public Sub searchid()
With rsREGISTRATION
.MoveFirst
    While .EOF = False
    If .Fields(0) = Me.txtsearch.Text Then
        Me.txtstudno.Text = dtgsi.Columns(0)
        Me.txtstudname.Text = dtgsi.Columns(1) & ", " & dtgsi.Columns(2) & " " & dtgsi.Columns(3)
        Me.txtage.Text = dtgsi.Columns(4)
        Me.txtgender.Text = dtgsi.Columns(5)
        Me.txtbday.Text = dtgsi.Columns(6)
        Me.txtaddress.Text = dtgsi.Columns(7)
        Me.txtcpno.Text = dtgsi.Columns(8)
        Me.txtgl.Text = dtgsi.Columns(9)
        Me.txtsection.Text = dtgsi.Columns(10)
        Me.txtsy.Text = dtgsi.Columns(11)
        Me.txtfname.Text = dtgsi.Columns(12)
        Me.txtfcpno.Text = dtgsi.Columns(13)
        Me.txtmname.Text = dtgsi.Columns(14)
        Me.txtmcpno.Text = dtgsi.Columns(15)
        Exit Sub
    Else
        clear
    End If
    .MoveNext
Wend
End With
End Sub

Public Sub clear()
Me.txtstudname.Text = ""
Me.txtstudno.Text = ""
Me.txtsy.Text = ""
Me.txtgl.Text = ""
Me.txtsection.Text = ""
Me.txtgender.Text = ""
Me.txtcpno.Text = ""
Me.txtage.Text = ""
Me.txtaddress.Text = ""
Me.txtbday.Text = ""
Me.txtfname.Text = ""
Me.txtfcpno.Text = ""
Me.txtmname.Text = ""
Me.txtmcpno.Text = ""
End Sub
Public Sub searchfn()
With rsREGISTRATION
.MoveFirst
    While .EOF = False
    If .Fields(2) = Me.txtsearch.Text Then
        Me.txtstudno.Text = dtgsi.Columns(0)
        Me.txtstudname.Text = dtgsi.Columns(1) & ", " & dtgsi.Columns(2) & " " & dtgsi.Columns(3)
        Me.txtage.Text = dtgsi.Columns(4)
        Me.txtgender.Text = dtgsi.Columns(5)
        Me.txtbday.Text = dtgsi.Columns(6)
        Me.txtaddress.Text = dtgsi.Columns(7)
        Me.txtcpno.Text = dtgsi.Columns(8)
        Me.txtgl.Text = dtgsi.Columns(9)
        Me.txtsection.Text = dtgsi.Columns(10)
        Me.txtsy.Text = dtgsi.Columns(11)
        Me.txtfname.Text = dtgsi.Columns(12)
        Me.txtfcpno.Text = dtgsi.Columns(13)
        Me.txtmname.Text = dtgsi.Columns(14)
        Me.txtmcpno.Text = dtgsi.Columns(15)
        Exit Sub
    Else
        clear
    End If
    .MoveNext
Wend
End With
End Sub

Public Sub searchln()
With rsREGISTRATION
.MoveFirst
    While .EOF = False
    If .Fields(1) = Me.txtsearch.Text Then
        Me.txtstudno.Text = dtgsi.Columns(0)
        Me.txtstudname.Text = dtgsi.Columns(1) & ", " & dtgsi.Columns(2) & " " & dtgsi.Columns(3)
        Me.txtage.Text = dtgsi.Columns(4)
        Me.txtgender.Text = dtgsi.Columns(5)
        Me.txtbday.Text = dtgsi.Columns(6)
        Me.txtaddress.Text = dtgsi.Columns(7)
        Me.txtcpno.Text = dtgsi.Columns(8)
        Me.txtgl.Text = dtgsi.Columns(9)
        Me.txtsection.Text = dtgsi.Columns(10)
        Me.txtsy.Text = dtgsi.Columns(11)
        Me.txtfname.Text = dtgsi.Columns(12)
        Me.txtfcpno.Text = dtgsi.Columns(13)
        Me.txtmname.Text = dtgsi.Columns(14)
        Me.txtmcpno.Text = dtgsi.Columns(15)
        Exit Sub
    Else
        clear
    End If
    .MoveNext
Wend
End With
End Sub

