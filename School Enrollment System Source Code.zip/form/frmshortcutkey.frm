VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Begin VB.Form frmshortcutkey 
   BackColor       =   &H00FFFF80&
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Shortcut Keys"
   ClientHeight    =   4500
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   4320
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   BeginProperty Font 
      Name            =   "Felix Titling"
      Size            =   9
      Charset         =   0
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4500
   ScaleWidth      =   4320
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin vkUserContolsXP.vkCommand cmdOk 
      Height          =   495
      Left            =   2760
      TabIndex        =   12
      Top             =   3840
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&OK"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.Timer Timer1 
      Left            =   240
      Top             =   4560
   End
   Begin VB.PictureBox Picture1 
      BackColor       =   &H00FFFFC0&
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3495
      Left            =   240
      ScaleHeight     =   3435
      ScaleWidth      =   3795
      TabIndex        =   0
      Top             =   240
      Width           =   3855
      Begin VB.Label Label24 
         BackStyle       =   0  'Transparent
         Caption         =   "ctrl + l"
         Height          =   255
         Left            =   2640
         TabIndex        =   25
         Top             =   2880
         Width           =   1095
      End
      Begin VB.Label Label23 
         BackStyle       =   0  'Transparent
         Caption         =   "Lock the system"
         Height          =   375
         Left            =   120
         TabIndex        =   24
         Top             =   2880
         Width           =   1935
      End
      Begin VB.Label Label22 
         BackStyle       =   0  'Transparent
         Caption         =   "F6"
         Height          =   255
         Left            =   3000
         TabIndex        =   23
         Top             =   2400
         Width           =   255
      End
      Begin VB.Label Label21 
         BackStyle       =   0  'Transparent
         Caption         =   "Particular"
         Height          =   255
         Left            =   120
         TabIndex        =   22
         Top             =   2400
         Width           =   1335
      End
      Begin VB.Label Label20 
         BackStyle       =   0  'Transparent
         Caption         =   "ctrl + O"
         Height          =   255
         Left            =   2640
         TabIndex        =   21
         Top             =   2640
         Width           =   975
      End
      Begin VB.Label Label19 
         BackStyle       =   0  'Transparent
         Caption         =   "Log Out"
         Height          =   375
         Left            =   120
         TabIndex        =   20
         Top             =   2640
         Width           =   1455
      End
      Begin VB.Label Label18 
         BackStyle       =   0  'Transparent
         Caption         =   "F5"
         Height          =   255
         Left            =   3000
         TabIndex        =   19
         Top             =   2160
         Width           =   375
      End
      Begin VB.Label Label16 
         BackStyle       =   0  'Transparent
         Caption         =   "F4"
         Height          =   255
         Left            =   3000
         TabIndex        =   18
         Top             =   1920
         Width           =   375
      End
      Begin VB.Label Label9 
         BackStyle       =   0  'Transparent
         Caption         =   "Billing"
         Height          =   255
         Left            =   120
         TabIndex        =   17
         Top             =   2160
         Width           =   1455
      End
      Begin VB.Label Label8 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "Assessment"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   120
         TabIndex        =   16
         Top             =   1920
         Width           =   1455
      End
      Begin VB.Label Label7 
         BackStyle       =   0  'Transparent
         Caption         =   "Ctrl + r"
         Height          =   255
         Left            =   2640
         TabIndex        =   15
         Top             =   960
         Width           =   1095
      End
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         Caption         =   "REgistration form"
         Height          =   255
         Left            =   120
         TabIndex        =   14
         Top             =   960
         Width           =   2295
      End
      Begin VB.Label Label17 
         BackStyle       =   0  'Transparent
         Caption         =   "Shortcut keys"
         BeginProperty Font 
            Name            =   "Felix Titling"
            Size            =   11.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   960
         TabIndex        =   13
         Top             =   240
         Width           =   2415
      End
      Begin VB.Label Label15 
         BackStyle       =   0  'Transparent
         Caption         =   "Shortcut Key"
         Height          =   255
         Left            =   120
         TabIndex        =   11
         Top             =   1680
         Width           =   1695
      End
      Begin VB.Label Label14 
         BackStyle       =   0  'Transparent
         Caption         =   "F1"
         Height          =   255
         Left            =   3000
         TabIndex        =   10
         Top             =   1200
         Width           =   615
      End
      Begin VB.Label Label13 
         BackStyle       =   0  'Transparent
         Caption         =   "Notepad"
         Height          =   255
         Left            =   120
         TabIndex        =   9
         Top             =   1200
         Width           =   1095
      End
      Begin VB.Label Label12 
         BackStyle       =   0  'Transparent
         Caption         =   "F3"
         Height          =   255
         Left            =   3000
         TabIndex        =   8
         Top             =   1680
         Width           =   855
      End
      Begin VB.Label Label11 
         BackStyle       =   0  'Transparent
         Caption         =   "Calculator"
         Height          =   255
         Left            =   120
         TabIndex        =   7
         Top             =   1440
         Width           =   1575
      End
      Begin VB.Label Label10 
         BackStyle       =   0  'Transparent
         Caption         =   "F2"
         Height          =   255
         Left            =   3000
         TabIndex        =   6
         Top             =   1440
         Width           =   735
      End
      Begin VB.Label Label6 
         BackStyle       =   0  'Transparent
         Caption         =   "Ctrl +  e"
         Height          =   255
         Left            =   2640
         TabIndex        =   5
         Top             =   3120
         Width           =   1455
      End
      Begin VB.Label Label5 
         BackStyle       =   0  'Transparent
         Caption         =   "EXIT"
         Height          =   255
         Left            =   120
         TabIndex        =   4
         Top             =   3120
         Width           =   1095
      End
      Begin VB.Label Label4 
         BackStyle       =   0  'Transparent
         Caption         =   "Ctrl +  A"
         Height          =   255
         Left            =   2640
         TabIndex        =   3
         Top             =   720
         Width           =   1815
      End
      Begin VB.Label Label3 
         BackStyle       =   0  'Transparent
         Caption         =   "Application form"
         Height          =   255
         Left            =   120
         TabIndex        =   2
         Top             =   720
         Width           =   2415
      End
      Begin VB.Image Image1 
         Height          =   480
         Left            =   120
         Picture         =   "frmshortcutkey.frx":0000
         Top             =   120
         Width           =   480
      End
   End
   Begin VB.Label Label1 
      Caption         =   "Label1"
      Height          =   495
      Left            =   1320
      TabIndex        =   1
      Top             =   2040
      Width           =   1215
   End
End
Attribute VB_Name = "frmshortcutkey"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*********************
' frmshortcutkey code*
'*********************
Dim bhide As Boolean

Private Sub cmdok_Click()
Timer1.Interval = 30
bhide = True
End Sub

Private Sub Form_Activate()
Me.cmdOk.SetFocus
Me.Height = 0
bhide = False
Timer1.Interval = 30
End Sub
Private Sub Timer1_Timer()
If bhide = False Then
    If Me.Height >= 4905 Then
        Me.Width = 4410
        Me.Height = 4905
        Timer1.Interval = 0
        Else
        Me.Height = Me.Height + 300
    End If
Else
 If Me.Height <= 600 Then
        Me.Width = 0
        Me.Height = 0
        Timer1.Interval = 0
        Unload Me
        Else
        Me.Height = Me.Height - 300
        DoEvents
    End If
End If
 Me.Top = (Screen.Height / 2) - (Me.Height / 2)
End Sub

