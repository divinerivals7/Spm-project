VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Begin VB.Form frmaddsection 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Add Section"
   ClientHeight    =   2775
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   5055
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2775
   ScaleWidth      =   5055
   StartUpPosition =   2  'CenterScreen
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   1695
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   4575
      _ExtentX        =   8070
      _ExtentY        =   2990
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkLabel vkLabel10 
         Height          =   375
         Left            =   240
         TabIndex        =   5
         Top             =   480
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Grade Level"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.ComboBox cbogl 
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         ItemData        =   "frmaddsection.frx":0000
         Left            =   1560
         List            =   "frmaddsection.frx":001F
         Style           =   2  'Dropdown List
         TabIndex        =   4
         Top             =   480
         Width           =   2775
      End
      Begin vkUserContolsXP.vkTextBox txtsection 
         Height          =   375
         Left            =   1560
         TabIndex        =   2
         Top             =   1080
         Width           =   735
         _ExtentX        =   1296
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel1 
         Height          =   375
         Left            =   240
         TabIndex        =   1
         Top             =   1080
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Enter Section"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   -360
      Top             =   2880
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   495
      Left            =   3720
      TabIndex        =   3
      Top             =   2040
      Width           =   1095
      _ExtentX        =   1931
      _ExtentY        =   873
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmaddsection"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*********************
' frmaddsection code *
'*********************

Private Sub cbogl_Click()
Me.txtsection.SetFocus
End Sub
Private Sub cmdsave_Click()
If Me.cbogl.Text = "" Then
    MsgBox "Please input student grade level", vbCritical, ""
    Me.cbogl.SetFocus
Exit Sub
End If
If Me.txtsection.Text = "" Then
    MsgBox "Please input student section", vbCritical, ""
    Me.txtsection.SetFocus
Exit Sub
End If
With rssec
.MoveFirst
    While .EOF = False
    If .Fields(1) = Me.cbogl.Text Then
        If .Fields(2) = Me.txtsection.Text Then
            MsgBox "Section already exist for the selected grade level", vbCritical, ""
            Exit Sub
        End If
    End If
    .MoveNext
Wend
End With
With rssec
    .AddNew
    .Fields(1) = Me.cbogl.Text
    .Fields(2) = UCase(Me.txtsection.Text)
    .Update
    MsgBox "information saved!!!", vbInformation, ""
End With
Me.txtsection.Text = ""
Me.cbogl.ListIndex = -1
Me.cbogl.SetFocus
End Sub

Private Sub Form_Activate()
Me.cbogl.SetFocus
End Sub

Private Sub Form_Load()
OpenConnection
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim a As Integer
If Me.cbogl.ListIndex <> -1 Then
    a = MsgBox("Are you sure you want to quit this form with out saving?", vbYesNo + vbQuestion, "")
        If a = vbYes Then
            Call CloseConnection
            Unload Me
        Else
            Cancel = 1
            End If
Else
    Call CloseConnection
    Unload Me
End If
End Sub

Public Sub sec()
With rssec
.MoveFirst
    While .EOF = False
    If .Fields(1) = Me.cbogl.Text Then
        If .Fields(2) = Me.txtsection.Text Then
            MsgBox "Section already exist for the selected grade level", vbCritical, ""
            Exit Sub
        End If
    End If
    .MoveNext
Wend
End With
End Sub

Private Sub txtsection_Change()
Me.txtsection.Text = UCase$(Me.txtsection.Text)
If Len(Me.txtsection.Text) > 1 Then
  Me.txtsection.Text = ""
End If
End Sub

Private Sub txtsection_KeyPress(KeyAscii As Integer)
If Chr(KeyAscii) Like "[0-9]" And KeyAscii <> 8 Then KeyAscii = 0
End Sub
