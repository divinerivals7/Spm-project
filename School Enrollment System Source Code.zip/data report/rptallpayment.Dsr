VERSION 5.00
Begin {78E93846-85FD-11D0-8487-00A0C90DC8A9} rptallpayment 
   Bindings        =   "rptallpayment.dsx":0000
   BorderStyle     =   1  'Fixed Single
   Caption         =   "All Payment Report"
   ClientHeight    =   7710
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   12540
   MaxButton       =   0   'False
   MinButton       =   0   'False
   StartUpPosition =   3  'Windows Default
   WindowState     =   2  'Maximized
   _ExtentX        =   22119
   _ExtentY        =   13600
   _Version        =   393216
   _DesignerVersion=   100684101
   ReportWidth     =   11145
   BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   GridX           =   10
   GridY           =   10
   LeftMargin      =   500
   RightMargin     =   500
   TopMargin       =   1440
   BottomMargin    =   1440
   DataMember      =   "Command3"
   NumSections     =   5
   SectionCode0    =   1
   BeginProperty Section0 {1C13A8E0-A0B6-11D0-848E-00A0C90DC8A9} 
      _Version        =   393216
      Name            =   "Section4"
      Object.Height          =   1965
      NumControls     =   4
      ItemType0       =   3
      BeginProperty Item0 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label3"
         Object.Left            =   4176
         Object.Top             =   288
         Object.Width           =   4608
         Object.Height          =   432
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   18
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Molina Montessori Center, Inc."
      EndProperty
      ItemType1       =   3
      BeginProperty Item1 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label1"
         Object.Left            =   5328
         Object.Top             =   1152
         Object.Width           =   2448
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "All Payment Report"
      EndProperty
      ItemType2       =   7
      BeginProperty Item2 {1C13A8E5-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Image1"
         Object.Left            =   2160
         Object.Width           =   1863
         Object.Height          =   1440
         Picture         =   "rptallpayment.dsx":001F
         SizeMode        =   1
      EndProperty
      ItemType3       =   3
      BeginProperty Item3 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label2"
         Object.Left            =   4608
         Object.Top             =   720
         Object.Width           =   3744
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "San Marcos Calumpit, Bulacan"
      EndProperty
   EndProperty
   SectionCode1    =   2
   BeginProperty Section1 {1C13A8E0-A0B6-11D0-848E-00A0C90DC8A9} 
      _Version        =   393216
      Name            =   "Section2"
      Object.Height          =   576
      NumControls     =   16
      ItemType0       =   6
      BeginProperty Item0 {1C13A8E4-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Shape1"
         Object.Left            =   432
         Object.Width           =   10512
         Object.Height          =   576
         BackColor       =   12648384
         BackStyle       =   1
      EndProperty
      ItemType1       =   3
      BeginProperty Item1 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label5"
         Object.Left            =   576
         Object.Top             =   144
         Object.Width           =   1584
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Student_Number"
      EndProperty
      ItemType2       =   3
      BeginProperty Item2 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label6"
         Object.Left            =   2592
         Object.Top             =   144
         Object.Width           =   1305
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Full_Name"
      EndProperty
      ItemType3       =   3
      BeginProperty Item3 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label10"
         Object.Left            =   4320
         Object.Top             =   144
         Object.Width           =   1305
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Charge"
      EndProperty
      ItemType4       =   3
      BeginProperty Item4 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label11"
         Object.Left            =   5328
         Object.Top             =   144
         Object.Width           =   864
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Payment"
      EndProperty
      ItemType5       =   3
      BeginProperty Item5 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label12"
         Object.Left            =   6336
         Object.Top             =   144
         Object.Width           =   720
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Balance"
      EndProperty
      ItemType6       =   3
      BeginProperty Item6 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label13"
         Object.Left            =   7488
         Object.Top             =   144
         Object.Width           =   1728
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Date of Payment"
      EndProperty
      ItemType7       =   3
      BeginProperty Item7 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label16"
         Object.Left            =   9360
         Object.Top             =   144
         Object.Width           =   1305
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Received By:"
      EndProperty
      ItemType8       =   5
      BeginProperty Item8 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line1"
         Object.Left            =   5184
         Object.Height          =   576
      EndProperty
      ItemType9       =   5
      BeginProperty Item9 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line2"
         Object.Left            =   2160
         Object.Height          =   576
      EndProperty
      ItemType10      =   5
      BeginProperty Item10 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line3"
         Object.Left            =   432
         Object.Height          =   432
      EndProperty
      ItemType11      =   5
      BeginProperty Item11 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line4"
         Object.Left            =   4176
         Object.Height          =   576
      EndProperty
      ItemType12      =   5
      BeginProperty Item12 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line5"
         Object.Left            =   6192
         Object.Height          =   576
      EndProperty
      ItemType13      =   5
      BeginProperty Item13 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line6"
         Object.Left            =   7200
         Object.Height          =   576
      EndProperty
      ItemType14      =   5
      BeginProperty Item14 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line7"
         Object.Left            =   9216
         Object.Height          =   576
      EndProperty
      ItemType15      =   5
      BeginProperty Item15 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line8"
         Object.Left            =   10944
         Object.Height          =   432
      EndProperty
   EndProperty
   SectionCode2    =   4
   BeginProperty Section2 {1C13A8E0-A0B6-11D0-848E-00A0C90DC8A9} 
      _Version        =   393216
      Name            =   "Section1"
      Object.Height          =   432
      NumControls     =   16
      ItemType0       =   4
      BeginProperty Item0 {1C13A8E2-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "txtStudent_Number"
         Object.Left            =   720
         Object.Top             =   144
         Object.Width           =   1440
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         DataField       =   "Student_Number"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
         DataMember      =   "Command3"
      EndProperty
      ItemType1       =   4
      BeginProperty Item1 {1C13A8E2-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "txtFull_Name"
         Object.Left            =   2304
         Object.Top             =   144
         Object.Width           =   1296
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         DataField       =   "Full_Name"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
         DataMember      =   "Command3"
      EndProperty
      ItemType2       =   4
      BeginProperty Item2 {1C13A8E2-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "txtStudent_Charge"
         Object.Left            =   3600
         Object.Top             =   144
         Object.Width           =   1440
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         DataField       =   "Student_Charge"
         Alignment       =   1
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
         DataMember      =   "Command3"
      EndProperty
      ItemType3       =   4
      BeginProperty Item3 {1C13A8E2-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "txtStudent_Current_Payment"
         Object.Left            =   4608
         Object.Top             =   144
         Object.Width           =   1440
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         DataField       =   "Student_Current_Payment"
         Alignment       =   1
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
         DataMember      =   "Command3"
      EndProperty
      ItemType4       =   4
      BeginProperty Item4 {1C13A8E2-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "txtStudent_Balance"
         Object.Left            =   5616
         Object.Top             =   144
         Object.Width           =   1440
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         DataField       =   "Student_Balance"
         Alignment       =   1
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
         DataMember      =   "Command3"
      EndProperty
      ItemType5       =   4
      BeginProperty Item5 {1C13A8E2-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "txtStudent_DateofPayment"
         Object.Left            =   7344
         Object.Top             =   144
         Object.Width           =   1875
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         DataField       =   "Student_DateofPayment"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
         DataMember      =   "Command3"
      EndProperty
      ItemType6       =   5
      BeginProperty Item6 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line17"
         Object.Left            =   432
         Object.Top             =   432
         Object.Width           =   10512
      EndProperty
      ItemType7       =   5
      BeginProperty Item7 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line9"
         Object.Left            =   2160
         Object.Height          =   432
      EndProperty
      ItemType8       =   5
      BeginProperty Item8 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line10"
         Object.Left            =   4176
         Object.Height          =   432
      EndProperty
      ItemType9       =   5
      BeginProperty Item9 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line11"
         Object.Left            =   5184
         Object.Height          =   432
      EndProperty
      ItemType10      =   5
      BeginProperty Item10 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line12"
         Object.Left            =   7200
         Object.Height          =   432
      EndProperty
      ItemType11      =   5
      BeginProperty Item11 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line13"
         Object.Left            =   6192
         Object.Height          =   432
      EndProperty
      ItemType12      =   5
      BeginProperty Item12 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line14"
         Object.Left            =   9216
         Object.Height          =   432
      EndProperty
      ItemType13      =   5
      BeginProperty Item13 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line15"
         Object.Left            =   10944
         Object.Height          =   432
      EndProperty
      ItemType14      =   5
      BeginProperty Item14 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line16"
         Object.Left            =   432
         Object.Height          =   432
      EndProperty
      ItemType15      =   4
      BeginProperty Item15 {1C13A8E2-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "txtReceivedBy"
         Object.Left            =   9360
         Object.Top             =   144
         Object.Width           =   1440
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         DataField       =   "Received_By"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
         DataMember      =   "Command3"
      EndProperty
   EndProperty
   SectionCode3    =   7
   BeginProperty Section3 {1C13A8E0-A0B6-11D0-848E-00A0C90DC8A9} 
      _Version        =   393216
      Name            =   "Section3"
      Object.Height          =   732
      NumControls     =   5
      ItemType0       =   3
      BeginProperty Item0 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label8"
         Object.Left            =   1152
         Object.Top             =   288
         Object.Width           =   420
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "%p"
      EndProperty
      ItemType1       =   3
      BeginProperty Item1 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label9"
         Object.Left            =   432
         Object.Top             =   288
         Object.Width           =   720
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Page"
      EndProperty
      ItemType2       =   3
      BeginProperty Item2 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label14"
         Object.Left            =   1584
         Object.Top             =   288
         Object.Width           =   585
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Of"
      EndProperty
      ItemType3       =   3
      BeginProperty Item3 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label15"
         Object.Left            =   2016
         Object.Top             =   288
         Object.Width           =   1440
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "%P"
      EndProperty
      ItemType4       =   3
      BeginProperty Item4 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label18"
         Object.Left            =   5904
         Object.Top             =   288
         Object.Width           =   5040
         Object.Height          =   240
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Monotype Corsiva"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   -1  'True
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Dedicated to the Total Formation of Your Children's Future"
         Alignment       =   1
      EndProperty
   EndProperty
   SectionCode4    =   8
   BeginProperty Section4 {1C13A8E0-A0B6-11D0-848E-00A0C90DC8A9} 
      _Version        =   393216
      Name            =   "Section5"
      Object.Height          =   2172
      NumControls     =   7
      ItemType0       =   13
      BeginProperty Item0 {49FF6930-2B8C-11D1-8DA9-00A0C90FFFC2} 
         _Version        =   393216
         Name            =   "Function1"
         Object.Left            =   2448
         Object.Top             =   432
         Object.Width           =   1002
         Object.Height          =   288
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         DataField       =   "Student_Current_Payment"
         Alignment       =   1
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
         DataMember      =   "Command3"
      EndProperty
      ItemType1       =   3
      BeginProperty Item1 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label4"
         Object.Left            =   432
         Object.Top             =   432
         Object.Width           =   1296
         Object.Height          =   300
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Total Income:"
      EndProperty
      ItemType2       =   3
      BeginProperty Item2 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label7"
         Object.Left            =   7488
         Object.Top             =   432
         Object.Width           =   1440
         Object.Height          =   300
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Date Prepared:"
      EndProperty
      ItemType3       =   3
      BeginProperty Item3 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "l1"
         Object.Left            =   9072
         Object.Top             =   432
         Object.Width           =   1875
         Object.Height          =   300
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "l1"
         Alignment       =   1
      EndProperty
      ItemType4       =   3
      BeginProperty Item4 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Label17"
         Object.Left            =   432
         Object.Top             =   1152
         Object.Width           =   1440
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Object.Caption         =   "Printed By:"
      EndProperty
      ItemType5       =   3
      BeginProperty Item5 {1C13A8E1-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Labelu"
         Object.Left            =   1440
         Object.Top             =   1152
         Object.Width           =   2016
         Object.Height          =   285
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Alignment       =   1
      EndProperty
      ItemType6       =   5
      BeginProperty Item6 {1C13A8E3-A0B6-11D0-848E-00A0C90DC8A9} 
         _Version        =   393216
         Name            =   "Line18"
         Object.Left            =   1872
         Object.Top             =   1440
         Object.Width           =   2448
      EndProperty
   EndProperty
End
Attribute VB_Name = "rptallpayment"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub DataReport_Terminate()
DataEnvironment1.rsCommand3.Close
End Sub
