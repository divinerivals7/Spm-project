Attribute VB_Name = "Module1"
'****************
' Module 1 Code *
'****************
Option Explicit
Public con As New ADODB.Connection
Public rsREGISTRATION As New ADODB.Recordset
Public rsAPPLICATION As New ADODB.Recordset
Public rsSCHOOLYEAR As New ADODB.Recordset
Public rsPARTICULAR As New ADODB.Recordset
Public rsASSESSMENT As New ADODB.Recordset
Public rsBILLING As New ADODB.Recordset
Public rsUSERLEVEL As New ADODB.Recordset
Public rsDP As New ADODB.Recordset
Public rsLOGS As New ADODB.Recordset
Public rsID As New ADODB.Recordset
Public rssec As New ADODB.Recordset

Public Sub OpenConnection()
con.Open "Provider=MSDASQL.1;Persist Security Info=False;Data Source=MMIC"
con.CursorLocation = adUseClient
rsREGISTRATION.Open "select * from REGISTRATION", con, adOpenKeyset, adLockOptimistic
rsAPPLICATION.Open "select * from APPLICATION", con, adOpenKeyset, adLockOptimistic
rsSCHOOLYEAR.Open "select * from SCHOOLYEAR", con, adOpenKeyset, adLockOptimistic
rsPARTICULAR.Open "select * from PARTICULAR", con, adOpenKeyset, adLockOptimistic
rsASSESSMENT.Open "select * from ASSESSMENT", con, adOpenKeyset, adLockOptimistic
rsBILLING.Open "select * from BILLING", con, adOpenKeyset, adLockOptimistic
rsUSERLEVEL.Open "select * from USERLEVEL", con, adOpenKeyset, adLockOptimistic
rsLOGS.Open "select * from LOGS", con, adOpenKeyset, adLockOptimistic
rsDP.Open "select * from DP", con, adOpenKeyset, adLockOptimistic
rsID.Open "select * from ID", con, adOpenKeyset, adLockOptimistic
rssec.Open "select * from sec", con, adOpenKeyset, adLockOptimistic
End Sub

Public Sub CloseConnection()
con.Close
Set con = Nothing
End Sub



