VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Begin VB.Form frmai 
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   9645
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   13950
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   9645
   ScaleWidth      =   13950
   StartUpPosition =   2  'CenterScreen
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   6735
      Left            =   6960
      TabIndex        =   9
      Top             =   2160
      Width           =   6855
      _ExtentX        =   12091
      _ExtentY        =   11880
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkTextBox txtmname 
         Height          =   375
         Left            =   2160
         TabIndex        =   35
         Top             =   6120
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel15 
         Height          =   375
         Left            =   240
         TabIndex        =   34
         Top             =   6120
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Mother's Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtfname 
         Height          =   375
         Left            =   2160
         TabIndex        =   33
         Top             =   5640
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel14 
         Height          =   375
         Left            =   240
         TabIndex        =   32
         Top             =   5640
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Father's Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel13 
         Height          =   375
         Left            =   240
         TabIndex        =   31
         Top             =   5160
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Previous Schooling"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtpv 
         Height          =   375
         Left            =   2160
         TabIndex        =   30
         Top             =   5160
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel12 
         Height          =   375
         Left            =   240
         TabIndex        =   29
         Top             =   3720
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Contact Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtcpno 
         Height          =   375
         Left            =   2160
         TabIndex        =   28
         Top             =   3720
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel11 
         Height          =   375
         Left            =   240
         TabIndex        =   27
         Top             =   4680
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Place of Birth"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtpb 
         Height          =   375
         Left            =   2160
         TabIndex        =   26
         Top             =   4680
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel10 
         Height          =   375
         Left            =   240
         TabIndex        =   25
         Top             =   4200
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Date of Birth"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtdateofbirth 
         Height          =   375
         Left            =   2160
         TabIndex        =   24
         Top             =   4200
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel9 
         Height          =   375
         Left            =   240
         TabIndex        =   23
         Top             =   3240
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Religion"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtreligion 
         Height          =   375
         Left            =   2160
         TabIndex        =   22
         Top             =   3240
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel8 
         Height          =   375
         Left            =   240
         TabIndex        =   21
         Top             =   2760
         Width           =   975
         _ExtentX        =   1720
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Address"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtadd 
         Height          =   375
         Left            =   2160
         TabIndex        =   20
         Top             =   2760
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkTextBox txtgender 
         Height          =   375
         Left            =   2160
         TabIndex        =   19
         Top             =   2280
         Width           =   735
         _ExtentX        =   1296
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel7 
         Height          =   375
         Left            =   240
         TabIndex        =   18
         Top             =   2280
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Gender"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtage 
         Height          =   375
         Left            =   2160
         TabIndex        =   17
         Top             =   1800
         Width           =   735
         _ExtentX        =   1296
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel6 
         Height          =   375
         Left            =   240
         TabIndex        =   16
         Top             =   1800
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Age"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtsy 
         Height          =   375
         Left            =   2160
         TabIndex        =   15
         Top             =   840
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel5 
         Height          =   375
         Left            =   240
         TabIndex        =   14
         Top             =   840
         Width           =   1335
         _ExtentX        =   2355
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "School Year"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtfullname 
         Height          =   375
         Left            =   2160
         TabIndex        =   13
         Top             =   1320
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel4 
         Height          =   375
         Left            =   240
         TabIndex        =   12
         Top             =   1320
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Full Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtappno 
         Height          =   375
         Left            =   2160
         TabIndex        =   11
         Top             =   360
         Width           =   735
         _ExtentX        =   1296
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         Locked          =   -1  'True
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel3 
         Height          =   375
         Left            =   240
         TabIndex        =   10
         Top             =   360
         Width           =   1935
         _ExtentX        =   3413
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Application Number"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin vkUserContolsXP.vkCommand cmddelete 
      Height          =   495
      Left            =   5280
      TabIndex        =   8
      Top             =   9000
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   873
      Caption         =   "&Delete"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.ComboBox cbosearch 
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      ItemData        =   "frmai.frx":0000
      Left            =   1320
      List            =   "frmai.frx":000D
      Style           =   2  'Dropdown List
      TabIndex        =   7
      Top             =   1560
      Width           =   2175
   End
   Begin vkUserContolsXP.vkLabel lblrecords 
      Height          =   375
      Left            =   2160
      TabIndex        =   0
      Top             =   9000
      Width           =   495
      _ExtentX        =   873
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Alignment       =   2
   End
   Begin vkUserContolsXP.vkLabel vkLabel2 
      Height          =   375
      Left            =   240
      TabIndex        =   1
      Top             =   9000
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Number of Records"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel1 
      Height          =   375
      Left            =   240
      TabIndex        =   2
      Top             =   1560
      Width           =   2415
      _ExtentX        =   4260
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Search by"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkTextBox txtsearch 
      Height          =   375
      Left            =   4200
      TabIndex        =   3
      Top             =   1560
      Width           =   2535
      _ExtentX        =   4471
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Alignment       =   2
      BorderColor     =   4210816
      LegendForeColor =   14117668
   End
   Begin MSAdodcLib.Adodc Adodc1 
      Height          =   375
      Left            =   6720
      Top             =   360
      Visible         =   0   'False
      Width           =   1815
      _ExtentX        =   3201
      _ExtentY        =   661
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   2
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   3
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   "DSN=MMIC"
      OLEDBString     =   ""
      OLEDBFile       =   ""
      DataSourceName  =   "MMIC"
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   "APPLICATION"
      Caption         =   "Adodc1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   9120
      Top             =   0
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   6735
      Left            =   240
      TabIndex        =   5
      Top             =   2160
      Width           =   6615
      _ExtentX        =   11668
      _ExtentY        =   11880
      Caption         =   "Applicant Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin MSDataGridLib.DataGrid dtgai 
         Bindings        =   "frmai.frx":003C
         Height          =   6255
         Left            =   120
         TabIndex        =   6
         Top             =   360
         Width           =   6375
         _ExtentX        =   11245
         _ExtentY        =   11033
         _Version        =   393216
         BackColor       =   12640511
         HeadLines       =   1
         RowHeight       =   19
         BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ColumnCount     =   2
         BeginProperty Column00 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         BeginProperty Column01 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         SplitCount      =   1
         BeginProperty Split0 
            BeginProperty Column00 
            EndProperty
            BeginProperty Column01 
            EndProperty
         EndProperty
      End
   End
   Begin VB.Label LblTitle 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Applicant Information "
      BeginProperty Font 
         Name            =   "Monotype Corsiva"
         Size            =   24
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   585
      Left            =   2040
      TabIndex        =   4
      Top             =   360
      Width           =   4335
   End
   Begin VB.Line Line1 
      X1              =   0
      X2              =   13920
      Y1              =   1200
      Y2              =   1200
   End
   Begin VB.Line Line2 
      X1              =   0
      X2              =   13920
      Y1              =   1320
      Y2              =   1320
   End
   Begin VB.Image Image1 
      Height          =   1095
      Left            =   240
      Picture         =   "frmai.frx":0051
      Stretch         =   -1  'True
      Top             =   120
      Width           =   1695
   End
End
Attribute VB_Name = "frmai"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*************
' frmai code *
'*************

Private Sub Command1_Click()
CloseConnection
frmreg.Show vbModal
End Sub

Private Sub cbosearch_Click()
Me.txtsearch.Text = ""
Me.txtsearch.Enabled = True
Me.txtsearch.SetFocus
End Sub

Private Sub cmddelete_Click()
Dim rec As New ADODB.Recordset
   Dim rResult
   rResult = MsgBox("Do you want to delete the record?", vbQuestion + vbYesNo, "")
   If rResult = vbYes Then
       con.Execute "Delete from APPLICATION where App_No =" & dtgai.Columns(0).Value
       MsgBox "Successfully Deleted!!!", vbInformation + vbOKOnly, ""
       Me.txtsy.Text = ""
       Me.txtreligion.Text = ""
       Me.txtpv.Text = ""
       Me.txtpb.Text = ""
       Me.txtmname.Text = ""
       Me.txtgender.Text = ""
       Me.txtfname.Text = ""
       Me.txtfullname.Text = ""
       Me.txtdateofbirth.Text = ""
       Me.txtcpno.Text = ""
       Me.txtappno.Text = ""
       Me.txtage.Text = ""
       Me.txtadd.Text = ""

       Set dtgai.DataSource = Nothing
       Set rec = Nothing
       
       Set rec = New ADODB.Recordset
       rec.Open "Select * from APPLICATION", con, adUseClient, adLockOptimistic
       Set dtgai.DataSource = rec
       dbgrid
   End If
   dbgrid
End Sub

Private Sub dtgai_Click()
With Me.Adodc1.Recordset
    If .RecordCount < 1 Then MsgBox "No Data Selected", vbExclamation, "": Exit Sub
End With
    dtgai.MarqueeStyle = dbgHighlightRow
    Me.txtappno.Text = dtgai.Columns(0)
    Me.txtsy.Text = dtgai.Columns(1)
    Me.txtfullname.Text = dtgai.Columns(2) & ", " & dtgai.Columns(3) & " " & dtgai.Columns(4)
    Me.txtage.Text = dtgai.Columns(5)
    Me.txtgender.Text = dtgai.Columns(6)
    Me.txtreligion.Text = dtgai.Columns(7)
    Me.txtdateofbirth.Text = dtgai.Columns(8)
    Me.txtpb.Text = dtgai.Columns(9)
    Me.txtadd.Text = dtgai.Columns(10)
    Me.txtcpno.Text = dtgai.Columns(11)
    Me.txtpv.Text = dtgai.Columns(12)
    Me.txtfname.Text = dtgai.Columns(13)
    Me.txtmname.Text = dtgai.Columns(18)
End Sub

Private Sub dtgai_HeadClick(ByVal ColIndex As Integer)
With Adodc1.Recordset
    If (.Sort = .Fields(ColIndex).[Name] & " Asc") Then
        .Sort = .Fields(ColIndex).[Name] & " Desc"
    Else
        .Sort = .Fields(ColIndex).[Name] & " Asc"
    End If
End With
End Sub

Private Sub Form_Load()
OpenConnection
Me.txtsearch.Enabled = False
dbgrid
If MDIForm1.StatusBar2.Panels(5) = "A" Then
    Me.cmddelete.Enabled = True
Else
    Me.cmddelete.Enabled = False
End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
CloseConnection
Unload Me
End Sub

Private Sub Form_Activate()
Me.lblrecords.Caption = rsAPPLICATION.RecordCount
End Sub

Private Sub txtsearch_Change()
If txtsearch.Text = "" Then
clear
Set dtgai.DataSource = rsAPPLICATION
dbgrid
Exit Sub
End If

Dim rssearch As New ADODB.Recordset

If cbosearch.Text = "Application_Number" Then
rssearch.Open " select * from APPLICATION where App_No like '" & txtsearch.Text & "%'", con, adOpenKeyset, adLockOptimistic
Set dtgai.DataSource = rssearch
searchid
dbgrid

ElseIf cbosearch.Text = "First Name" Then
rssearch.Open " select * from APPLICATION where Firstname like '" & txtsearch.Text & "%'", con, adOpenKeyset, adLockOptimistic
Set dtgai.DataSource = rssearch
searchfn
dbgrid

ElseIf cbosearch.Text = "Last Name" Then
rssearch.Open " select * from APPLICATION where Lastname like '" & txtsearch.Text & "%'", con, adOpenKeyset, adLockOptimistic
Set dtgai.DataSource = rssearch
searchln
dbgrid

End If
End Sub
Public Sub dbgrid()
dtgai.Columns(0).Width = 800
dtgai.Columns(1).Width = 1400
dtgai.Columns(2).Width = 1600
dtgai.Columns(3).Width = 1600
dtgai.Columns(4).Width = 600
dtgai.Columns(5).Width = 600
dtgai.Columns(6).Width = 600
End Sub

Public Sub searchid()
With rsAPPLICATION
.MoveFirst
    While .EOF = False
    If .Fields(0) = Me.txtsearch.Text Then
        Me.txtsy.Text = dtgai.Columns(1)
        Me.txtreligion.Text = dtgai.Columns(7)
        Me.txtpv.Text = dtgai.Columns(12)
        Me.txtpb.Text = dtgai.Columns(9)
        Me.txtmname.Text = dtgai.Columns(18)
        Me.txtgender.Text = dtgai.Columns(6)
        Me.txtfname.Text = dtgai.Columns(13)
        Me.txtfullname.Text = dtgai.Columns(2) & ", " & dtgai.Columns(3) & " " & dtgai.Columns(4)
        Me.txtdateofbirth.Text = dtgai.Columns(8)
        Me.txtcpno.Text = dtgai.Columns(11)
        Me.txtappno.Text = dtgai.Columns(0)
        Me.txtage.Text = dtgai.Columns(5)
        Me.txtadd.Text = dtgai.Columns(10)
        Exit Sub
    Else
        clear
    End If
    .MoveNext
Wend
End With
End Sub

Public Sub clear()
Me.txtsy.Text = ""
Me.txtreligion.Text = ""
Me.txtpv.Text = ""
Me.txtpb.Text = ""
Me.txtmname.Text = ""
Me.txtgender.Text = ""
Me.txtfname.Text = ""
Me.txtfullname.Text = ""
Me.txtdateofbirth.Text = ""
Me.txtcpno.Text = ""
Me.txtappno.Text = ""
Me.txtage.Text = ""
Me.txtadd.Text = ""
End Sub
Public Sub searchfn()
With rsAPPLICATION
.MoveFirst
    While .EOF = False
    If .Fields(3) = Me.txtsearch.Text Then
        Me.txtsy.Text = dtgai.Columns(1)
        Me.txtreligion.Text = dtgai.Columns(7)
        Me.txtpv.Text = dtgai.Columns(12)
        Me.txtpb.Text = dtgai.Columns(9)
        Me.txtmname.Text = dtgai.Columns(18)
        Me.txtgender.Text = dtgai.Columns(6)
        Me.txtfname.Text = dtgai.Columns(13)
        Me.txtfullname.Text = dtgai.Columns(2) & ", " & dtgai.Columns(3) & " " & dtgai.Columns(4)
        Me.txtdateofbirth.Text = dtgai.Columns(8)
        Me.txtcpno.Text = dtgai.Columns(11)
        Me.txtappno.Text = dtgai.Columns(0)
        Me.txtage.Text = dtgai.Columns(5)
        Me.txtadd.Text = dtgai.Columns(10)
        Exit Sub
    Else
        clear
    End If
    .MoveNext
Wend
End With
End Sub

Public Sub searchln()
With rsAPPLICATION
.MoveFirst
    While .EOF = False
    If .Fields(2) = Me.txtsearch.Text Then
        Me.txtsy.Text = dtgai.Columns(1)
        Me.txtreligion.Text = dtgai.Columns(7)
        Me.txtpv.Text = dtgai.Columns(12)
        Me.txtpb.Text = dtgai.Columns(9)
        Me.txtmname.Text = dtgai.Columns(18)
        Me.txtgender.Text = dtgai.Columns(6)
        Me.txtfname.Text = dtgai.Columns(13)
        Me.txtfullname.Text = dtgai.Columns(2) & ", " & dtgai.Columns(3) & " " & dtgai.Columns(4)
        Me.txtdateofbirth.Text = dtgai.Columns(8)
        Me.txtcpno.Text = dtgai.Columns(11)
        Me.txtappno.Text = dtgai.Columns(0)
        Me.txtage.Text = dtgai.Columns(5)
        Me.txtadd.Text = dtgai.Columns(10)
        Exit Sub
    Else
        clear
    End If
    .MoveNext
Wend
End With
End Sub
