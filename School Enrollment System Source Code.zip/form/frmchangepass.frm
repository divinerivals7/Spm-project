VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Begin VB.Form frmchangepass 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Change Password"
   ClientHeight    =   4095
   ClientLeft      =   45
   ClientTop       =   375
   ClientWidth     =   5955
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4095
   ScaleWidth      =   5955
   StartUpPosition =   2  'CenterScreen
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   495
      Left            =   2880
      TabIndex        =   3
      Top             =   3360
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel3 
      Height          =   375
      Left            =   480
      TabIndex        =   0
      Top             =   720
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Username"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel4 
      Height          =   375
      Left            =   480
      TabIndex        =   1
      Top             =   1920
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "New Password"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel5 
      Height          =   375
      Left            =   480
      TabIndex        =   2
      Top             =   2520
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Confirm Password"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkCommand cmdcancel 
      Cancel          =   -1  'True
      Height          =   495
      Left            =   4320
      TabIndex        =   4
      Top             =   3360
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   873
      Caption         =   "&Clear"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   360
      Top             =   4440
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkLabel vkLabel6 
      Height          =   375
      Left            =   480
      TabIndex        =   5
      Top             =   1320
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Old Password"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   2895
      Left            =   240
      TabIndex        =   6
      Top             =   240
      Width           =   5415
      _ExtentX        =   9551
      _ExtentY        =   5106
      Caption         =   "Change Password"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkTextBox txtpass2 
         Height          =   375
         Left            =   2280
         TabIndex        =   10
         Top             =   2280
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         PassWordChar    =   "*"
         LegendForeColor =   5328457
      End
      Begin vkUserContolsXP.vkTextBox txtpass1 
         Height          =   375
         Left            =   2280
         TabIndex        =   9
         Top             =   1680
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         PassWordChar    =   "*"
         LegendForeColor =   5328457
      End
      Begin vkUserContolsXP.vkTextBox txtoldpass 
         Height          =   375
         Left            =   2280
         TabIndex        =   8
         Top             =   1080
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         PassWordChar    =   "*"
         LegendForeColor =   5328457
      End
      Begin vkUserContolsXP.vkTextBox txtuser 
         Height          =   375
         Left            =   2280
         TabIndex        =   7
         Top             =   480
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   5328457
      End
   End
End
Attribute VB_Name = "frmchangepass"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*******************
'frmchangepass code*
'*******************
Private Sub cmdcancel_Click()
clear
Me.txtuser.SetFocus
End Sub

Private Sub cmdsave_Click()
If Len(Me.txtpass1.Text) < 5 Then
    MsgBox "Minimum of 5 characters for password", vbCritical, ""
    Me.txtpass1.SetFocus
    Exit Sub
End If
With rsUSERLEVEL
    .MoveFirst  'Moving to the first record
        While .EOF = False    'Running through all the records in the database
            
            If .Fields(3).Value = txtuser.Text Then 'Checking for the right Employee ID
                
                If .Fields(4).Value <> txtoldpass.Text Then   'Checking if the Old Password typed by the user is correct
                    MsgBox "Error! The Old Password You Provided Was Incorrect! Please Check Your Password!", vbCritical, ""
                    txtoldpass.Text = ""    'Clearing the Old Password textfield
                    Me.txtoldpass.SetFocus
                    Exit Sub
                End If
                    
                If txtpass1.Text <> txtpass2.Text Then  'Checking if the new passwords match
                    MsgBox "Error! The New Passwords You Provided Do Not Match! Please Check Your Passwords!", vbCritical, ""
                    txtpass1.Text = ""    'Clearing the New Password textfield
                    txtpass2.Text = ""    'Clearing the Confirm Password textfield
                    Me.txtpass1.SetFocus
                    Exit Sub
                End If
                                               
                If txtpass1.Text = txtpass2.Text Then   'Checking if the passwords match
                    'Making sure that the user wants to save the record
                    If MsgBox("Are You Sure You Wish To Change Your Password?", vbYesNo + vbQuestion, "") = vbYes Then
                        .Fields(4).Value = txtpass1.Text
                        .Update 'Updating the recordset
                        'Display Success Message
                        MsgBox "Your Password Has Been Changed Successfully!", vbInformation, ""
                        clear
                        Me.txtuser.SetFocus
                        Exit Sub
                    Else
                        'Display 'No Modifications' Message
                        MsgBox "No Modifications Have Taken Place!", vbInformation, ""
                        clear
                        Me.txtuser.SetFocus
                        Exit Sub
                    End If
                End If
            
            Else
                
                .MoveNext   'Moving to the next record
            End If
        Wend
        Unload Me
    End With
End Sub

Private Sub Form_Activate()
Me.txtoldpass.SetFocus
End Sub

Private Sub Form_Load()
OpenConnection
Me.txtuser.Text = MDIForm1.StatusBar2.Panels(2)
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim a As Integer
If cmdsave.Enabled = True Then
    a = MsgBox("Are you sure you want to quit this form with out saving?", vbYesNo + vbQuestion, "")
        If a = vbYes Then
            Call CloseConnection
            Unload Me
        Else
            Cancel = 1
            End If
Else
    Call CloseConnection
    Unload Me
End If
End Sub
Public Sub clear()
Me.txtpass1.Text = ""
Me.txtpass2.Text = ""
Me.txtuser.Text = ""
Me.txtoldpass.Text = ""
End Sub

Public Sub enable()
Me.txtpass1.Enabled = True
Me.txtpass2.Enabled = True
End Sub
Public Sub disable()
Me.txtpass1.Enabled = False
Me.txtpass2.Enabled = False
End Sub

Private Sub txtpass2_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
cmdsave_Click
End If
End Sub
