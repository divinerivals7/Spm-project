VERSION 5.00
Object = "{CB9331C5-4A52-45B1-B34A-36C0DE0F96A5}#1.0#0"; "WelchUserControl.ocx"
Object = "{5734474E-78D3-4254-99B9-C35F31BDF509}#63.1#0"; "vbskpro2.ocx"
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Begin VB.Form frmparticular 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Particular"
   ClientHeight    =   8280
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   9510
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   8280
   ScaleWidth      =   9510
   StartUpPosition =   2  'CenterScreen
   Begin MSDataGridLib.DataGrid dtgpart 
      Bindings        =   "frmparticular.frx":0000
      Height          =   2655
      Left            =   360
      TabIndex        =   17
      Top             =   1320
      Width           =   8775
      _ExtentX        =   15478
      _ExtentY        =   4683
      _Version        =   393216
      BackColor       =   12640511
      HeadLines       =   1
      RowHeight       =   24
      BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ColumnCount     =   2
      BeginProperty Column00 
         DataField       =   ""
         Caption         =   ""
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
      EndProperty
      BeginProperty Column01 
         DataField       =   ""
         Caption         =   ""
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
      EndProperty
      SplitCount      =   1
      BeginProperty Split0 
         BeginProperty Column00 
         EndProperty
         BeginProperty Column01 
         EndProperty
      EndProperty
   End
   Begin MSAdodcLib.Adodc adopart 
      Height          =   375
      Left            =   5040
      Top             =   240
      Visible         =   0   'False
      Width           =   2295
      _ExtentX        =   4048
      _ExtentY        =   661
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   2
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   3
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   "DSN=MMIC"
      OLEDBString     =   ""
      OLEDBFile       =   ""
      DataSourceName  =   "MMIC"
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   "PARTICULAR"
      Caption         =   "Adodc1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin VB.ComboBox cbogl 
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      ItemData        =   "frmparticular.frx":0016
      Left            =   2040
      List            =   "frmparticular.frx":0035
      Style           =   2  'Dropdown List
      TabIndex        =   9
      Top             =   5400
      Width           =   2055
   End
   Begin vkUserContolsXP.vkCommand cmdadd 
      Height          =   495
      Left            =   4080
      TabIndex        =   4
      Top             =   7560
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   873
      Caption         =   "&Add"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkTextBox txttp 
      Height          =   375
      Left            =   6960
      TabIndex        =   3
      Top             =   4200
      Width           =   2295
      _ExtentX        =   4048
      _ExtentY        =   661
      BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Alignment       =   2
      BorderColor     =   4210816
      Locked          =   -1  'True
      LegendForeColor =   14117668
   End
   Begin vkUserContolsXP.vkLabel vkLabel3 
      Height          =   375
      Left            =   5280
      TabIndex        =   2
      Top             =   4200
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Total Payment"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkLabel vkLabel2 
      Height          =   375
      Left            =   240
      TabIndex        =   1
      Top             =   360
      Width           =   2295
      _ExtentX        =   4048
      _ExtentY        =   661
      BackColor       =   16777215
      BackStyle       =   0
      Caption         =   "Select Grade Level"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   12.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.ComboBox cbogl2 
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      ItemData        =   "frmparticular.frx":00B0
      Left            =   2280
      List            =   "frmparticular.frx":00CF
      Style           =   2  'Dropdown List
      TabIndex        =   0
      Top             =   360
      Width           =   2055
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   -600
      Top             =   0
      _ExtentX        =   1270
      _ExtentY        =   1270
      SysDisableSkinCaption=   "&Disable Skin"
   End
   Begin vkUserContolsXP.vkCommand cmddelete 
      Height          =   495
      Left            =   6720
      TabIndex        =   5
      Top             =   7560
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   873
      Caption         =   "&Delete"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame1 
      Height          =   3135
      Left            =   240
      TabIndex        =   6
      Top             =   960
      Width           =   9015
      _ExtentX        =   15901
      _ExtentY        =   5530
      Caption         =   "Particular Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkLabel vkLabel1 
         Height          =   375
         Left            =   120
         TabIndex        =   7
         Top             =   -600
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Select Year Level"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin vkUserContolsXP.vkCommand cmdcancel 
      Height          =   495
      Left            =   8040
      TabIndex        =   8
      Top             =   7560
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   873
      Caption         =   "&Clear"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin vkUserContolsXP.vkFrame vkFrame2 
      Height          =   2415
      Left            =   240
      TabIndex        =   10
      Top             =   4920
      Width           =   9015
      _ExtentX        =   15901
      _ExtentY        =   4260
      Caption         =   "Add Information"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TitleColor1     =   4210816
      TitleColor2     =   4210816
      BorderColor     =   4210816
      Begin vkUserContolsXP.vkTextBox txtamount 
         Height          =   375
         Left            =   1800
         TabIndex        =   15
         Top             =   1680
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel4 
         Height          =   375
         Left            =   240
         TabIndex        =   14
         Top             =   1680
         Width           =   855
         _ExtentX        =   1508
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Amount"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkTextBox txtpn 
         Height          =   375
         Left            =   1800
         TabIndex        =   13
         Top             =   1080
         Width           =   2775
         _ExtentX        =   4895
         _ExtentY        =   661
         BeginProperty LegendFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BorderColor     =   4210816
         LegendForeColor =   14117668
      End
      Begin vkUserContolsXP.vkLabel vkLabel5 
         Height          =   375
         Left            =   240
         TabIndex        =   12
         Top             =   1080
         Width           =   1575
         _ExtentX        =   2778
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Particular Name"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin vkUserContolsXP.vkLabel vkLabel6 
         Height          =   375
         Left            =   240
         TabIndex        =   11
         Top             =   480
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   661
         BackColor       =   16777215
         BackStyle       =   0
         Caption         =   "Grade Level"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Arial Narrow"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin vkUserContolsXP.vkCommand cmdsave 
      Height          =   495
      Left            =   5400
      TabIndex        =   16
      Top             =   7560
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   873
      Caption         =   "&Save"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmparticular"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'********************
' frmparticular code*
'********************

Private Sub cbogl_Click()
Me.txtpn.SetFocus
End Sub

Private Sub cbogl2_Click()
On Error GoTo errorhandler
Dim rssearch As New ADODB.Recordset
rssearch.Open "Select * from PARTICULAR where Grade_Level like '" & Trim(Me.cbogl2.Text) & "%'", con, adOpenKeyset, adLockOptimistic
Set dtgpart.DataSource = rssearch
dbgrid

On Error GoTo errorhandler
Dim rs As New ADODB.Recordset
rs.Open "Select sum(Amount) as sumpay from PARTICULAR where Grade_Level like '" & Trim(Me.cbogl2.Text) & "%'", con, adOpenKeyset, adLockOptimistic
Me.txttp.Text = rs!sumpay

Set rs = Nothing
Exit Sub
errorhandler:
Me.txttp.Text = 0
End Sub

Private Sub cmdadd_Click()
    Set rec = New ADODB.Recordset
    rec.Open "Select * from PARTICULAR", con, adUseClient, adLockOptimistic
    Set dtgpart.DataSource = rec
    dbgrid
cbogl.locked = False
Me.txtamount.locked = False
Me.txtpn.locked = False
enable
End Sub

Private Sub cmdexit_Click()
Unload Me
End Sub

Private Sub cmdcancel_Click()
clear
cmdadd.Enabled = True
disable
End Sub

Private Sub cmddelete_Click()
Dim rec As New ADODB.Recordset

   Dim rResult
   
   rResult = MsgBox("Do you want to delete the record?", vbQuestion + vbYesNo, "")
   
   If rResult = vbYes Then
       con.Execute "Delete from Particular where Particular_ID =" & dtgpart.Columns(0).Value
       MsgBox "Successfully Deleted!!!", vbInformation + vbOKOnly, ""
        Me.cbogl.ListIndex = -1
        Me.txtamount.Text = ""
        Me.txtpn.Text = ""
        cmdadd.Enabled = True
        cmddelete.Enabled = False
        cmdcancel.Enabled = False
       Set dtgpart.DataSource = Nothing
       Set rec = Nothing
       
       Set rec = New ADODB.Recordset
       rec.Open "Select * from PARTICULAR", con, adUseClient, adLockOptimistic
       Set dtgpart.DataSource = rec
       
   End If
   adopart.Refresh
   dbgrid
End Sub

Private Sub cmdsave_Click()
If Me.txtpn.Text = "" Then
    MsgBox "Please Enter Particular Name...", vbCritical, ""
    Me.txtpn.SetFocus
    Exit Sub
End If
If Me.txtamount.Text = "" Then
    MsgBox "Please Enter Amount of Particular Item...", vbCritical, ""
    txtamount.SetFocus
    Exit Sub
End If
If IsNumeric(Me.txtamount.Text) = False Then
    MsgBox "Only numbers required on this Field...", vbCritical, ""
    txtamount.SetFocus
    Exit Sub
End If

If Me.cbogl.ListIndex = -1 Then
    MsgBox "Please Enter Grade Level...", vbCritical, ""
    Me.cbogl.SetFocus
    Exit Sub
End If

With adopart.Recordset
    .Find "Particular='" & Trim(Me.cbogl.Text & " - " & Me.txtpn.Text) & "'", 0, adSearchForward, 1
    If .EOF <> True Then
    MsgBox "Particular name already exist!", vbInformation + vbOKOnly, ""
    Me.txtpn.SetFocus
    Exit Sub
Else
    .AddNew
    .Fields(1) = Me.cbogl.Text
    .Fields(2) = Me.cbogl.Text & " - " & Me.txtpn.Text
    .Fields(3) = Me.txtamount.Text
    .Update
    MsgBox "Information Saved!!", vbInformation + vbOKOnly, ""
 End If
 End With
 
Set rec = New ADODB.Recordset
rec.Open "Select * from PARTICULAR", con, adUseClient, adLockOptimistic
Set dtgpart.DataSource = rec

dbgrid
clear
disable
End Sub

Private Sub dtgpart_Click()
With adopart.Recordset
    If .RecordCount < 1 Then MsgBox "No Data Selected", vbExclamation, "": Exit Sub
End With
enable
cmdadd.Enabled = False
cmdsave.Enabled = False
cmddelete.Enabled = True
Me.cbogl.locked = True
Me.txtamount.locked = True
Me.txtpn.locked = True
dtgpart.MarqueeStyle = dbgHighlightRow
Me.cbogl.Text = dtgpart.Columns(1)
Me.txtpn.Text = dtgpart.Columns(2)
Me.txtamount.Text = dtgpart.Columns(3)
End Sub

Private Sub dtgpart_HeadClick(ByVal ColIndex As Integer)
With adopart.Recordset
    If (.Sort = .Fields(ColIndex).[Name] & " Asc") Then
        .Sort = .Fields(ColIndex).[Name] & " Desc"
    Else
        .Sort = .Fields(ColIndex).[Name] & " Asc"
    End If
End With
End Sub

Private Sub Form_Load()
OpenConnection
dbgrid
disable
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim a As Integer
If cmdsave.Enabled = True Then
    a = MsgBox("Are you sure you want to quit this form with out saving?", vbYesNo + vbQuestion, "")
        If a = vbYes Then
            Call CloseConnection
            Unload Me
        Else
            Cancel = 1
            End If
Else
    Call CloseConnection
    Unload Me
End If
End Sub

Public Sub disable()
Me.cbogl.Enabled = False
Me.txtpn.Enabled = False
Me.txtamount.Enabled = False
cmdsave.Enabled = False
cmdcancel.Enabled = False
cmddelete.Enabled = False
End Sub
Public Sub enable()
Me.cbogl.Enabled = True
Me.txtpn.Enabled = True
Me.txtamount.Enabled = True
cmdsave.Enabled = True
cmdcancel.Enabled = True
End Sub
Public Sub clear()
Me.cbogl.ListIndex = -1
Me.txtpn.Text = ""
Me.txtamount.Text = ""
End Sub

Public Sub dbgrid()
dtgpart.Columns(0).Visible = False
dtgpart.Columns(1).Width = 1500
dtgpart.Columns(2).Width = 3000
dtgpart.Columns(3).Width = 1000
End Sub

Private Sub txtamount_KeyPress(KeyAscii As Integer)
If KeyAscii < 48 Or KeyAscii > 57 Then
    KeyAscii = 0
End If
End Sub
